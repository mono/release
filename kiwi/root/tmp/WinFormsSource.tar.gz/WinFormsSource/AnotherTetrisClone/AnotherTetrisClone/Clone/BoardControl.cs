using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

using Clone.Engine;

namespace Clone
{
	public class BoardControl : UserControl
	{
		private Container components = null;

		private Board _board;
		private uint _fieldWidth; 
		private uint _fieldHeight;
		private bool _ghostVisible = false;
		private static Color _ghostOutlineColor = Color.Red;

		public BoardControl(Board board)
		{
			_board = board;
			InitializeComponent();
			SetUp();
			SetFieldSize();
		}

		public bool GhostVisible
		{
			set { _ghostVisible = value; }
			get { return _ghostVisible; }
		}

		private void SetUp()
		{
			_board.Changed += new BoardChangedEventHandler(board_Changed);
		}

		private void SetFieldSize()
		{
			if (_board == null)
				return;

			_fieldWidth = (uint) Math.Floor(this.Width / _board.Width);
			_fieldHeight = (uint) Math.Floor(this.Height / (_board.Height - 1));
		}

		protected override void OnResize(EventArgs e)
		{
			base.OnResize (e);
			SetFieldSize();
			Invalidate();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Component Designer generated code

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// BoardControl
			// 
			this.Name = "BoardControl";
			this.Size = new System.Drawing.Size(180, 360);

		}

		#endregion

		private void board_Changed(object sender, BoardChangedEventArgs e)
		{
			if (this.InvokeRequired)
				this.Invoke(new BoardChangedEventHandler(board_Changed), 
					new object[] { sender, e });

			// Board -> boardControl coordinates conversion
			// (matrix indexes -> real form coordinates)
			foreach (Position position in e.ChangedFields)
			{
				FieldRenderInfo renderInfo = new FieldRenderInfo(Color.Empty, 
					this.Height, position.Column, position.Line,
					_fieldWidth, _fieldHeight);
				Rectangle fieldRectangle = new Rectangle((int) renderInfo.Left, 
					(int) renderInfo.Top, (int) renderInfo.Width, 
					(int) renderInfo.Height);
				this.Invalidate(fieldRectangle);
			}
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			if (_fieldWidth == 0 || _fieldHeight == 0)
				return;
			
			// calculate approximately board area to overdraw
			// (convert control coordinates -> matrix indexes)
			byte left, right, top, bottom;
			left = (byte) (e.ClipRectangle.Left / _fieldWidth);
			right = (byte) (e.ClipRectangle.Right / _fieldWidth);
			bottom = (byte) Math.Max(0, 
				(this.Height - e.ClipRectangle.Bottom) / _fieldHeight);
			top = (byte) Math.Max(0, 
				(this.Height - e.ClipRectangle.Top) / _fieldHeight);
			// protection against overflow
			// (while resizing, it causes problems without this protection)
			top = (byte) Math.Min(top, _board.Height - 2);
			bottom = (byte) Math.Min(bottom, _board.Height - 2);
			right = (byte) Math.Min(right, _board.Width - 1);

			DrawBoardArea(e.Graphics, left, bottom, right, top);
	
			base.OnPaint(e);
		}

		#region -- Draw board, shape, and ghost --

		private void DrawBoardArea(Graphics controlGraphics,
			byte leftColumn, byte bottomLine, byte rightColumn, byte topLine)
		{
			controlGraphics.Clear(this.BackColor);
			for (byte column=leftColumn; column<=rightColumn; column++)
				for (byte line=bottomLine; line<=topLine; line++)
				{
					Field fieldToDraw = _board[column, line];
					if (fieldToDraw.Empty)
						continue;

					Color colorToPaint = 
						fieldToDraw.Empty ? this.BackColor : fieldToDraw.Color;
		
					FieldDrawingUtility.DrawField(controlGraphics, 
						new FieldRenderInfo(colorToPaint, this.Height, 
						column, line, _fieldWidth, _fieldHeight));
				}

			if (_board.ShapeMover != null)
			{
//				Thread.Sleep(200);  // for testing purposes
				if (_ghostVisible 
					&& _board.ShapeMover.GetGhostDifferenceInY() != 0)
					DrawGhostShape(controlGraphics, leftColumn, bottomLine,
					rightColumn, topLine);
				DrawFallingShape(controlGraphics, leftColumn, bottomLine,
					rightColumn, topLine);
				
			}
		}

		private void DrawGhostShape(Graphics controlGraphics,
			byte leftColumn, byte bottomLine, byte rightColumn, byte topLine)
		{
			Shape shapeToDraw = _board.ShapeMover.Shape;
			for (byte i=0; i<shapeToDraw.Width; i++)
				for (byte j=0; j<shapeToDraw.Height; j++)
				{
					uint boardLeft = (uint) (i + _board.ShapeMover.PositionX);
					uint boardBottom = (uint) (j + _board.ShapeMover.PositionY
						- _board.ShapeMover.GetGhostDifferenceInY());

					// this field isn't in the overdrawn rectangle
					if (boardLeft < leftColumn || boardLeft > rightColumn ||
						boardBottom < bottomLine || boardBottom > topLine)
						continue;

					if (shapeToDraw[i, j].Empty || 
						boardBottom > _board.Height - 2)
						continue;

					FieldDrawingUtility.DrawGhostField(controlGraphics, 
						new FieldRenderInfo(shapeToDraw[i, j].Color, this.Height, 
						boardLeft, boardBottom, _fieldWidth, _fieldHeight));
				}
		}

		private void DrawFallingShape(Graphics controlGraphics,
			byte leftColumn, byte bottomLine, byte rightColumn, byte topLine)
		{
			Shape shapeToDraw = _board.ShapeMover.Shape;
			for (byte i=0; i<shapeToDraw.Width; i++)
				for (byte j=0; j<shapeToDraw.Height; j++)
				{
					uint boardLeft = (uint) (i + _board.ShapeMover.PositionX);
					uint boardBottom = (uint) (j + _board.ShapeMover.PositionY);

					// this field isn't in the overdrawn rectangle
					if (boardLeft < leftColumn || boardLeft > rightColumn ||
						boardBottom < bottomLine || boardBottom > topLine)
						continue;
					
					if (shapeToDraw[i, j].Empty || 
						boardBottom > _board.Height - 2)
						continue;

					FieldDrawingUtility.DrawField(controlGraphics, 
						new FieldRenderInfo(shapeToDraw[i, j].Color, this.Height, 
						boardLeft, boardBottom, _fieldWidth, _fieldHeight));
				}
		}

		#endregion

		#region -- FieldRenderInfo struct --

		private struct FieldRenderInfo
		{
			private Color _color;
			public readonly uint Left, Bottom, Right, Top;

			public FieldRenderInfo(Color fieldColor, int formHeight, 
				uint boardLeft, uint boardBottom, uint fieldWidth, 
				uint fieldHeight)
			{
				_color = fieldColor;

				// convert coordinates - board -> boardControl
				Left = boardLeft * fieldWidth;
				Right = Left + fieldWidth - 1;
				Bottom = (uint) (formHeight - boardBottom * fieldHeight - 1);
				Top = Bottom - fieldHeight + 1;
			}

			public Color Color
			{
				get { return System.Drawing.Color.FromArgb(_color.ToArgb()); }
			}

			public uint Height
			{
				get { return Bottom - Top + 1; }
			}

			public uint Width
			{
				get { return Right - Left + 1; }
			}

			public PointF[] GetFieldCorners()
			{
				return new PointF[] {
										new PointF(Left, Bottom), 
										new PointF(Right, Bottom),
										new PointF(Right, Top), 
										new PointF(Left, Top)
									};
			}
		}


		#endregion

		#region -- FieldDrawingUtility --

		private sealed class FieldDrawingUtility
		{
			private FieldDrawingUtility()
			{
			}

			public static void DrawGhostField(Graphics controlGraphics, 
				FieldRenderInfo fieldRenderInfo)
			{
				controlGraphics.DrawRectangle(new Pen(_ghostOutlineColor), 
					fieldRenderInfo.Left, fieldRenderInfo.Top, 
					fieldRenderInfo.Width - 2, fieldRenderInfo.Height - 2);
			}

			public static void DrawField(Graphics controlGraphics, 
			                             FieldRenderInfo fieldRenderInfo)
			{
				// draw rectangle
				controlGraphics.FillPolygon(new SolidBrush(fieldRenderInfo.Color),
					fieldRenderInfo.GetFieldCorners());

				DrawOutlines(controlGraphics, fieldRenderInfo);
			}

			private static void DrawOutlines(Graphics controlGraphics, 
				FieldRenderInfo fieldRenderInfo)
			{
				Color colorToPaint = fieldRenderInfo.Color;
				uint formLeft = fieldRenderInfo.Left;
				uint formBottom = fieldRenderInfo.Bottom;
				uint formRight = fieldRenderInfo.Right;
				uint formTop = fieldRenderInfo.Top;

				// draw rectangle outlines & shadows of the drawn field
				Pen penLight = new Pen(GetLightenedColor(colorToPaint, 0.45f));
				Pen penDarker = new Pen(GetDarkenedColor(colorToPaint, 0.5f));
				Pen penDark = new Pen(GetDarkenedColor(colorToPaint, 0.65f));

				// left
				controlGraphics.DrawLine(penLight,
				                         new PointF(formLeft + 1, formBottom - 2), 
				                         new PointF(formLeft + 1, formTop + 1));
				// upper
				controlGraphics.DrawLine(penLight,
				                         new PointF(formLeft + 1, formTop + 1), 
				                         new PointF(formRight - 2, formTop + 1));
				// inner bottom
				controlGraphics.DrawLine(penDarker,
				                         new PointF(formLeft + 1, formBottom - 1), 
				                         new PointF(formRight - 1, formBottom - 1));
				// inner right
				controlGraphics.DrawLine(penDarker,
				                         new PointF(formRight - 1, formTop + 1), 
				                         new PointF(formRight - 1, formBottom - 1));
				// outer bottom
				controlGraphics.DrawLine(penDark,
				                         new PointF(formLeft, formBottom), 
				                         new PointF(formRight, formBottom));
				// outer right
				controlGraphics.DrawLine(penDark,
				                         new PointF(formRight, formTop), 
				                         new PointF(formRight, formBottom));
			}

			private static Color GetDarkenedColor(Color colorToPaint, 
				float changeInPercent)
			{
				return Color.FromArgb(
					DarkenByPercent(colorToPaint.R, changeInPercent),
					DarkenByPercent(colorToPaint.G, changeInPercent),
					DarkenByPercent(colorToPaint.B, changeInPercent)
					);
			}

			private static Color GetLightenedColor(Color colorToPaint, 
				float changeInPercent)
			{
				return Color.FromArgb(
					LightenByPercent(colorToPaint.R, changeInPercent),
					LightenByPercent(colorToPaint.G, changeInPercent),
					LightenByPercent(colorToPaint.B, changeInPercent)
					);
			}

			private static byte DarkenByPercent(byte channelToLighten, 
				float change)
			{
				return (byte) (channelToLighten - 
					Math.Floor(channelToLighten * change));
			}

			private static byte LightenByPercent(byte channelToDarken, 
				float change)
			{
				return (byte) (channelToDarken + 
					Math.Floor((255 - channelToDarken) * change));
			}

		}

		#endregion
	}
}