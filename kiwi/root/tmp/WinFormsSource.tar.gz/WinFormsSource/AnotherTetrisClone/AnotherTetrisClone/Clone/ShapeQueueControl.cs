using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

using Clone.Engine;

namespace Clone
{
	public class ShapeQueueControl : UserControl
	{
		private Container components = null;
		private ShapeQueue _queue;

		private int _leftMargin = 20;
		private int _topMargin = 0;
		private int _fieldSize = 10;

		public ShapeQueueControl(ShapeQueue queue)
		{
			_queue = queue;
			InitializeComponent();
			_queue.Changed += new EventHandler(queue_Changed);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint (e);
			DrawQueue(e.Graphics);
		}

		private void DrawQueue(Graphics graphics)
		{
			byte maxShapeHeight = _queue.MaxDefinedHeight;
			Shape[] shapes = _queue.GetQueueImage();
			for (byte i=0; i<shapes.Length; i++)
			{
				DrawShape(graphics, shapes[i], (maxShapeHeight + 1)*(i+1));
			}
		}

		private void DrawShape(Graphics graphics, Shape shape, int y)
		{
			Pen pen = new Pen(Color.Black);
			SolidBrush brush = new SolidBrush(shape.Color);
			for (byte i=0; i<shape.Width; i++)
				for (byte j=0; j<shape.Height; j++)
				{
					if (shape[i, j].Empty)
						continue;

					graphics.FillRectangle(brush, 
						_leftMargin + i*_fieldSize,
						_topMargin + (y-j)*_fieldSize,
						_fieldSize, _fieldSize);
					graphics.DrawRectangle(pen, 
						_leftMargin + i*_fieldSize,
						_topMargin + (y-j)*_fieldSize,
						_fieldSize, _fieldSize);
				}
		}

		private void queue_Changed(object sender, EventArgs e)
		{
			if (InvokeRequired)
				this.Invoke(new EventHandler(queue_Changed));
			
			this.Invalidate();
		}
	}
}
