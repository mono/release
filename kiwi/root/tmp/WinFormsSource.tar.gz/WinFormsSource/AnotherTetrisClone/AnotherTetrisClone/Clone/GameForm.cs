using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

using Clone.Engine;

namespace Clone
{
	public class GameForm : Form
	{
		private Container components = null;
		private Label levelLabel;
		private Label levelValueLabel;
		private Label linesCompletedLabel;
		private Label linesCompletedValueLabel;
		private Label scoreLabel;
		private Label scoreValueLabel;
		private MenuItem menuSeparator1;
		private MenuItem gameMenuItem;
		private MenuItem startMenuItem;
		private MenuItem pauseMenuItem;
		private MenuItem exitMenuItem;
		private MainMenu mainMenu;
		private MenuItem ghostMenuItem;
		private MenuItem menuSeparator2;
		private MenuItem aboutMenuItem;
		private MenuItem infoMenuItem;
		private BoardControl boardControl;
		private ShapeQueueControl queueControl;

		private Game _game = new Game();
		private bool _keypressed = false;
		private bool _ignoreKeys = false;

		public GameForm()
		{
			SetUpGame();
			InitializeComponent();
			InitializeGameControls();
		}

		private void SetUpGame()
		{
			_game.Board.ShapeFallenDown += 
				new BoardChangedEventHandler(Board_ShapeFallenDown);
			_game.GameOver += new EventHandler(game_GameOver);
		}

		private void InitializeGameControls()
		{
			this.boardControl = new BoardControl(_game.Board);
			this.queueControl = new ShapeQueueControl(_game.ShapeQueue);
//			this.boardControl = new Clone.BoardControl(
//				BoardUtility.GetTestBoard());
			this.SuspendLayout();

			// boardControl
			this.boardControl.Location = new Point(110, 0);
			this.boardControl.Name = "boardControl";
			this.boardControl.BackColor = Color.Black;
			this.boardControl.TabIndex = 1;
			this.boardControl.Anchor = AnchorStyles.Top
				| AnchorStyles.Bottom
				| AnchorStyles.Left
				| AnchorStyles.Right;
			this.boardControl.Height = this.ClientSize.Height;
			this.boardControl.Width = 220;
			this.boardControl.Enabled = false;
			this.boardControl.GhostVisible = true;
			this.boardControl.Paint += new PaintEventHandler(boardControl_Paint);

			// shapeQueueControl
			this.queueControl.Location = new Point(354, 20);
			this.queueControl.Name = "queueControl";
			this.queueControl.BackColor = Color.Black;
			this.queueControl.TabIndex = 2;
			this.queueControl.Anchor = AnchorStyles.Top | AnchorStyles.Right;
			this.queueControl.Height = 150;
			this.queueControl.Width = 80;
			this.queueControl.Enabled = false;

			this.Controls.Add(this.boardControl);
			this.Controls.Add(this.queueControl);
			this.ResumeLayout(false);
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.scoreLabel = new System.Windows.Forms.Label();
			this.scoreValueLabel = new System.Windows.Forms.Label();
			this.linesCompletedLabel = new System.Windows.Forms.Label();
			this.linesCompletedValueLabel = new System.Windows.Forms.Label();
			this.levelLabel = new System.Windows.Forms.Label();
			this.levelValueLabel = new System.Windows.Forms.Label();
			this.mainMenu = new System.Windows.Forms.MainMenu();
			this.gameMenuItem = new System.Windows.Forms.MenuItem();
			this.startMenuItem = new System.Windows.Forms.MenuItem();
			this.pauseMenuItem = new System.Windows.Forms.MenuItem();
			this.menuSeparator2 = new System.Windows.Forms.MenuItem();
			this.ghostMenuItem = new System.Windows.Forms.MenuItem();
			this.menuSeparator1 = new System.Windows.Forms.MenuItem();
			this.exitMenuItem = new System.Windows.Forms.MenuItem();
			this.aboutMenuItem = new System.Windows.Forms.MenuItem();
			this.infoMenuItem = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// scoreLabel
			// 
			this.scoreLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.scoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.scoreLabel.ForeColor = System.Drawing.Color.White;
			this.scoreLabel.Location = new System.Drawing.Point(8, 205);
			this.scoreLabel.Name = "scoreLabel";
			this.scoreLabel.Size = new System.Drawing.Size(72, 23);
			this.scoreLabel.TabIndex = 0;
			this.scoreLabel.Text = "Score";
			// 
			// scoreValueLabel
			// 
			this.scoreValueLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.scoreValueLabel.ForeColor = System.Drawing.Color.White;
			this.scoreValueLabel.Location = new System.Drawing.Point(8, 221);
			this.scoreValueLabel.Name = "scoreValueLabel";
			this.scoreValueLabel.Size = new System.Drawing.Size(72, 23);
			this.scoreValueLabel.TabIndex = 1;
			this.scoreValueLabel.Text = "0";
			// 
			// linesCompletedLabel
			// 
			this.linesCompletedLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.linesCompletedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.linesCompletedLabel.ForeColor = System.Drawing.Color.White;
			this.linesCompletedLabel.Location = new System.Drawing.Point(8, 261);
			this.linesCompletedLabel.Name = "linesCompletedLabel";
			this.linesCompletedLabel.Size = new System.Drawing.Size(96, 23);
			this.linesCompletedLabel.TabIndex = 2;
			this.linesCompletedLabel.Text = "Lines Completed";
			// 
			// linesCompletedValueLabel
			// 
			this.linesCompletedValueLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.linesCompletedValueLabel.ForeColor = System.Drawing.Color.White;
			this.linesCompletedValueLabel.Location = new System.Drawing.Point(8, 277);
			this.linesCompletedValueLabel.Name = "linesCompletedValueLabel";
			this.linesCompletedValueLabel.Size = new System.Drawing.Size(80, 23);
			this.linesCompletedValueLabel.TabIndex = 3;
			this.linesCompletedValueLabel.Text = "0";
			// 
			// levelLabel
			// 
			this.levelLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.levelLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(238)));
			this.levelLabel.ForeColor = System.Drawing.Color.White;
			this.levelLabel.Location = new System.Drawing.Point(8, 317);
			this.levelLabel.Name = "levelLabel";
			this.levelLabel.Size = new System.Drawing.Size(48, 23);
			this.levelLabel.TabIndex = 4;
			this.levelLabel.Text = "Level";
			// 
			// levelValueLabel
			// 
			this.levelValueLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.levelValueLabel.ForeColor = System.Drawing.Color.White;
			this.levelValueLabel.Location = new System.Drawing.Point(8, 333);
			this.levelValueLabel.Name = "levelValueLabel";
			this.levelValueLabel.Size = new System.Drawing.Size(56, 23);
			this.levelValueLabel.TabIndex = 5;
			this.levelValueLabel.Text = "1";
			// 
			// mainMenu
			// 
			this.mainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.gameMenuItem,
																					 this.aboutMenuItem});
			// 
			// gameMenuItem
			// 
			this.gameMenuItem.Index = 0;
			this.gameMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.startMenuItem,
																						 this.pauseMenuItem,
																						 this.menuSeparator2,
																						 this.ghostMenuItem,
																						 this.menuSeparator1,
																						 this.exitMenuItem});
			this.gameMenuItem.Text = "Game";
			// 
			// startMenuItem
			// 
			this.startMenuItem.Index = 0;
			this.startMenuItem.Text = "Start";
			this.startMenuItem.Click += new System.EventHandler(this.startMenuItem_Click);
			// 
			// pauseMenuItem
			// 
			this.pauseMenuItem.Index = 1;
			this.pauseMenuItem.Text = "Pause";
			this.pauseMenuItem.Click += new System.EventHandler(this.pauseMenuItem_Click);
			// 
			// menuSeparator2
			// 
			this.menuSeparator2.Index = 2;
			this.menuSeparator2.Text = "-";
			// 
			// ghostMenuItem
			// 
			this.ghostMenuItem.Checked = true;
			this.ghostMenuItem.Index = 3;
			this.ghostMenuItem.Text = "Ghost Visible";
			this.ghostMenuItem.Click += new System.EventHandler(this.ghostMenuItem_Click);
			// 
			// menuSeparator1
			// 
			this.menuSeparator1.Index = 4;
			this.menuSeparator1.Text = "-";
			// 
			// exitMenuItem
			// 
			this.exitMenuItem.Index = 5;
			this.exitMenuItem.Text = "Exit";
			this.exitMenuItem.Click += new System.EventHandler(this.exitMenuItem_Click);
			// 
			// aboutMenuItem
			// 
			this.aboutMenuItem.Index = 1;
			this.aboutMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						  this.infoMenuItem});
			this.aboutMenuItem.Text = "About";
			// 
			// infoMenuItem
			// 
			this.infoMenuItem.Index = 0;
			this.infoMenuItem.Text = "Info";
			this.infoMenuItem.Click += new System.EventHandler(this.infoMenuItem_Click);
			// 
			// GameForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.Blue;
			this.ClientSize = new System.Drawing.Size(460, 399);
			this.Controls.Add(this.levelValueLabel);
			this.Controls.Add(this.levelLabel);
			this.Controls.Add(this.linesCompletedValueLabel);
			this.Controls.Add(this.linesCompletedLabel);
			this.Controls.Add(this.scoreValueLabel);
			this.Controls.Add(this.scoreLabel);
			this.Cursor = System.Windows.Forms.Cursors.Default;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.KeyPreview = true;
			this.MaximizeBox = false;
			this.Menu = this.mainMenu;
			this.Name = "GameForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Clone";
			this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GameForm_KeyDown);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.GameForm_KeyUp);
			this.ResumeLayout(false);

		}

		#endregion

		[STAThread]
		private static void Main()
		{
			Application.Run(new GameForm());
		}

		private void GameForm_KeyDown(object sender, KeyEventArgs e)
		{
			_keypressed = true;
			if (_ignoreKeys)
				return;
			switch (e.KeyCode)
			{
				case Keys.S:
					StartGame();
					break;
				case Keys.P:
					PauseGame();
					break;
				case Keys.Left:
					_game.MoveLeft();
					break;
				case Keys.Right:
					_game.MoveRight();
					break;
				case Keys.Up:
				case Keys.Space:
					_game.DropImmediately();
					break;
				case Keys.Down:
					_game.MoveDownByStep();
					break;
				case Keys.PageUp:
				case Keys.Z:
					_ignoreKeys = true;
					_game.RotateCCW();
					break;
				case Keys.PageDown:
				case Keys.C:
					_ignoreKeys = true;
					_game.RotateCW();
					break;
				case Keys.Escape:
					this.Close();
					break;
			}
		}

		private void GameForm_KeyUp(object sender, KeyEventArgs e)
		{
			_keypressed = false;
			_ignoreKeys = false;
		}

		private void Board_ShapeFallenDown(object sender, BoardChangedEventArgs e)
		{
			if (InvokeRequired)
				this.Invoke(new BoardChangedEventHandler(Board_ShapeFallenDown));

			if (_keypressed) // the shape has fallen down while keypressed
				_ignoreKeys = true;

			RefreshValues();
		}

		private void StartGame()
		{
			_game.Start();
			boardControl.Refresh();
			RefreshValues();
		}

		private void RefreshValues()
		{
			scoreValueLabel.Text = _game.Score.ToString();
			levelValueLabel.Text = _game.Level.ToString();
			linesCompletedValueLabel.Text = _game.LinesCompleted.ToString();
		}

		private void startMenuItem_Click(object sender, System.EventArgs e)
		{
			StartGame();
		}

		private void pauseMenuItem_Click(object sender, System.EventArgs e)
		{
			PauseGame();
		}

		private void PauseGame()
		{
			if (_game.Started == false)
				return;

			if (_game.Paused)
			{
				_game.Continue();
				boardControl.Refresh();
				return;				
			}

			_game.Pause();
			DrawPaused();
		}

		private void exitMenuItem_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void game_GameOver(object sender, EventArgs e)
		{
			if (InvokeRequired)
				this.Invoke(new EventHandler(game_GameOver));
			DrawGameOver();
		}

		private void ghostMenuItem_Click(object sender, System.EventArgs e)
		{
			ghostMenuItem.Checked = !ghostMenuItem.Checked;
			boardControl.GhostVisible = ghostMenuItem.Checked;
			boardControl.Refresh();
		}

		private void boardControl_Paint(object sender, PaintEventArgs e)
		{
			if (InvokeRequired)
				this.Invoke(new PaintEventHandler(boardControl_Paint));

			if (_game.Paused)
				DrawPaused();
			else if (_game.Ended)
				DrawGameOver();
		}

		private void DrawPaused()
		{
			Graphics graphics = boardControl.CreateGraphics();
			int x = boardControl.Width / 2;
			int y = boardControl.Height / 2;
			int width = 120;
			int height = 46;
			int fontSize = 14;
			graphics.FillRectangle(new SolidBrush(Color.Blue),
				x - width/2, y - height/2, width, height);
			graphics.DrawString("Paused", 
				new Font(FontFamily.GenericSansSerif, fontSize), 
				new SolidBrush(Color.White), x - width/2 + 24,
				y - fontSize);
		}

		private void DrawGameOver()
		{
			Graphics graphics = boardControl.CreateGraphics();
			int x = boardControl.Width / 2;
			int y = boardControl.Height / 2;
			int width = 120;
			int height = 46;
			int fontSize = 14;
			graphics.FillRectangle(new SolidBrush(Color.Blue),
				x - width/2, y - height/2, width, height);
			graphics.DrawString("Game Over", 
				new Font(FontFamily.GenericSansSerif, fontSize), 
				new SolidBrush(Color.White), x - width/2 + 10,
				y - fontSize);
		}

		private void infoMenuItem_Click(object sender, System.EventArgs e)
		{
			MessageBox.Show("Clone 2005\r\rAuthor: Alien", "About", 
				MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
	}
}