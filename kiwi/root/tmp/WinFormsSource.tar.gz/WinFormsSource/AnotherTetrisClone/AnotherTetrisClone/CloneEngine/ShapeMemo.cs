using System.Collections;

namespace Clone.Engine
{
	public class ShapeMemo
	{
		private Position _position;
		private Position _ghostPosition;
		private Matrix _shapeMatrix;

		public ShapeMemo(FallingShape shape)
		{
			_shapeMatrix = (Matrix) shape.Clone();
			_position = new Position(shape.PositionX,  shape.PositionY);
			_ghostPosition = 
				new Position(shape.PositionX,  shape.GetGhostPositionY());
		}

		public Position Position
		{
			get { return _position; }
		}

		public Position GhostPosition
		{
			get { return _ghostPosition; }
		}

		public Matrix ShapeMatrix
		{
			get { return _shapeMatrix; }
		}

		public Position[] GetNotEmptyFieldsPositions()
		{
			ArrayList positions = new ArrayList(
				_shapeMatrix.GetNotEmptyFieldsPositions(
				_position.Column, _position.Line));

			foreach (Position position in 
				_shapeMatrix.GetNotEmptyFieldsPositions(
				_ghostPosition.Column, _ghostPosition.Line))
			{
				if (positions.Contains(position) == false)
					positions.Add(position);
			}
			
			return (Position[]) positions.ToArray(typeof(Position));
		}

		public static Position[] GetDifferentFields(ShapeMemo memo1,
			FallingShape memo2)
		{
			return GetDifferentFields(memo1, new ShapeMemo(memo2));
		}
		public static Position[] GetDifferentFields(ShapeMemo memo1,
			ShapeMemo memo2)
		{
			Board board1 = new Board();
			board1.AddMatrix(memo1.ShapeMatrix, memo1.Position.Column, 
				memo1.Position.Line);
			Board board2 = new Board();
			board2.AddMatrix(memo2.ShapeMatrix, memo2.Position.Column, 
				memo2.Position.Line);
			ArrayList positions = new ArrayList(
				Matrix.CompareFields(board1, board2));

			// ghosts
			Board board3 = new Board();
			board3.AddMatrix(memo1.ShapeMatrix, memo1.Position.Column, 
				memo1.GhostPosition.Line);
			Board board4 = new Board();
			board4.AddMatrix(memo2.ShapeMatrix, memo2.Position.Column, 
				memo2.GhostPosition.Line);
			Position[] ghostPositions = Matrix.CompareFields(board3, board4);

			foreach (Position position in ghostPositions)
			{
				if (positions.Contains(position) == false)
					positions.Add(position);
			}

			return (Position[]) positions.ToArray(typeof(Position));
		}
	}
}
