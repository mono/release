using System;

namespace Clone.Engine
{
	public class BoardChangedEventArgs : EventArgs
	{
		private Position[] _changedFields;

		public BoardChangedEventArgs(Position[] changedFields)
		{
			_changedFields = changedFields;
		}

		public Position[] ChangedFields
		{
			get { return _changedFields; }
		}
	}
}
