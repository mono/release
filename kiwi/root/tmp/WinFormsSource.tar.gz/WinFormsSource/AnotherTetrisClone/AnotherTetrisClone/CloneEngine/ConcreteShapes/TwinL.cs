using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
	// **
	//  **
	internal sealed class TwinL : Shape
	{
		public TwinL() : base(3, 2, Color.Red)
		{
			SetFieldColor(0, 1, Color);
			SetFieldColor(1, 1, Color);
			SetFieldColor(1, 0, Color);
			SetFieldColor(2, 0, Color);
		}
	}
}