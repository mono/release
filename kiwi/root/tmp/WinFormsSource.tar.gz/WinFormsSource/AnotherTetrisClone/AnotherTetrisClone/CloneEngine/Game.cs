using System;

namespace Clone.Engine
{
	public class Game
	{
		private Board _board = new Board();
		private ShapeQueue _queue = new ShapeQueue();
		private bool _started = false;
		private bool _paused = false;

		private int _linesCompleted;
		private int _score;
		private int _level;
		private int _timerInterval;
		private bool _ended;

		public event EventHandler GameOver;

		public Game()
		{
			_board.ShapeFallenDown += 
				new BoardChangedEventHandler(board_ShapeFallenDown);
			_board.BoardFull += new EventHandler(board_BoardFull);
			_board.Changed += new BoardChangedEventHandler(board_Changed);
			_board.LinesCompleted += 
				new LinesCompletedEventHandler(board_LinesCompleted);
		}

		public Board Board
		{
			get { return _board; }
		}

		public int Level
		{
			get { return _level; }
		}

		public int LinesCompleted
		{
			get { return _linesCompleted; }
		}

		public int Score
		{
			get { return _score; }
		}

		public void Start()
		{
			if (_started)
				return;
			_started = true;
			_ended = false;

			SetUpBoard();
			ThrowNewShape();
		}

		private void SetUpBoard()
		{
			_board.Reset();
			_linesCompleted = 0;
			_score = 0;
			_level = 1;
			_timerInterval = 800;
		}

		public void Pause()
		{
			if (_started == false)
				return;
			_board.ShapeMover.Pause();
			_paused = true;
		}

		public void Continue()
		{
			if (_started == false)
				return;
			_board.ShapeMover.Continue();
			_paused = false;
		}

		public bool Paused
		{
			get { return _paused; }
		}

		public bool Started
		{
			get { return _started; }
		}

		public bool Ended
		{
			get { return _ended; }
		}

		public ShapeQueue ShapeQueue
		{
			get { return _queue; }
		}

		private void OnGameOver(EventArgs e)
		{
			if (GameOver != null)
				GameOver(this, e);
		}

		#region -- Controls - Falling Shape Movements --
		public void MoveLeft()
		{
			if (AreControlsDisabled())
				return;
			_board.ShapeMover.MoveLeft();
		}

		public void MoveRight()
		{
			if (AreControlsDisabled())
				return;
			_board.ShapeMover.MoveRight();
		}

		public void RotateCCW()
		{
			if (AreControlsDisabled())
				return;
			_board.ShapeMover.RotateCCW();
		}

		public void RotateCW()
		{
			if (AreControlsDisabled())
				return;
			_board.ShapeMover.RotateCW();
		}

		public void DropImmediately()
		{
			if (AreControlsDisabled())
				return;
			_board.ShapeMover.DropImmediately();
		}

		public void MoveDownByStep()
		{
			if (AreControlsDisabled())
				return;
			_board.ShapeMover.MoveDown();
		}

		private bool AreControlsDisabled()
		{
			return _started == false || _paused;
		}

		#endregion

		private void board_ShapeFallenDown(object sender, BoardChangedEventArgs e)
		{
			ThrowNewShape();
		}

		private void board_BoardFull(object sender, EventArgs e)
		{
			_started = false;
			_ended = true;
			OnGameOver(EventArgs.Empty);
		}

		private void board_Changed(object sender, BoardChangedEventArgs e)
		{
		}

		private void ThrowNewShape()
		{
			_board.ThrowShape(_queue.PickUpShape(), _timerInterval);
		}

		private void board_LinesCompleted(object sender, 
			LinesCompletedEventArgs e)
		{
			_linesCompleted += e.LinesCount;
			_score += (int) Math.Round(100 * e.LinesCount * Math.Pow(
				Math.Pow(2, 1/3d), (e.LinesCount - 1)));
			_level = _linesCompleted / 10 + 1;
			_timerInterval = Math.Max(55, 800 - (_level - 1) * 55);
		}
	}
}