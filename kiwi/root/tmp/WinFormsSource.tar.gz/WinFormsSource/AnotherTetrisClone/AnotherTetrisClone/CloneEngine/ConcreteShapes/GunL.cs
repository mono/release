using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
	// ***
	//   *
	internal sealed class GunL : Shape
	{
		public GunL() : base(3, 2, Color.Blue)
		{
			SetFieldColor(0, 1, Color);
			SetFieldColor(0, 0, Color);
			SetFieldColor(1, 0, Color);
			SetFieldColor(2, 0, Color);
		}
	}
}