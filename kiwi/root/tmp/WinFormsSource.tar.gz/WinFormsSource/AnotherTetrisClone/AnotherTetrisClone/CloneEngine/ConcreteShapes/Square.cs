using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
	// **
	// **
	internal sealed class Square : Shape
	{
		public Square() : base(2, 2, Color.Yellow)
		{
			SetFieldColor(0, 0, Color);
			SetFieldColor(1, 0, Color);
			SetFieldColor(0, 1, Color);
			SetFieldColor(1, 1, Color);
		}
	}
}