namespace Clone.Engine
{
	public delegate void LinesCompletedEventHandler(object sender,
		LinesCompletedEventArgs e);
}
