using System;
using System.Collections;
using System.Drawing;

namespace Clone.Engine
{
	public class Matrix : ICloneable
	{
		private Color _backgroundColor;
		private Field[,] _matrixInternal;

		protected Matrix(byte width, byte height) : 
			this(width, height, Color.Empty)
		{
		}
		protected Matrix(byte width, byte height, Color backgroundColor)
		{
			_backgroundColor = backgroundColor;
			_matrixInternal = new Field[width,height];

			InitializeMatrix();
		}

		protected Matrix(Matrix preparedMatrix)
		{
			_matrixInternal = preparedMatrix._matrixInternal;
		}

		public Field this[byte x, byte y]
		{
			get {return (Field) _matrixInternal[x, y].Clone();}
		}
		public Field this[Position position]
		{
			get {return this[position.Column, position.Line];}
		}

		protected void SetFieldColor(byte x, byte y, Color newColor)
		{
			_matrixInternal[x, y].Color = newColor;
		}

		public Color BackgroundColor
		{
			get {return _backgroundColor;}
		}

		public byte Height
		{
			get {return (byte) _matrixInternal.GetLength(1);}
		}

		public byte Width
		{
			get {return (byte) _matrixInternal.GetLength(0);}
		}

		
		public Position[] GetNotEmptyFieldsPositions()
		{
			return GetNotEmptyFieldsPositions(0, 0);
		}
		public Position[] GetNotEmptyFieldsPositions(byte offsetX, byte offsetY)
		{
			ArrayList positions = new ArrayList();
			for (byte i=0; i<this.Width; i++)
				for (byte j=0; j<this.Height; j++)
				{
					if (this[i, j].Empty == false)
						positions.Add(new Position((byte) (i + offsetX), 
						                           (byte) (j + offsetY)));
				}
			return (Position[]) positions.ToArray(typeof(Position));
		}

		public static Position[] CompareFields(Matrix m1, Matrix m2)
		{
			if (m1 == null || m2 == null || m1.Width != m2.Width 
				|| m1.Height != m2.Height)
				throw new ArgumentException("Both matrixes must be of the same size.");
			
			ArrayList positions = new ArrayList();
			for (byte i=0; i<m1.Width; i++)
				for (byte j=0; j<m1.Height; j++)
				{
					if (m1[i, j] != m2[i, j])
						positions.Add(new Position(i, j));
				}
			return (Position[]) positions.ToArray(typeof(Position));
		}

		public object Clone()
		{
			Matrix clonedMatrix = new Matrix(Width, Height, BackgroundColor);
			for (byte x = 0; x < Width; x++)
			{
				for (byte y = 0; y < Height; y++)
				{
					clonedMatrix._matrixInternal[x, y].Color = 
						_matrixInternal[x, y].Color;
				}
			}
			return clonedMatrix;
		}

		protected void ResetFields()
		{
			SetUpBackgroundColor();
		}

		protected virtual void Rotate(bool rotateClockwise)
		{
			Field[,] _rotatedMatrix = new Field[this.Height, this.Width];
			for (byte x = 0; x < this.Width; x++)
				for (byte y = 0; y < this.Height; y++)
				{
					if (rotateClockwise)
						_rotatedMatrix[y, x] = 
							_matrixInternal[this.Width - x - 1, y];
					else
						_rotatedMatrix[y, x] = 
							_matrixInternal[x, this.Height - y - 1];
				}
			_matrixInternal = _rotatedMatrix;
		}

		private void InitializeMatrix()
		{
			for (byte x = 0; x < Width; x++)
			{
				for (byte y = 0; y < Height; y++)
				{
					_matrixInternal[x, y] = new Field(_backgroundColor);
				}
			}
		}

		private void SetUpBackgroundColor()
		{
			foreach (Field field in _matrixInternal)
			{
				field.Color = _backgroundColor;
			}
		}
	}
}