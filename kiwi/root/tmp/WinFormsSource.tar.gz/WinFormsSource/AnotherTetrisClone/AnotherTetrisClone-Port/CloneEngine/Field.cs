using System;
using System.Drawing;

namespace Clone.Engine
{
	public class Field : ICloneable
	{
		private bool _empty = true;
		private Color _color = Color.Empty;

		internal Field()
		{
		}

		internal Field(Color color)
		{
			_color = color;
		}

		public Color Color
		{
			get {return _color;}
			set
			{
				_color = value;
				_empty = _color == Color.Empty;
			}
		}

		public bool Empty
		{
			get {return _empty;}
		}

		internal void Clear()
		{
			Color = Color.Empty;
		}

		public object Clone()
		{
			Field clonedField = new Field();
			clonedField.Color = Color;
			return clonedField;
		}

		public static bool operator == (Field field1, Field field2)
		{
			return field1.Equals(field2);
		}
		public static bool operator != (Field field1, Field field2)
		{
			return !field1.Equals(field2);
		}

		public override bool Equals(object field1)
		{
			if ((field1 is Field) == false)
				return false;

			Field fieldToCompare = (Field) field1;
			bool equals = this.Color == fieldToCompare.Color;

			return equals;
		}

		public override int GetHashCode()
		{
			return base.GetHashCode ();
		}


	}
}