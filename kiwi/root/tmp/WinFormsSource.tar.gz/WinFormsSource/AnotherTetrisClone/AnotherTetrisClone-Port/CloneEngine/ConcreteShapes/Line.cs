using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
	// ****
	internal sealed class Line : Shape
	{
		public Line() : base(4, 1, Color.LightBlue)
		{
			SetFieldColor(0, 0, Color);
			SetFieldColor(1, 0, Color);
			SetFieldColor(2, 0, Color);
			SetFieldColor(3, 0, Color);
		}
	}
}