using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
//	// ***
//	// * *
//	internal sealed class TestShape : Shape
//	{
//		public TestShape() : base(3, 2, Color.White)
//		{
//			SetFieldColor(0, 0, Color);
//			SetFieldColor(0, 1, Color);
//			SetFieldColor(1, 1, Color);
//			SetFieldColor(2, 1, Color);
//			SetFieldColor(2, 0, Color);
//		}
//	}
}