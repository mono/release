using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
	//  *
	// ***
	internal sealed class Hill : Shape
	{
		public Hill() : base(3, 2, Color.Pink)
		{
			SetFieldColor(0, 0, Color);
			SetFieldColor(1, 0, Color);
			SetFieldColor(2, 0, Color);
			SetFieldColor(1, 1, Color);
		}
	}
}