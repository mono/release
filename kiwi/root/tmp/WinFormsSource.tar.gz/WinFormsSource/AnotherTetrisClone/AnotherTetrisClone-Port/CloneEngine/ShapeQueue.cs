using System;
using System.Collections;
using System.Reflection;

namespace Clone.Engine
{
	public class ShapeQueue
	{
		private Queue _queue;
		private ArrayList _definedShapes = new ArrayList();
		private byte _maxDefinedHeight = 0;
		private Random _random = new Random();

		public event EventHandler Changed;

		internal ShapeQueue() : this(4)
		{
		}

		internal ShapeQueue(byte queueLength)
		{
			SetDefinedShapes();
			FillQueue(queueLength);
		}

		public byte Length
		{
			get {return (byte) _queue.Count;}
		}

		public byte MaxDefinedHeight
		{
			get
			{
				return _maxDefinedHeight;
			}
		}

		public Shape[] GetQueueImage()
		{
			Shape[] shapesInQueue;
			lock (_queue)
			{
				shapesInQueue = new Shape[_queue.Count];
				_queue.CopyTo(shapesInQueue, 0);
			}
			return shapesInQueue;
		}

		private void OnChanged(EventArgs e)
		{
			if (Changed != null)
				Changed(this, e);
		}

		internal Shape PickUpShape()
		{
			Shape shape = (Shape) _queue.Dequeue();
			_queue.Enqueue(GetRandomShape());
			OnChanged(EventArgs.Empty);
			return shape;
		}

		private void FillQueue(byte queueLength)
		{
			_queue = new Queue(queueLength);
			for (byte counter = 0; counter < queueLength; counter++)
			{
				_queue.Enqueue(GetRandomShape());
			}
		}

		private Shape GetRandomShape()
		{
			int randomShapeIndex = _random.Next(_definedShapes.Count);
			return (Shape) Assembly.GetExecutingAssembly().CreateInstance(
				_definedShapes[randomShapeIndex].ToString());
		}

		private void SetDefinedShapes()
		{
			Assembly thisAssembly = Assembly.GetExecutingAssembly();
			Type[] definedTypes = thisAssembly.GetTypes();
			foreach (Type definedType in definedTypes)
			{
				if (definedType.IsClass && definedType.IsSealed
					&& definedType.IsSubclassOf(typeof(Shape)))
				{
					_definedShapes.Add(definedType.FullName);
					Shape shape = 
						(Shape) thisAssembly.CreateInstance(definedType.FullName);
					if (shape.Height > _maxDefinedHeight)
						_maxDefinedHeight = shape.Height;
				}
			}
		}
	}
}