using System;
using System.Collections;
using System.Drawing;

namespace Clone.Engine
{
	public class Board : Matrix
	{
		private ShapeMover _shapeMover;

		public event EventHandler BoardFull;
		public event LinesCompletedEventHandler LinesCompleted;
		public event BoardChangedEventHandler Changed;
		public event BoardChangedEventHandler ShapeFallenDown;

		internal Board() : base(10, 20)
		{
		}

		public ShapeMover ShapeMover
		{
			get { return _shapeMover; }
		}

		public void Reset()
		{
			this.ResetFields();
		}

		internal void ThrowShape(Shape shapeToDrop, int fallByStepInterval)
		{
			_shapeMover = new ShapeMover(this, shapeToDrop);

			_shapeMover.Moved += 
				new BoardChangedEventHandler(fallingShape_Moved);
			_shapeMover.FallenDown += 
				new BoardChangedEventHandler(fallingShape_FallenDown);
			_shapeMover.CollisionAtStart +=
				new EventHandler(fallingShape_CollisionAtStart);
			_shapeMover.ThrowIntoBoard(fallByStepInterval);
		}

		protected void OnBoardFull(EventArgs e)
		{
			if (BoardFull != null)
				BoardFull(this, e);
		}

		protected void OnChanged(BoardChangedEventArgs e)
		{
			if (Changed != null)
				Changed(this, e);
		}

		protected void OnShapeFallenDown(BoardChangedEventArgs e)
		{
			if (ShapeFallenDown != null)
				ShapeFallenDown(this, e);
		}

		private void OnLinesCompleted(LinesCompletedEventArgs eventArgs)
		{
			if (LinesCompleted != null)
				LinesCompleted(this, eventArgs);
		}

		private void fallingShape_FallenDown(object sender,
			BoardChangedEventArgs e)
		{
			// prepare for deleting
			byte[] linesCompleted = GetLinesCompleted();

			if (linesCompleted.Length == 0)
			{
				OnShapeFallenDown(e);
				return;				
			}

			// delete lines prepared for deleting
			Matrix beforeChange = (Matrix) this.Clone();
			for (int i=0; i<linesCompleted.Length; i++)
			{
				byte lineToDelete = linesCompleted[i];
				ShiftSegmentDown((byte) (lineToDelete+1-i));
			}
			// OnChanged
			OnChanged(new BoardChangedEventArgs(
				Matrix.CompareFields(beforeChange, this)));

			// score -> call game + number of lines completed
			OnLinesCompleted(
				new LinesCompletedEventArgs((byte) linesCompleted.Length));

			OnShapeFallenDown(e);
		}

		private void fallingShape_Moved(object sender, BoardChangedEventArgs e)
		{
			OnChanged(e);
		}

		private void fallingShape_CollisionAtStart(object sender, EventArgs e)
		{
			OnBoardFull(e);
		}

		internal void AddMatrix(Matrix matrix, byte x, byte y)
		{
			for (byte i = 0; i < matrix.Width; i++)
			{
				for (byte j = 0; j < matrix.Height; j++)
				{
					if (matrix[i, j].Empty == false)
					{ // collisions detection
						if (this[(byte) (i + x), (byte) (j + y)].Empty == false)
							throw new Exception("Collision detected.");

						this.SetFieldColor((byte) (i + x), (byte) (j + y),
							matrix[i, j].Color);
					}
				}
			}
		}
		
		private byte[] GetLinesCompleted()
		{
			ArrayList linesCompleted = new ArrayList();
			for (byte line=0; line<this.Height; line++)
			{
				bool lineCompleted = true;
				for (byte column=0; column<this.Width; column++)
				{
					if (this[column, line].Empty)
					{
						lineCompleted = false;
						break;
					}
				}
				if (lineCompleted)
					linesCompleted.Add(line);
			}
			return (byte[]) linesCompleted.ToArray(typeof(byte));
		}
		
		private void ShiftSegmentDown(byte fromLine)
		{
			// shift segment by one line down
			for (byte line=fromLine; line<this.Height; line++)
				for (byte column=0; column<this.Width; column++)
				{
					// copy field by shiftByLines down
					this.SetFieldColor(column, (byte) (line-1), 
						this[column, line].Color);
					// clear field
					this.SetFieldColor(column, line, Color.Empty);
				}
		}
	}

//	public class BoardUtility
//	{
//		private BoardUtility()
//		{
//		}
//
//		public static Board GetTestBoard()
//		{
//			Board board = new Board();
//			board.AddShape(new ConcreteShapes.Line(), 3, 18);
//			board.AddShape(new ConcreteShapes.TwinL(), 4, 11);
//			board.AddShape(new ConcreteShapes.Line(), 0, 0);
//			board.AddShape(new ConcreteShapes.Line(), 6, 0);
//			board.AddShape(new ConcreteShapes.GunR(), 2, 1);
//			return board;
//		}
//	}
}