namespace Clone.Engine
{
	public delegate void BoardChangedEventHandler(object sender,
		BoardChangedEventArgs e);
}
