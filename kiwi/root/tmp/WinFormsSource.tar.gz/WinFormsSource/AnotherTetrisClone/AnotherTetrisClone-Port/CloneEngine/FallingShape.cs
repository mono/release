using System;

using Timer = System.Windows.Forms.Timer;

namespace Clone.Engine
{
	public class FallingShape : Shape
	{
		private Board _board;
		// coordinates of the left bottom corner of the _shape on the _board
		private byte _positionX, _positionY;
		private Timer _timer = new Timer();
		private bool _fallen = false;

		internal event BoardChangedEventHandler FallenDown;
		internal event BoardChangedEventHandler Moved;
		internal event EventHandler CollisionAtStart;

		internal FallingShape(Shape shapeToDrop) : base(shapeToDrop)
		{
			_timer.Tick +=new EventHandler(timer_Tick);
		}

		public byte PositionX
		{
			get { return _positionX; }
		}

		public byte PositionY
		{
			get { return _positionY; }
		}

		public byte GetGhostPositionY()
		{
			byte ghostPositionY = _positionY;

			while (IsCollidingWithBoard(_positionX, 
				(byte) (ghostPositionY - 1)) == false)
			{
				--ghostPositionY;
			}

			return ghostPositionY;
		}

		public byte GetGhostDifferenceInY()
		{
			return (byte) (_positionY - GetGhostPositionY());
		}

		internal void ThrowIntoBoard(Board board, int fallByStepInterval)
		{
			_board = board;

			// calculate initial position
			_positionX = (byte) Math.Ceiling((_board.Width - this.Width) / 2);
			_positionY = (byte) (_board.Height - this.Height);
			if (this.Height == 1)
				_positionY--;	// "line" shape always starts at the 2nd line
	
			if (IsCollidingWithBoard(_positionX, _positionY))
			{
				OnCollisionAtStart(EventArgs.Empty);	// game over
				return;				
			}
	
			// display initial position
			OnMoved(new BoardChangedEventArgs(
				new ShapeMemo(this).GetNotEmptyFieldsPositions()));

			_timer.Interval = fallByStepInterval;
			_timer.Start();
		}

		protected void OnMoved(BoardChangedEventArgs e)
		{
			if (Moved != null)
				Moved(this, e);
		}

		protected void OnFallenDown(BoardChangedEventArgs e)
		{
			_board.AddMatrix(this, _positionX, _positionY);

			if (FallenDown != null)
				FallenDown(this, e);
		}

		protected void OnCollisionAtStart(EventArgs e)
		{
			if (CollisionAtStart != null)
				CollisionAtStart(this, e);
		}

		private void timer_Tick(object sender, EventArgs e)
		{
			MoveShape(Movement.Down);
		}

		#region -- Controls --

		internal void Pause()
		{
			_timer.Stop();
		}

		internal void Continue()
		{
			_timer.Start();
		}

		internal void MoveLeft()
		{
			MoveShape(Movement.Left);
		}

		internal void MoveRight()
		{
			MoveShape(Movement.Right);
		}

		internal void MoveDown()
		{
			_timer.Stop();
			MoveShape(Movement.Down);
			_timer.Start();
		}

		internal void RotateCCW()
		{
			Rotate(false);
		}

		internal void RotateCW()
		{
			Rotate(true);
		}

		internal void DropImmediately()
		{
			MoveShape(Movement.Drop);
		}

		#endregion

		#region -- Movements, Rotations --

		private void MoveShape(Movement movement)
		{
			if (_fallen)
				return;

			int horizontalMove = 0;
			int verticalMove = 0;
			switch (movement)
			{
				case Movement.Down:
					verticalMove = -1;
					break;
				case Movement.Left:
					horizontalMove = -1;
					break;
				case Movement.Right:
					horizontalMove = 1;
					break;
				case Movement.Drop:
					verticalMove = -GetGhostDifferenceInY();
					break;
			}

			if (IsCollidingWithBoard(_positionX + horizontalMove,
				_positionY + verticalMove))
			{
				if (movement == Movement.Down)
				{
					// the shape lies at the bottom and is about to fall,
					//  but there's not enough space below it -> OnFallenDown
					_fallen = true;
					_timer.Stop();
					OnFallenDown(new BoardChangedEventArgs(
						base.GetNotEmptyFieldsPositions()));
				}
				return;
			}

			// move
			ShapeMemo memo = new ShapeMemo(this);
			_positionX += (byte) horizontalMove;
			_positionY += (byte) verticalMove;
			OnMoved(new BoardChangedEventArgs(
				ShapeMemo.GetDifferentFields(memo, this)));

			if (_positionY == GetGhostPositionY() &&
				IsCollidingWithBoard(_positionX + 1, _positionY) && 
				IsCollidingWithBoard(_positionX -1, _positionY)
				|| movement == Movement.Drop)
			{
				// the shape has just fallen by this move, there is no posibility
				//  to shift it in the horizontal direction -> the board must check
				//  if there are any completed lines.
				_fallen = true;
				_timer.Stop();
				OnFallenDown(new BoardChangedEventArgs(
					this.GetNotEmptyFieldsPositions()));
			}
		}
		
		private new void Rotate(bool rotateClockwise)
		{
			if (_fallen)
				return;
				
			ShapeMemo memo = new ShapeMemo(this);
			int shiftInX, shiftInY;
			base.RotateAroundCentre(rotateClockwise, 
				out shiftInX, out shiftInY);

			// try to place the rotated shape
			// keep the shape centre in the same place
			int newPositionX = _positionX - shiftInX;
			int newPositionY = _positionY - shiftInY;
			// modify the new position so that the shape won't get 
			//  out of the board
			if (newPositionX < 0) 
				newPositionX = 0;
			else if (newPositionX + this.Width > _board.Width)
				newPositionX = _board.Width - this.Width;
			if (newPositionY + this.Height > _board.Height)
				newPositionY = _board.Height - this.Height;

			if (IsCollidingWithBoard(newPositionX, newPositionY) == false)
			{
				_positionX = (byte) newPositionX;
				_positionY = (byte) newPositionY;
			}
			else
			{// new position not found
				base.RotateAroundCentre(!rotateClockwise, 
					out shiftInX, out shiftInY);
				return;
			}

			OnMoved(new BoardChangedEventArgs(
				ShapeMemo.GetDifferentFields(memo, this)));
		}

		#endregion
		
		#region -- Helper Methods --

		private bool IsCollidingWithBoard(int shapePosX, int shapePosY)
		{
			// check indexes
			if (shapePosX < 0 || shapePosY < 0 || 
				shapePosX + this.Width > _board.Width ||
				shapePosY + this.Height > _board.Height)
				return true;

			// check overlapping
			for (byte i = 0; i < this.Width; i++)
			{
				for (byte j = 0; j < this.Height; j++)
				{
					if (this[i, j].Empty == false &&
						_board[(byte) (i + shapePosX), (byte) (j + shapePosY)
						].Empty == false)
						return true;
				}
			}
			return false;
		}

		#endregion

		private enum Movement
		{
			Left, Right, Down, Drop
		}
	}
}