namespace Clone.Engine
{
	public struct Position
	{
		public readonly byte Column;
		public readonly byte Line;

		public Position(byte column, byte line)
		{
			Column = column;
			Line = line;
		}
	}
}
