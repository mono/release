using System;

namespace Clone.Engine
{
	public class LinesCompletedEventArgs : EventArgs
	{
		private byte _linesCount;

		public LinesCompletedEventArgs(byte linesCount)
		{
			_linesCount = linesCount;
		}

		public byte LinesCount
		{
			get { return _linesCount; }
		}
	}
}
