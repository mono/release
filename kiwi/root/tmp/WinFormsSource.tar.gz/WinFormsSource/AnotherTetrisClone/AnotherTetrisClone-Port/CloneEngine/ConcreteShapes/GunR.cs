using System.Drawing;

namespace Clone.Engine.ConcreteShapes
{
	// ***
	// *
	internal sealed class GunR : Shape
	{
		public GunR() : base(3, 2, Color.Orange)
		{
			SetFieldColor(0, 0, Color);
			SetFieldColor(1, 0, Color);
			SetFieldColor(2, 0, Color);
			SetFieldColor(2, 1, Color);
		}
	}
}