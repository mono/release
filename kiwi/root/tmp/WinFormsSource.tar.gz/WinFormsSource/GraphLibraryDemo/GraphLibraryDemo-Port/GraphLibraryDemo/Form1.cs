using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Tools.Graphs;
using Microsoft.Tools.Graphs.Bars;
using Microsoft.Tools.Graphs.Lines;
using Microsoft.Tools.Graphs.Lines.DateLines;
using Microsoft.Tools.Graphs.Pies;
using Microsoft.Tools.Graphs.Legends;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;


namespace TestGraphLibrary
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
    {

        private System.Windows.Forms.Button button1;
        private BarGraph bg = new BarGraph();
        private Legend l = new Legend(Size.Empty);
		private LineGraph lg = new LineGraph();
		private DateLineGraph dlg = new DateLineGraph();
		private PieGraph pg = new PieGraph();
		private GraphBase currentGraph = null;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;

		private System.Windows.Forms.Label pictureBox1;

		private System.Windows.Forms.Label pictureBox2;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.Button button13;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.Label();
			this.pictureBox2 = new System.Windows.Forms.Label();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.button11 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.SuspendLayout();

			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(12, 3);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(115, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "BarGraph Vertical";
			this.button1.Click += new System.EventHandler(this.button1_Click);

			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(247, 3);
			this.button3.Name = "button3";
			this.button3.TabIndex = 5;
			this.button3.Text = "LineGraph";
			this.button3.Click += new System.EventHandler(this.button3_Click);

			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(12, 31);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(116, 23);
			this.button4.TabIndex = 6;
			this.button4.Text = "BarGraph Horizontal";
			this.button4.Click += new System.EventHandler(this.button4_Click);

			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox1.Location = new System.Drawing.Point(25, 61);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(540, 387);
			this.pictureBox1.TabIndex = 7;
			this.pictureBox1.Resize += new System.EventHandler(this.pictureBox1_SizeChanged);

			// 
			// pictureBox2
			// 
			this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.pictureBox2.Location = new System.Drawing.Point(576, 348);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(158, 101);
			this.pictureBox2.TabIndex = 8;
			this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);

			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(329, 3);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(107, 23);
			this.button5.TabIndex = 9;
			this.button5.Text = "DateLine - Months";
			this.button5.Click += new System.EventHandler(this.button5_Click);

			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(443, 3);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(104, 23);
			this.button6.TabIndex = 10;
			this.button6.Text = "DateLine - Weeks";
			this.button6.Click += new System.EventHandler(this.button6_Click);

			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(554, 3);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(103, 23);
			this.button7.TabIndex = 11;
			this.button7.Text = "DateLine - Years";
			this.button7.Click += new System.EventHandler(this.button7_Click);

			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(664, 3);
			this.button8.Name = "button8";
			this.button8.TabIndex = 12;
			this.button8.Text = "PieGraph";
			this.button8.Click += new System.EventHandler(this.button8_Click);

			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(134, 3);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(106, 23);
			this.button9.TabIndex = 13;
			this.button9.Text = "Separate Bars";
			this.button9.Click += new System.EventHandler(this.button9_Click);

			// 
			// button10
			// 
			this.button10.Location = new System.Drawing.Point(248, 31);
			this.button10.Name = "button10";
			this.button10.TabIndex = 14;
			this.button10.Text = "Projected";
			this.button10.Click += new System.EventHandler(this.button10_Click);

			// 
			// button11
			// 
			this.button11.Location = new System.Drawing.Point(461, 33);
			this.button11.Name = "button11";
			this.button11.TabIndex = 15;
			this.button11.Text = "Projected";
			this.button11.Click += new System.EventHandler(this.button11_Click);

			// 
			// button13
			// 
			this.button13.Location = new System.Drawing.Point(135, 31);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(106, 23);
			this.button13.TabIndex = 17;
			this.button13.Text = "Single Bars";
			this.button13.Click += new System.EventHandler(this.button13_Click);

			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(751, 467);
			this.Controls.Add(this.button13);
			this.Controls.Add(this.button11);
			this.Controls.Add(this.button10);
			this.Controls.Add(this.button9);
			this.Controls.Add(this.button8);
			this.Controls.Add(this.button7);
			this.Controls.Add(this.button6);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button1);
			this.Name = "Form1";
			this.Text = "GraphLibrary Demo";
			this.ResumeLayout(false);
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.Run(new Form1());
        }

        private void button1_Click (object sender, System.EventArgs e)
        {
			try
			{
				bg = new BarGraph(this.pictureBox1.Size);

				//bg.GridSpacingValue = 10;
				bg.CutOff = 65.0;
				bg.Color = Color.White;
				bg.ColorGradient = Color.Olive;

				BarSliceCollection bsc = new BarSliceCollection();

				bsc.Add(new BarSlice(-20, Color.Red, "Red"));
				bsc.Add(new BarSlice(60, Color.Green, "Green"));
				bsc.Add(new BarSlice(40, Color.Yellow, "Yellow"));
				bsc.Add(new BarSlice(12, Color.Blue, "Blue"));
				bsc.Add(new BarSlice(80, Color.Pink, "Pink"));
				bsc.Add(new BarSlice(30, Color.PaleTurquoise, "PaleTurquoise"));
				bsc.Add(new MultipleBarSlice(new double[] { -10, -30, -40 }, new Color[] { Color.Plum, Color.DodgerBlue, Color.Red }, "Multi1"));
				bsc.Add(new MultipleBarSlice(new double[] { 50, 45 }, new Color[] { Color.Orange, Color.Yellow }, "Multi2"));
				bg.BarSliceCollection = bsc;
				this.pictureBox1.Size = bg.Size;
				currentGraph = bg;
				this.pictureBox1.Image = GraphRenderer.DrawGraph(currentGraph);

				l = new Legend(this.pictureBox2.Size);

				//l.ColumnCount = 2;
				LegendEntryCollection lec = new LegendEntryCollection();

				lec.Add(new LegendEntry(Color.Red, "Red"));
				lec.Add(new LegendEntry(Color.Blue, "Blue"));
				lec.Add(new LegendEntry(Color.Pink, "Pink"));
				lec.Add(new LegendEntry(Color.Green, "Green"));
				lec.Add(new LegendEntry(Color.Plum, "Plum"));
				lec.Add(new LegendEntry(Color.Salmon, "Salmon"));
				lec.Add(new LegendEntry(Color.Salmon, "Salmon"));
				l.LegendEntryCollection = lec;
				this.pictureBox2.Image = GraphRenderer.DrawLegend(l);
			}
			catch
			{
			}
		}

        private void pictureBox1_SizeChanged (object sender, System.EventArgs e)
        {
			try
			{
				currentGraph.Size = this.pictureBox1.Size;
				this.pictureBox1.Image = GraphRenderer.DrawGraph(currentGraph);
			}
			catch
            {
            }
        }

		private void button2_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.pictureBox1.Image = BarGraphPlotter.GetSingleBarGraph(this.pictureBox1.Size, "Hope It Works", new int[] { 20, 30, 40, 50 }, null);
				this.pictureBox2.Image = BarGraphPlotter.GetLegend(this.pictureBox2.Size, new string[] { "1", "2", "3", "4" }, 2);
			}
			catch
			{
			}
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.pictureBox2.Image = null;
				lg = new LineGraph(this.pictureBox1.Size);

				//lg.GridSpacingValue = 10;
				lg.Color = Color.White;
				lg.ColorGradient = Color.Orange;
				lg.TotalXAxisIntervals = 30;
				lg.XAxisIntervalValue = 1;
				lg.AddXAxisText(0, 10, "Jan");
				lg.AddXAxisText(10, 20, "Feb");
				lg.AddXAxisText(20, 30, "Mar");

				Line line1 = new Line(Color.Blue);

				line1.AddPoint(0, 10);
				line1.AddPoint(2, 40);
				line1.AddPoint(3, 30);
				line1.AddPoint(4, 70);
				line1.AddPoint(5, 5);
				line1.AddPoint(6, 95);
				line1.AddPoint(7, 50);
				lg.Lines.Add(line1);

				Line line2 = new Line(Color.Green);

				line2.AddPoint(0, 60);
				line2.AddPoint(2, 10);
				line2.AddPoint(3, 25);
				line2.AddPoint(4, 80);
				line2.AddPoint(5, 40);
				line2.AddPoint(6, 20);
				line2.AddPoint(15, 5);
				lg.Lines.Add(line2);

				Line tl = new Line(Color.Red);

				tl.Width = 2.0F;
				tl.AddPoint(0, 85);
				tl.AddPoint(20, 25);
				tl.AddPoint(23, 65);
				tl.AddPoint(28, 75);
				tl.AddPoint(30, -55);
				lg.TrendLine = tl;

				// Legend
				l = new Legend(this.pictureBox1.Width, 50);

				//l.ColumnCount = 5;
				l.Text = null;

				LegendEntryCollection lec = new LegendEntryCollection();

				lec.Add(new LegendEntry(Color.Red, "Red"));
				lec.Add(new LegendEntry(Color.Blue, "Blue"));
				lec.Add(new LegendEntry(Color.Pink, "Pink"));
				lec.Add(new LegendEntry(Color.Green, "Green"));
				lec.Add(new LegendEntry(Color.Plum, "Plum"));
				lec.Add(new LegendEntry(Color.Salmon, "Salmon"));
				lec.Add(new LegendEntry(Color.Salmon, "Salmon"));
				l.LegendEntryCollection = lec;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(lg, l, this.pictureBox1.Size);
				currentGraph = lg;
			}
			catch
			{
			}
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			try
			{
				this.pictureBox2.Image = null;

				// Bar Graph
				bg.Alignment = Alignment.HorizontalLeft;

				// Legend
				l.Size = new Size(this.pictureBox1.Width, 50);

				//l.ColumnCount = 5;
				l.Text = null;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(bg, l, this.pictureBox1.Size);
				currentGraph = bg;
			}
			catch
			{
			}
		}

		private void pictureBox2_Click(object sender, System.EventArgs e)
		{
		
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			try
			{
				dlg = new DateLineGraph(DateMode.Months);
				dlg.Size = this.pictureBox1.Size;
				dlg.Color = Color.White;
				dlg.ColorGradient = Color.Orange;

				DateLine line1 = new DateLine(Color.Blue);

				line1.AddDateLinePoint(new DateTime(2003, 1, 1), 10);
				line1.AddDateLinePoint(new DateTime(2003, 1, 23), 20);
				line1.AddDateLinePoint(new DateTime(2003, 2, 1), 30);
				line1.AddDateLinePoint(new DateTime(2003, 2, 15), 75);
				line1.AddDateLinePoint(new DateTime(2003, 3, 1), 80);
				line1.AddDateLinePoint(new DateTime(2003, 4, 1), 55);
				dlg.DateLines.Add(line1);

				DateLine line2 = new DateLine(Color.Red);

				line2.Width = 2.0F;
				line2.AddDateLinePoint(new DateTime(2003, 1, 1), 10);
				line2.AddDateLinePoint(new DateTime(2003, 1, 24), 40);
				line2.AddDateLinePoint(new DateTime(2003, 2, 5), 10);
				line2.AddDateLinePoint(new DateTime(2003, 3, 16), 70);
				line2.AddDateLinePoint(new DateTime(2003, 4, 29), 30);
				dlg.DateTrendLine = line2;

				// Legend
				l = new Legend(this.pictureBox1.Width, 50);

				//l.ColumnCount = 5;
				l.Text = null;

				LegendEntryCollection lec = new LegendEntryCollection();

				lec.Add(new LegendEntry(Color.Red, "Red"));
				lec.Add(new LegendEntry(Color.Blue, "Blue"));
				lec.Add(new LegendEntry(Color.Pink, "Pink"));
				lec.Add(new LegendEntry(Color.Green, "Green"));
				lec.Add(new LegendEntry(Color.Plum, "Plum"));
				lec.Add(new LegendEntry(Color.Salmon, "Salmon"));
				lec.Add(new LegendEntry(Color.Salmon, "Salmon"));
				l.LegendEntryCollection = lec;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(dlg, l, this.pictureBox1.Size);
				currentGraph = dlg;
			}
			catch
			{
			}
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			try
			{
				dlg.DateMode = DateMode.Weeks;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(dlg, l, this.pictureBox1.Size);
				currentGraph = dlg;
			}
			catch
			{
			}
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			try
			{
				dlg.DateMode = DateMode.Years;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(dlg, l, this.pictureBox1.Size);
				currentGraph = dlg;
			}
			catch
			{
			}
		}

		private void button8_Click(object sender, System.EventArgs e)
		{
			try
			{
				pg = new PieGraph(this.pictureBox1.Size);
				pg.Color = Color.White;
				pg.ColorGradient = Color.RosyBrown;
				pg.Slices.Add(new PieSlice(80, Color.Blue));
				pg.Slices.Add(new PieSlice(137, Color.Green));
				pg.Slices.Add(new PieSlice(260, Color.Red));
				this.pictureBox1.Image = GraphRenderer.DrawGraph(pg);
				currentGraph = pg;
			}
			catch
			{
			}
		}

		private void button9_Click(object sender, System.EventArgs e)
		{
			try
			{
				bg.Size = this.pictureBox1.Size;
				bg.MultiBarDisplayStyle = MultiBarDisplayStyle.SeparateBars;
				this.pictureBox1.Image = GraphRenderer.DrawGraph(bg);
				currentGraph = bg;
			}
			catch 
			{
			}
		}

		private void button10_Click(object sender, System.EventArgs e)
		{
			try
			{
				lg.Size = this.pictureBox1.Size;
				lg.ShowProjectedTrend = true;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(lg, l, this.pictureBox1.Size);
				currentGraph = lg;
			}
			catch
			{
			}
		}

		private void button11_Click(object sender, System.EventArgs e)
		{
			try
			{
				dlg.Size = this.pictureBox1.Size;
				dlg.ShowProjectedTrend = true;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(dlg, l, this.pictureBox1.Size);
				currentGraph = dlg;
			}
			catch
			{
			}
		}

		private void button12_Click(object sender, System.EventArgs e)
		{
			try
			{
				dlg.DateMode = DateMode.Day;
				this.pictureBox1.Image = GraphRenderer.DrawGraphAndLegend(dlg, l, this.pictureBox1.Size);
				currentGraph = dlg;
			}
			catch
			{
			}
		}

		private void button13_Click(object sender, System.EventArgs e)
		{
			try
			{
				bg.Size = this.pictureBox1.Size;
				bg.MultiBarDisplayStyle = MultiBarDisplayStyle.SingleBar;
				this.pictureBox1.Image = GraphRenderer.DrawGraph(bg);
				currentGraph = bg;
			}
			catch
			{
			}
		}

	}
}
