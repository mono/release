#region Copyright
/*
 * File Name: Communication.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Drawing;
using System.Drawing.Drawing2D;

using System.Xml;

//Un-comment if you need MessageBoxes to debug
//using System.Collections;
//using System.ComponentModel;
//using System.Windows.Forms;

#endregion

namespace myUML
{
  /// <summary>
  /// The ArrowEnds enumeration is defined to describe the possible
  /// settings for a Communication's Arrows attribute:
  /// None:		The Communication is displayed with no arrows;
  /// Starting:	The COmmunication is displayed with an arrow at its Start point;
  /// Ending:	The Communication is displayed with an arrow at its End point;
  /// Both:		The Communication is displayed with an arrow both at its Start and its End.
  /// </summary>
  public enum ArrowEnds
  {
	None,
	Starting,
	Ending,
	Both
  }
  /// <summary>
  /// The CommunicationAnchors enumeration is defined to describe the various
  /// Anchors of a Communication:
  /// Start:	The Anchor at the Communication's Start point;
  /// Middle:	The Anchor in the Middle of the Communication;
  /// End:		The Anchor at the Communication's End;
  /// All:		All three of the COmmunication's Anchors;
  /// None:		None of the Communication's Anchors.
  /// </summary>
  public enum CommunicationAnchors
  {
	Start,
	Middle,
	End,
	All,
	None
  }

  /// <summary>
  /// A Communication is a representation of the connection between an
  /// Actor and a UseCase in a UseCase Diagram. An Actor linked to a
  /// UseCase by a Communication is involved in the performance of
  /// that UseCase, either by performing some action, or providing some
  /// information.
  /// The Communication class implements the IUMLtoXML interface.
  /// </summary>
  public class Communication : IUMLtoXML
  {
	#region Static Methods

	/// <summary>
	/// Converts a given string to its equivalent ArrowEnds value.
	/// </summary>
	/// <param name="x">The string to be converted.</param>
	/// <returns>The ArrowsEnd value whose string representation matches
	/// the given string; ArrowEnds.None is returned if the given string
	/// does not match any of the ArrowEnds values.</returns>
	public static ArrowEnds StringToArrowEnds(string x)
	{
	  switch(x)
	  {
		case "None":	  return ArrowEnds.None;
		case "Starting":  return ArrowEnds.Starting;
		case "Ending":	  return ArrowEnds.Ending;
		case "Both":	  return ArrowEnds.Both;
		default:		  return ArrowEnds.None;
	  }
	}

	#endregion

	#region Private Data Fields

	/// <summary>
	/// The Anchor where the Communication originates.
	/// </summary>
	private Anchor	  start	  = new Anchor();
	/// <summary>
	/// The Anchor in the middle of the Communication.
	/// </summary>
	private	Anchor	  mid	  = new Anchor();
	/// <summary>
	/// The Anchor at the end of the Communication.
	/// </summary>
	private	Anchor	  end	  = new Anchor();
	/// <summary>
	/// The ArrowEnds value indicating whether the Communication should be
	/// displayed with an arrow at its Start, End, at both its Start and End,
	/// or neither.
	/// </summary>
	private	ArrowEnds arrows  = ArrowEnds.None;
	/// <summary>
	/// A value indicating whether the Communication is currently selected
	/// or not.
	/// </summary>
	private	bool	  selected= false;
	/// <summary>
	/// The Color to be used when painting the Communication.
	/// </summary>
	private	Color	  color	  = Color.Black;

	#endregion

	#region Public Attributes

	/// <summary>
	/// Gets or sets the Communication start Anchor.
	/// </summary>
	public	Anchor	  Start
	{
	  get { return start;}
	  set { start=value.Clone(); }
	}
	/// <summary>
	/// Gets or sets the Communication's Mmiddle Anchor.
	/// Note: This should be changed to a readonly attribute,
	/// by eliminating the setter; changes to the Start or End
	/// Anchors should appropriately modify the mid Anchor
	/// implicitly.
	/// </summary>
	public	Anchor	  Mid
	{
	  get { return mid;}
	  set { mid=value.Clone(); }
	}
	/// <summary>
	/// Gets or sets the Communication's End Anchor.
	/// </summary>
	public	Anchor	  End
	{
	  get { return end;}
	  set { end=value.Clone(); }
	}
	/// <summary>
	/// Gets or sets the ArrowEnds value for the Communication, which
	/// determines which arrows (if any) should be displayed when
	/// the Communication is painted.
	/// </summary>
	public	ArrowEnds Arrows
	{
	  get { return arrows;}
	  set { arrows=value; }
	}
	/// <summary>
	/// Gets the value indicating whether the Communication is currently
	/// selected or not; see SetSelectedAnchor to set this value indirectly.
	/// </summary>
	public	bool	  Selected
	{
	  get { return selected;}
	}
	/// <summary>
	/// Gets or sets the Color to be used when painting the Communication.
	/// </summary>
	public	Color	  Color
	{
	  get { return color;}
	  set { color=value; }
	}
	/// <summary>
	/// Gets a value indicating whether any of the Communication's
	/// Anchors are currently selected. See the SetSelectedAnchor
	/// method to set this value indirectly.
	/// </summary>
	public	bool	  HasAnchorSelected
	{
	  get { return (start.Selected || mid.Selected || end.Selected); }
	}
	/// <summary>
	/// Gets a COmmunicationAnchors value indicating which of the Communication's
	/// Anchors are currently selected (if any). See the SetSelectedAnchor
	/// method to set this value indirectly.
	/// </summary>
	public	CommunicationAnchors  SelectedAnchor
	{
	  get
	  {
		if(start.Selected && mid.Selected && end.Selected)	return CommunicationAnchors.All;
		if(start.Selected)									return CommunicationAnchors.Start;
		if(mid.Selected)									return CommunicationAnchors.Middle;
		if(end.Selected)									return CommunicationAnchors.End;
		return CommunicationAnchors.None;
	  }
	}

	#endregion

	#region Constructors

	/// <summary>
	/// Instanciates a new Communication, with three default Anchors,
	/// no arrows to be displayed, no associated tex, and with its
	/// Color and TxtColor properties set to Color.Black.
	/// </summary>
	public Communication()
	{ }
	/// <summary>
	/// Instanciates a new Communication, set to be a deep copy
	/// of the rhs Communication.
	/// </summary>
	/// <param name="rhs">The COmmunication of which the new Communication
	/// should be a deep copy.</param>
	public Communication(Communication rhs)
	{
	  start = new Anchor(rhs.start);
	  mid	= new Anchor(rhs.mid);
	  end	= new Anchor(rhs.end);
	  arrows= rhs.arrows;
	  selected=rhs.selected;
	  color	=rhs.color;
	}

	#endregion

	#region Public Methods

	/// <summary>
	/// Creates and returns a new Communication, set to be a deep copy
	/// of this Communication.
	/// </summary>
	/// <returns>A new Communication instance, the deep copy of this
	/// Communication.</returns>
	public Communication Clone()
	{ return new Communication(this); }
	/// <summary>
	/// Sets the specified Communication's Anchor(s) as currently selected.
	/// Also sets the Communication's Selected property.
	/// </summary>
	/// <param name="x">The CommunicationAnchors value indicating which
	/// of the Communication's Anchors should be set as selected; if this value
	/// is equal to CommunicationAnchors.None, all of the Anchors are
	/// set as un-selected.</param>
	public void SetSelectedAnchor(CommunicationAnchors x)
	{ this.SetSelectedAnchor(x, true); }
	/// <summary>
	/// Sets the specified Communication's Anchor(s)' Selected property
	/// as specified. Also sets the Communication's Selected property.
	/// </summary>
	/// <param name="x">The CommunicationAnchors value indicating which
	/// of the Communication's Anchors should be set as selected; if this value
	/// is equal to CommunicationAnchors.None, all of the Anchors are
	/// set as un-selected, regardless of the b parameter.</param>
	/// <param name="b">The boolean parameter indicating whether the
	/// Communication Anchor(s) defined by the x parameter should be
	/// set as selected (if b is true) or not (if b is false).</param>
	public void SetSelectedAnchor(CommunicationAnchors x, bool b)
	{
	  switch(x)
	  {
		case CommunicationAnchors.All:
		  start.Selected=b;
		  mid.Selected=b;
		  end.Selected=b;
		  break;
		case CommunicationAnchors.Start:
		  start.Selected=b;
		  break;
		case CommunicationAnchors.Middle:
		  mid.Selected=b;
		  break;
		case CommunicationAnchors.End:
		  end.Selected=b;
		  break;
		case CommunicationAnchors.None:
		  start.Selected=false;
		  mid.Selected=false;
		  end.Selected=false;
		  break;
		default:
		  //Should never happen
		  break;
	  }//SWITCH on x
	  if(start.Selected || mid.Selected || end.Selected)	selected = true;
	  else													selected = false;
	}
	/// <summary>
	/// Paints this Communication on the Graphics g. Takes into consideration
	/// the clip rectangle, scroll offset, and maximum dimensions
	/// provided as parameters. In particular, if the clip rectangle's
	/// top coordinate plus the width of the scroll offset Size is greater than
	/// or equal to the MAX_DRAW_WIDTH value, the Communication is not drawn. The
	/// same happens if the clip rectangle's left coordinate plus the scroll
	/// offset's height is greater than or equal to the MAX_DRAW_HEIGHT.
	/// When painted in Standard PaintMode, Communications appear as a line,
	/// painted in the color specified by the Communication's Color property;
	/// arrows may appear at eithier the start point, the end point, at both
	/// points, or neither, based on the Communication's Arrows property.
	/// When painted in Outline PaintMode, Communications appear as a dashed
	/// blue line (and arrows are never rendered).
	/// </summary>
	/// <param name="g">The Graphics over which the Communications should be painted.</param>
	/// <param name="clipRectangle">The Rectangle defining the clip area that is currently
	/// being painted on the Graphics g.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the Graphics g.</param>
	/// <param name="MAX_DRAW_WIDTH">The Maximum X coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="MAX_DRAW_HEIGHT">The Maximum Y coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="pm">The PaintMode to be used.</param>
	public void Paint(Graphics g, Rectangle clipRectangle, Size scrollOffset,
	  int MAX_DRAW_WIDTH, int MAX_DRAW_HEIGHT, PaintMode pm)
	{	  
	  //Check for clipRectangle + scrollOffset to be in drawable range
	  if (clipRectangle.Top+scrollOffset.Width < MAX_DRAW_WIDTH ||
		clipRectangle.Left+scrollOffset.Height < MAX_DRAW_HEIGHT)
	  {
		//Make appropriately modified anchors:
		Anchor tmpStart = start.Clone();
		tmpStart.CenterX+=scrollOffset.Width;
		tmpStart.CenterY+=scrollOffset.Height;
		Anchor tmpMid = mid.Clone();
		tmpMid.CenterX+=scrollOffset.Width;
		tmpMid.CenterY+=scrollOffset.Height;
		Anchor tmpEnd = end.Clone();
		tmpEnd.CenterX+=scrollOffset.Width;
		tmpEnd.CenterY+=scrollOffset.Height;

		//Pick the Pen as if we were in Standard PaintMode
		//(it will be dashed in Outline mode)
		Pen pen = new Pen(color);
		pen.Width=5;
		//Fix the arrow-head:
		switch(arrows)
		{
		  case ArrowEnds.Starting:
			pen.StartCap=LineCap.ArrowAnchor;
			break;
		  case ArrowEnds.Ending:
			pen.EndCap=LineCap.ArrowAnchor;
			break;
		  case ArrowEnds.Both:
			pen.StartCap=LineCap.ArrowAnchor;;
			pen.EndCap=LineCap.ArrowAnchor;
			break;
		  case ArrowEnds.None:
		  default:
			//Do nothing.
			break;
		}//SWITCH on arrows

		//Depending on the PaintMode:
		switch(pm)
		{
		  case PaintMode.Standard:
			//Draw the line:
			g.DrawLine(pen, tmpStart.Center, tmpEnd.Center);

			//IF selected: Also draw the anchors:
			if(selected)
			{
			  start.Paint(g, clipRectangle, scrollOffset, MAX_DRAW_WIDTH, MAX_DRAW_HEIGHT, pm);
			  mid.Paint(g, clipRectangle, scrollOffset, MAX_DRAW_WIDTH, MAX_DRAW_HEIGHT, pm);
			  end.Paint(g, clipRectangle, scrollOffset, MAX_DRAW_WIDTH, MAX_DRAW_HEIGHT, pm);
			}
			break;
		  case PaintMode.Outline:
			//Modify the pen to be dashed and blue, with no line caps:
			pen.StartCap=LineCap.NoAnchor;
			pen.EndCap=LineCap.NoAnchor;
			pen.Color=Color.Blue;
			pen.DashPattern = new float[] {5, 2};
			g.DrawLine(pen, tmpStart.Center, tmpEnd.Center);
			break;
		  default:
			//Should never happen:
			break;
		}//SWITCH on pm
	  }//IF in max drawable size
	}
	/// <summary>
	/// Determines whether the PointF (where, presumably, a mouse click has
	/// taken place) lies within one of the Communication's Anchors. The scroll
	/// offset provided as parameter is also considered.
	/// </summary>
	/// <param name="cp">The PointF where the click took place.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the component where the Communication lies.</param>
	/// <returns>true if cp falls within any of the  Communication's Anchors;
	/// false otherwise.</returns>
	public bool Clicked(PointF cp, Size scrollOffset)
	{
	  //Checks if cp is in one of the anchors:
	  return(	start.Clicked(cp, scrollOffset)
		||		mid.Clicked(cp, scrollOffset)
		||		end.Clicked(cp, scrollOffset) );
	}
	/// <summary>
	/// Determines which of the Communication's Anchors have been clicked.
	/// Note that the method presumes that the three Anchors
	/// do not overlap; if an overlap occurs, the Start Anchor has precedence
	/// over the Mid Anchor, which, in turn, has precedence over the End Anchor.
	/// </summary>
	/// <param name="cp">The PointF where the click took place.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the component where the Communication lies.</param>
	/// <returns>The CommunicationAnchors value indicating which of the Communication's
	/// Anchors has been clicked.</returns>
	public CommunicationAnchors ClickedWhich(PointF cp, Size scrollOffset)
	{
	  if(start.Clicked(cp, scrollOffset)) return CommunicationAnchors.Start;
	  if(mid.Clicked(cp, scrollOffset))	  return CommunicationAnchors.Middle;
	  if(end.Clicked(cp, scrollOffset))	  return CommunicationAnchors.End;
	  return CommunicationAnchors.None;
	}
	/// <summary>
	/// Saves (Serializes) the Communication to the stream underneath the XmlTextWriter.
	/// The Communication is saved as an Element named "Communication", with two
	/// attributes: Arrows, whose value is set to the string representation of the
	/// Communication's Arrows property, and Color, whose value is set to the
	/// int representation of the Communication's Color. The Communication element
	/// also has 3 children:
	/// Start, containing the serialization of the Communication's Start Anchor;
	/// Mid, containing the serialization of the Communication's Mid Anchor;
	/// End, containing the serialization of the Communication's End Anchor;
	/// The stream is flushed after the Communication is serialized.
	/// </summary>
	/// <param name="x">The XmlTextWriter to which the Communication whould be saved.</param>
	public void SaveTo(XmlTextWriter x)
	{
	  x.WriteStartElement("Communication", null);
	  x.WriteAttributeString("Arrows", arrows.ToString());
	  x.WriteAttributeString("Color", color.ToArgb().ToString());

	  x.WriteStartElement("Start", null);
	  start.SaveTo(x);
	  x.WriteEndElement();

	  x.WriteStartElement("Mid", null);
	  mid.SaveTo(x);
	  x.WriteEndElement();

	  x.WriteStartElement("End", null);
	  end.SaveTo(x);
	  x.WriteEndElement();

	  x.WriteEndElement();

	  x.Flush();
	}
	/// <summary>
	/// Reads (Deserializes) a Communication from the given XmlTextReader.
	/// </summary>
	/// <param name="x">The XmlTextReader from which the Communication should be deserialized.</param>
	public void ReadFrom(XmlTextReader x)
	{
	  while(x.MoveToNextAttribute())
	  {
		switch(x.Name)
		{
		  case "Arrows":	arrows = StringToArrowEnds(x.Value);		  break;
		  case "Color":		color = Color.FromArgb(int.Parse(x.Value));	  break;
		  default:														  break;
		}
	  }//WEND

	  while(true)
	  {
		bool b = x.Read();
		if(x.NodeType==XmlNodeType.Element
		  &&	(x.Name=="Start" || x.Name=="Mid" || x.Name=="End") )
		{
		  string childName = x.Name;
		  x.Read();
		  switch(childName)
		  {
			case "Start":	  start.ReadFrom(x);  break;
			case "Mid":	  mid.ReadFrom(x);	  break;
			case "End":	  end.ReadFrom(x);	  break;
			default:							  break;
		  }//SWITCH
		  while(x.NodeType!=XmlNodeType.EndElement)
			x.Read();
		}//IF
		else  break;
	  }
	}

	#endregion

  }
}
