#region Copyright
/*
 * File Name: Anchor.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Drawing;

using System.Xml;

#endregion

namespace myUML
{
  /// <summary>
  /// The PaintMode enumeration defines the possible paint modes for the
  /// various figures in the myUML project:
  /// Standard:	this is the standard paint mode;
  /// Outline:	when a figure is painted in Outline mode, only its
  ///			outline should be painted; this mode is characteristically
  ///			used when a figure is being drawn by the user.
  /// </summary>
  public enum PaintMode
  {
	Standard,
	Outline
  }

  /// <summary>
  /// The Anchor class defines the Anchor points, or hot-spots of the figures
  /// in the myUML project. Each Anchor is defined by a Center point, and a
  /// square area centered on that point.
  /// The Anchor class implements the IUMLtoXML Interface.
  /// </summary>
  public class Anchor : IUMLtoXML
  {
	#region Constants

	/// <summary>
	/// The ANCHOR_SIZE constant defines the length of the side
	/// of the squares surrounding all Anchor Points.
	/// </summary>
	public const float	  ANCHOR_SIZE	=4.0f;

	#endregion

	#region Static Methods

	/// <summary>
	/// Instanciates a new Anchor point at the middle point between
	/// the given Anchors.
	/// </summary>
	/// <param name="a1">The first Anchor to be used in calculating the location of the
	/// Anchor instanciated by the method.</param>
	/// <param name="a2">The second Anchor to be used in calculating the location of the
	/// Anchor instanciated by the method.</param>
	/// <returns>A new Anchor, center on the mid-point between the two given Anchors.</returns>
	public static Anchor MidAnchor(Anchor a1, Anchor a2)
	{
	  Anchor r = new Anchor();
	  r.CenterX=(a1.CenterX+a2.CenterX)/2.0f;
	  r.CenterY=(a1.CenterY+a2.CenterY)/2.0f;
	  return r;
	}

	#endregion

	#region Private Fields

	/// <summary>
	/// The actual center of the Anchor. Defaults to the (0, 0) PointF.
	/// </summary>
	private	PointF	  center	=new PointF(0.0f, 0.0f);
	/// <summary>
	/// A flag indicating whether the Anchor is currently selected or not.
	/// </summary>
	private	bool	  selected	=false;

	#endregion

	#region Public Attributes

	/// <summary>
	/// Gets or sets the Center of the Anchor (a PointF).
	/// If you attempt to set this attribute to an empty PointF
	/// (based upon the PointF's IsEmpty attribute), the
	/// operation has no effect.
	/// </summary>
	public	PointF	Center
	{
	  get { return center; }
	  set
	  {
		if(!value.IsEmpty)
		  center = value;
	  }
	}
	/// <summary>
	/// Gets or sets the X coordinate of the Center of the Anchor.
	/// </summary>
	public	float	CenterX
	{
	  get { return center.X;}
	  set { center.X=value; }
	}
	/// <summary>
	/// Gets or sets the Y coordinate of the Center of the Anchor.
	/// </summary>
	public	float	CenterY
	{
	  get { return center.Y;}
	  set { center.Y=value; }
	}
	/// <summary>
	/// Gets or sets the value indicating whether the Anchor is
	/// currently selected.
	/// </summary>
	public	bool	Selected
	{
	  get { return selected;}
	  set { selected=value; }
	}

	#endregion

	#region Constructors

	/// <summary>
	/// Instanciates a new Anchor. By default, the new Anchor is not selected,
	/// and is centered at (0, 0).
	/// </summary>
	public Anchor()
	{ }
	/// <summary>
	/// Instanciates a new Anchor, centered as specified by the inp parameter.
	/// By default the new Anchor is not selected.
	/// </summary>
	/// <param name="inp">The PointF where the new Anchor should be centered.</param>
	public Anchor(PointF inp)
	{ center = inp; }
	/// <summary>
	/// Instanciates a new Anchor, setting it to be a deep copy of the rhs Anchor.
	/// </summary>
	/// <param name="rhs">The Anchor of which the new Anchor should be a deep copy.</param>
	public Anchor(Anchor rhs)
	{
	  center   = rhs.center;
	  selected = rhs.selected;
	}

	#endregion

	#region Public Methods

	/// <summary>
	/// Creates and returns a deep copy of this Anchor.
	/// </summary>
	/// <returns>A new Anchor, set to be a deep copy of this Anchor.</returns>
	public Anchor Clone()
	{ return new Anchor(this); }

	/// <summary>
	/// Paints this Anchor on the Graphics g. Takes into consideration
	/// the clip rectangle, scroll offset, and maximum dimensions
	/// provided as parameters. In particular, if the clip rectangle's
	/// top coordinate plus the width of the scroll offset Size is greater than
	/// or equal to the MAX_DRAW_WIDTH value, the Anchor is not drawn. The
	/// same happens if the clip rectangle's left coordinate plus the scroll
	/// offset's height is greater than or equal to the MAX_DRAW_HEIGHT.
	/// When painted in Standard PaintMode, Anchors appear as a square
	/// filled in red and bordered in black. When painted in Outline PaintMode,
	/// Anchors appear as an un-filled square bordered by a blue dashed line.
	/// </summary>
	/// <param name="g">The Graphics over which the Anchor should be painted.</param>
	/// <param name="clipRectangle">The Rectangle defining the clip area that is currently
	/// being painted on the Graphics g.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the Graphics g.</param>
	/// <param name="MAX_DRAW_WIDTH">The Maximum X coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="MAX_DRAW_HEIGHT">The Maximum Y coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="pm">The PaintMode to be used.</param>
	public void Paint(Graphics g, Rectangle clipRectangle, Size scrollOffset,
	  int MAX_DRAW_WIDTH, int MAX_DRAW_HEIGHT, PaintMode pm)
	{	  
	  //Check for clipRectangle + scrollOffset to be in drawable range
	  if (clipRectangle.Top+scrollOffset.Width < MAX_DRAW_WIDTH ||
		clipRectangle.Left+scrollOffset.Height < MAX_DRAW_HEIGHT)
	  {
		//Set up a tmpRectangle with the appropriately modified size:
		PointF tmpP = center;
		tmpP.X-=(ANCHOR_SIZE/2.0f);
		tmpP.Y-=(ANCHOR_SIZE/2.0f);
		RectangleF tmpRectangle = new RectangleF(tmpP+scrollOffset,
		  new SizeF(ANCHOR_SIZE, ANCHOR_SIZE));

		//Depending on the PaintMode:
		switch(pm)
		{
		  case PaintMode.Standard:
			//Fill the rectangle in red,
			//outline the rectangle in black:
			Brush b = new SolidBrush(Color.Red);
			g.FillRectangle(b,
			  tmpRectangle.Left,tmpRectangle.Top, tmpRectangle.Width, tmpRectangle.Height);
			Pen p1 = new Pen(Color.Black);
			g.DrawRectangle(p1,
			  tmpRectangle.Left,tmpRectangle.Top, tmpRectangle.Width, tmpRectangle.Height);
			break;
		  case PaintMode.Outline:
			//outline the rectangle in dashed blue pen:
			Pen p2 = new Pen(Color.Blue, 2);
			p2.DashPattern = new float[] {5, 2};
			g.DrawRectangle(p2,
			  tmpRectangle.Left,tmpRectangle.Top, tmpRectangle.Width, tmpRectangle.Height);
			break;
		  default:
			//Should never happen:
			break;
		}//SWITCH on pm
	  }//IF in max size
	}
	/// <summary>
	/// Verifies whether the given PointF (assumed to be the PointF
	/// where a mouse click event took place) falls within the
	/// Anchor's square. Takes in consideration the given scroll
	/// offset.
	/// </summary>
	/// <param name="cp">The PointF where the click took place.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the component where the Anchor lies.</param>
	/// <returns>true if cp falls within the Anchor's square;
	/// false otherwise.</returns>
	public bool Clicked(PointF cp, Size scrollOffset)
	{
	  //Checks if cp is within the anchor's rectangle.
	  //Make a temporaryRectangle based on the center
	  //the ANCHOR_SIZE, and the scrollOffset
	  PointF tmpP = center;
	  tmpP.X-=(ANCHOR_SIZE/2.0f);
	  tmpP.Y-=(ANCHOR_SIZE/2.0f);
	  RectangleF tmpRectangle = new RectangleF(tmpP+scrollOffset,
		new SizeF(ANCHOR_SIZE, ANCHOR_SIZE));
	  return(	cp.X>=tmpRectangle.Left
		&&		cp.X<=(tmpRectangle.Left+tmpRectangle.Width)
		&&		cp.Y>=tmpRectangle.Top
		&&		cp.Y<=(tmpRectangle.Top+tmpRectangle.Height)  );
	}
	/// <summary>
	/// Saves (Serializes) the Anchor to the stream underneath the XmlTextWriter.
	/// The Anchor is saved as an Element named "Anchor", with two
	/// attributes, X and Y, representing its center's coordinates.
	/// The stream is flushed after the Anchor is serialized.
	/// </summary>
	/// <param name="x">The XmlTextWriter to which the Anchor whould be saved.</param>
	public void SaveTo(XmlTextWriter x)
	{
	  x.WriteStartElement("Anchor", null);
	  x.WriteAttributeString("X", center.X.ToString());
	  x.WriteAttributeString("Y", center.Y.ToString());
	  x.WriteEndElement();
	  x.Flush();
	}
	/// <summary>
	/// Reads (Deserializes) an Anchor from the given XmlTextReader.
	/// </summary>
	/// <param name="x">The XmlTextReader from which the Anchor should be deserialized.</param>
	public void ReadFrom(XmlTextReader x)
	{
	  while(x.MoveToNextAttribute())
	  {
		switch(x.Name)
		{
		  case "X":	  center.X = float.Parse(x.Value);	break;
		  case "Y":	  center.Y = float.Parse(x.Value);	break;
		  default:										break;
		}
	  }//WEND

	}

	#endregion
  }
}
