#region Copyright
/*
 * File Name: UseCase.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Drawing;

using System.Xml;

#endregion

namespace myUML
{
  /// <summary>
  /// The UseCaseAnchors enumeration is defined to describe the various
  /// Anchors of a Usecase:
  /// TopLeft:		The Anchor in the top-left corner of the rectangle surrounding the UseCase
  /// TopMiddle:	The Anchor in the middle of the upper bound of the rectangle surrounding the UseCase
  /// TopRight:		The Anchor in the top-right corner of the rectangle surrounding the UseCase
  /// CenterLeft:	The Anchor in the middle of the left bound of the rectangle surrounding the UseCase
  /// CenterRight:	The Anchor in the middle of the right bound of the rectangle surrounding the UseCase
  /// BottomLeft:	The Anchor in the bottom-left corner of the rectangle surrounding the UseCase
  /// BottomMiddle:	The Anchor in the middle of the lower bound of the rectangle surrounding the UseCase
  /// BottomRight:	The Anchor in the bottom-right corner of the rectangle surrounding the UseCase
  /// None:			None of the above.
  /// </summary>
  public enum UseCaseAnchors
  {
	TopLeft		=0,
	TopMiddle,
	TopRight,
	CenterLeft,
	CenterRight,
	BottomLeft,
	BottomMiddle,
	BottomRight,
	None
  }

  /// <summary>
  /// The UseCase class is defined to provide a representation of a UseCase.
  /// In a UseCase Diagram, a UseCase represents a task to be performed by the
  /// system depicted, possibly with the interaction of one or more Actors.
  /// The UseCase class implements the IUMLtoXML interface.
  /// </summary>
  public class UseCase : IUMLtoXML
  {
	#region Constants

	/// <summary>
	/// The number of Anchors associated with each UseCase.
	/// </summary>
	public const int NUM_USE_CASE_ANCHORS =8;

	#endregion

	#region Static Methods

	/// <summary>
	/// Transforms a given UseCaseAnchors value into its corresponding
	/// integer value.
	/// </summary>
	/// <param name="x">The UseCaseAnchors value to be transformed.</param>
	/// <returns>The integer value corresponding to the x UseCaseAnchors
	/// value; this is in the range [0..NUM_USE_CASE_ANCHORS); -1 is returned
	/// if the given value is unrecognized, or if it is equal to UseCaseAnchors.None.</returns>
	public static int UseCaseAnchorsToInt(UseCaseAnchors x)
	{
	  switch(x)
	  {
		case UseCaseAnchors.TopLeft:	  return 0;
		case UseCaseAnchors.TopMiddle:	  return 1;
		case UseCaseAnchors.TopRight:	  return 2;
		case UseCaseAnchors.CenterLeft:	  return 3;
		case UseCaseAnchors.CenterRight:  return 4;
		case UseCaseAnchors.BottomLeft:	  return 5;
		case UseCaseAnchors.BottomMiddle: return 6;
		case UseCaseAnchors.BottomRight:  return 7;
		case UseCaseAnchors.None:
		default:						  return -1;
	  }
	}
	/// <summary>
	/// Transforms a given integer value into its corresponding UseCaseAnchors
	/// value.
	/// </summary>
	/// <param name="x">The integer value to be transformed.</param>
	/// <returns>The UseCaseAnchors value corresponding to x; this is
	/// defined as follows:
	/// UseCaseAnchors.TopLeft for x=0;
	/// UseCaseAnchors.TopMiddle for x=1;
	/// UseCaseAnchors.TopRight for x=2;
	/// UseCaseAnchors.CenterLeft for x=3;
	/// UseCaseAnchors.CenterRight for x=4;
	/// UseCaseAnchors.BottomLeft for x=5;
	/// UseCaseAnchors.BottomMiddle for x=6;
	/// UseCaseAnchors.BottomRight for x=7;
	/// UseCaseAnchors.None otherwise.
	/// </returns>
	public static UseCaseAnchors IntToUseCaseAnchors(int x)
	{
	  switch(x)
	  {
		case 0:		return UseCaseAnchors.TopLeft;
		case 1:		return UseCaseAnchors.TopMiddle;
		case 2:		return UseCaseAnchors.TopRight;
		case 3:		return UseCaseAnchors.CenterLeft;
		case 4:		return UseCaseAnchors.CenterRight;
		case 5:		return UseCaseAnchors.BottomLeft;
		case 6:		return UseCaseAnchors.BottomMiddle;
		case 7:		return UseCaseAnchors.BottomRight;
		default:	return UseCaseAnchors.None;
	  }
	}

	#endregion

	#region Static Fields

	/// <summary>
	/// The Font used to render any text associated with a UseCase.
	/// </summary>
	public static Font arialFont10 = new Font("Arial", 10);

	#endregion

	#region Protected Data Fields

	/// <summary>
	/// The Array of Anchors associated with the UseCase.
	/// </summary>
	protected	Anchor[]	anchors = new Anchor[NUM_USE_CASE_ANCHORS];
	/// <summary>
	/// The width of the rectangle surrounding the UseCase.
	/// </summary>
	protected	float		width	= 0.0f;
	/// <summary>
	/// The height of the rectangle surrounding the UseCase.
	/// </summary>
	protected	float		height	= 0.0f;
	/// <summary>
	/// A flag indicating whether the Usecase is currently selected or not.
	/// </summary>
	protected	bool		selected= false;
	/// <summary>
	/// A flag indicating whether the UseCase should be filled or not when being rendered.
	/// </summary>
	protected	bool		filled	= false;
	/// <summary>
	/// The Color to be used to fill the UseCase if it is rendered as filled.
	/// </summary>
	protected	Color		color	= Color.Black;
	/// <summary>
	/// A flag indicating whether the UseCase should be rendered as bordered or not.
	/// </summary>
	protected		bool		bordered= true;
	/// <summary>
	/// The Color to be used to render the Usecase's border, if the UseCase is
	/// to be rendered as bordered.
	/// </summary>
	protected		Color		brdColor= Color.Black;
	/// <summary>
	/// The string of text associated with the UseCase.
	/// </summary>
	protected	string		text	= "";
	/// <summary>
	/// The Color to be used in rendering the text associated with the UseCase.
	/// </summary>
	protected	Color		txtColor= Color.Black;

	#endregion

	#region Public Attributes

	/// <summary>
	/// Gets or sets the array of Anchors associated with the UseCase.
	/// Note: this should be modified to prevent setting the Anchors to some
	/// un-acceptable configuration.
	/// </summary>
	public	Anchor	this[UseCaseAnchors x]
	{
	  get
	  {
		if(x==UseCaseAnchors.None)	return null;
		return ((Anchor)anchors[UseCase.UseCaseAnchorsToInt(x)]).Clone();
	  }
	  set
	  {
		if(x!=UseCaseAnchors.None)
		  anchors[UseCase.UseCaseAnchorsToInt(x)]=value.Clone();
	  }
	}
	/// <summary>
	/// Gets or sets the width of the rectangle surrounding the UseCase.
	/// Note that this value cannot be set to any value less than 0.0f.
	/// Also, setting the Width of a UseCase implicitly resets the
	/// UseCase's Anchors accordingly. The top-left Anchor is considered,
	/// for these calculations, as the fixed point of the UseCase.
	/// </summary>
	public	float	Width
	{
	  get { return width; }
	  set
	  {
		if(value>0.0f)
		  width=value;
		else
		  width=0.0f;
		float x = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterX;
		float y = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterY;

		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopMiddle)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopMiddle)].CenterY=y;

		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopRight)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopRight)].CenterY=y;

		x = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterX;
		y+=(height/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterLeft)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterLeft)].CenterY=y;
		x+=width;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterRight)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterRight)].CenterY=y;

		x = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterX;
		y+=(height/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomLeft)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomLeft)].CenterY=y;
		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomMiddle)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomMiddle)].CenterY=y;
		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomRight)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomRight)].CenterY=y;
	  }
	}
	/// <summary>
	/// Gets or sets the height of the rectangle surrounding the UseCase.
	/// Note that this value cannot be set to any value less than 0.0f.
	/// Also, setting the Height of a UseCase implicitly resets the
	/// UseCase's Anchors accordingly. The top-left Anchor is considered,
	/// for these calculations, as the fixed point of the UseCase.
	/// </summary>
	public float	Height
	{
	  get { return height; }
	  set
	  {
		if(value>0.0f)
		  height=value;
		else
		  height=0.0f;
		float x = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterX;
		float y = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterY;

		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopMiddle)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopMiddle)].CenterY=y;

		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopRight)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopRight)].CenterY=y;

		x = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterX;
		y+=(height/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterLeft)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterLeft)].CenterY=y;
		x+=width;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterRight)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterRight)].CenterY=y;

		x = anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].CenterX;
		y+=(height/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomLeft)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomLeft)].CenterY=y;
		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomMiddle)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomMiddle)].CenterY=y;
		x+=(width/2.0f);
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomRight)].CenterX=x;
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomRight)].CenterY=y;
	  }
	}
	/// <summary>
	/// Gets or sets the value indicating whether the UseCase is currently
	/// selected or not.
	/// </summary>
	public	bool	Selected
	{
	  get { return selected;}
	  set { selected=value; }
	}
	/// <summary>
	/// Gets or sets the value indicating whether the UseCase is to be rendered
	/// as filled or not.
	/// </summary>
	public	bool	Filled
	{
	  get { return filled;}
	  set { filled=value; }
	}
	/// <summary>
	/// Gets or sets the Color to be used in filling the UseCase, if it
	/// is to be rendered as filled.
	/// </summary>
	public	Color	Color
	{
	  get { return color;}
	  set { color=value; }
	}
	/// <summary>
	/// Gets or sets the value indicating whether the UseCase should be rendered
	/// as bordered or not.
	/// </summary>
	public bool		Bordered
	{
	  get { return bordered;}
	  set { bordered=value; }
	}
	/// <summary>
	/// Gets or sets the Color tobe used to draw the UseCase's border, if it
	/// is to be rendered as bordered.
	/// </summary>
	public	Color	BrdColor
	{
	  get { return brdColor;}
	  set { brdColor=value; }
	}
	/// <summary>
	/// Gets or sets the text associated with the UseCase.
	/// </summary>
	public	string	Text
	{
	  get { return text;}
	  set { text=value;}
	}
	/// <summary>
	/// Gets or sets the Color to be used in rendering the text associated
	/// with the UseCase, if any.
	/// </summary>
	public	Color	TxtColor
	{
	  get { return txtColor;}
	  set { txtColor=value; }
	}
	/// <summary>
	/// Gets the UseCaseAnchors value indicating which of the Anchors
	/// associated with the UseCase are currently selected.
	/// </summary>
	public	UseCaseAnchors	SelectedAnchor
	{
	  get
	  {
		for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
		  if(anchors[i].Selected) return UseCase.IntToUseCaseAnchors(i);
		return UseCaseAnchors.None;
	  }
	}

	#endregion

	#region Constructors

	/// <summary>
	/// Instanciates a new UseCase, with all of its Anchors set as
	/// default Anchors; by default, a UseCase has no text (but the TxtColor
	/// property is set to Color.Black), is set to be bordered in Color.Black,
	/// and not filled (but its FillColor is set to Color.White).
	/// </summary>
	public UseCase()
	{
	  for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
		anchors[i]=new Anchor();
	}
	/// <summary>
	/// Instanciates a new UseCase with top-left Anchor in the
	/// specified point, and with the given width and height.
	/// </summary>
	/// <param name="inTL">The PointF to be used as top-left Anchor
	/// for the UseCase.</param>
	/// <param name="inW">The Width of the new UseCase.</param>
	/// <param name="inH">The Height of the new UseCase.</param>
	public UseCase(PointF inTL, float inW, float inH)
	{
	  width = inW;
	  height = inH;
	  Anchor ta = new Anchor(inTL);
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)]=ta.Clone();
	  float w2 = width/2.0f;
	  float h2 = height/2.0f;
	  ta.CenterX+=w2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopMiddle)]=ta.Clone();
	  ta.CenterX+=w2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopRight)]=ta.Clone();
	  ta.CenterY+=h2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterRight)]=ta.Clone();
	  ta.CenterY+=h2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomRight)]=ta.Clone();
	  ta.CenterX-=w2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomMiddle)]=ta.Clone();
	  ta.CenterX-=w2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.BottomLeft)]=ta.Clone();
	  ta.CenterY-=h2;
	  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.CenterLeft)]=ta.Clone();
	}
	/// <summary>
	/// Instanciates a new UseCase and sets it to be a deep copy of the
	/// given UseCase.
	/// </summary>
	/// <param name="rhs">The UseCase of which the new UseCase should be
	/// a deep copy.</param>
	public UseCase(UseCase rhs)
	{
	  for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
		anchors[i]=rhs.anchors[i].Clone();
	  width = rhs.width;
	  height= rhs.height;
	  selected = rhs.selected;
	  filled = rhs.filled;
	  color = rhs.color;
	  bordered = rhs.bordered;
	  brdColor = rhs.brdColor;
	  text = rhs.text;
	  txtColor = rhs.txtColor;
	}

	#endregion

	#region Public Methods

	/// <summary>
	/// Creates and returns a new UseCase, set to be a deep copy of this UseCase.
	/// </summary>
	/// <returns>The new UseCase, the deep copy of this UseCase.</returns>
	public UseCase Clone()
	{ return new UseCase(this); }
	/// <summary>
	/// Paints this UseCase on the Graphics g. Takes into consideration
	/// the clip rectangle, scroll offset, and maximum dimensions
	/// provided as parameters. In particular, if the clip rectangle's
	/// top coordinate plus the width of the scroll offset Size is greater than
	/// or equal to the MAX_DRAW_WIDTH value, the UseCase is not drawn. The
	/// same happens if the clip rectangle's left coordinate plus the scroll
	/// offset's height is greater than or equal to the MAX_DRAW_HEIGHT.
	/// When painted in Standard PaintMode, the appearance of UseCases depends
	/// upon its properties:
	/// if the UseCase is to be bordered, an ellipse is rendered, in the Color
	/// specified by the BrdColor property; the ellipse is tangent to the
	/// surrounding rectangle at the top-middle, bottom-middle, center-left
	/// and center-right Anchors;
	/// if the UseCase is to be filled, the ellipse is also filled, in the
	/// Color specified by the Color property;
	/// if the UseCase is selected, the surrounding rectangle is also rendered,
	/// including all of its Anchors;
	/// Text, if any, is rendered in the middle of the ellipse.
	/// If the UseCase is to be painted in Outline PaintMode, only the ellipse
	/// is rendered, in the form of a blue dashed line.
	/// </summary>
	/// <param name="g">The Graphics over which the UseCase should be painted.</param>
	/// <param name="clipRectangle">The Rectangle defining the clip area that is currently
	/// being painted on the Graphics g.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the Graphics g.</param>
	/// <param name="MAX_DRAW_WIDTH">The Maximum X coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="MAX_DRAW_HEIGHT">The Maximum Y coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="pm">The PaintMode to be used.</param>
	public virtual void Paint(Graphics g, Rectangle clipRectangle, Size scrollOffset,
	  int MAX_DRAW_WIDTH, int MAX_DRAW_HEIGHT, PaintMode pm)
	{
	  //Check for clipRectangle + scrollOffset to be in drawable range
	  if (clipRectangle.Top+scrollOffset.Width < MAX_DRAW_WIDTH ||
		clipRectangle.Left+scrollOffset.Height < MAX_DRAW_HEIGHT)
	  {
		RectangleF tmpRectangle = new RectangleF(
		  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].Center+scrollOffset,
		  new SizeF(width, height));

		Pen pen;
		//Depending on the PaintMode:
		switch(pm)
		{
		  case PaintMode.Standard:
			//Filled?
			if(filled)
			{
			  Brush b = new SolidBrush(color);
			  g.FillEllipse(b, tmpRectangle);
			}//IF filled
			//Bordered?
			if(bordered)
			{
			  pen = new Pen(brdColor);
			  g.DrawEllipse(pen, tmpRectangle);
			}//IF bordered
			//Anchor Points (if selected) ?
			if(selected)
			{
			  for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
				anchors[i].Paint(g, clipRectangle, scrollOffset, MAX_DRAW_WIDTH, MAX_DRAW_HEIGHT, pm);
			}//IF selected
			//Text?
			if(text.Length>0)
			{
			  SizeF txtBox = g.MeasureString(text, arialFont10);
			  PointF txtPoint = new PointF(tmpRectangle.Left, tmpRectangle.Top);
			  txtPoint.X+=(width/2.0f);
			  txtPoint.Y+=(height/2.0f);
			  txtPoint.X-=(txtBox.Width/2.0f);
			  txtPoint.Y-=(txtBox.Height/2.0f);
			  g.DrawString(text, new Font("Arial", 10), new SolidBrush(txtColor), txtPoint);
			}//IF text.Length>0
			break;
		  case PaintMode.Outline:
			//Paint online the border in dashed blue pen:
			pen = new Pen(Color.Blue, 2);
			pen.DashPattern = new float[] {5, 2};
			g.DrawEllipse(pen,
			  tmpRectangle.Left, tmpRectangle.Top, tmpRectangle.Width, tmpRectangle.Height);
			break;
		  default:
			//Should never happen.
			break;
		}//SWITCH on pm
	  }//IF clipRectangle+scrollOffset is in drawable range
	}
	/// <summary>
	/// Determines whether the cp PointF (presumably, the PointF where a mouse click
	/// event took place) lies within the UseCase or not (i.e. if it falls within the
	/// rectangle surrounding the UseCase).
	/// </summary>
	/// <param name="cp">The PointF where the click took place.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the component where the UseCase lies.</param>
	/// <returns>true if cp falls within the rectangle surrounding the UseCase;
	/// false otherwise.</returns>
	public bool Clicked(PointF cp, Size scrollOffset)
	{
	  RectangleF tmpR = new RectangleF(
		anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].Center+scrollOffset,
		new SizeF(width, height));

	  return(	cp.X>=tmpR.Left
		&&		cp.X<=(tmpR.Left+tmpR.Width)
		&&		cp.Y>=tmpR.Top
		&&		cp.Y<=(tmpR.Top+tmpR.Height)	);
	}
	/// <summary>
	/// Determines whether the cp PointF (presumably, where a mouse click
	/// event took place) lies within one of the UseCase's Anchors or not.
	/// </summary>
	/// <param name="cp">The PointF where the click took place.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the component where the UseCase lies.</param>
	/// <returns>true, if cp lies within any of the UseCase's Anchors; false otheriwse.</returns>
	public bool ClickedAnchor(PointF cp, Size scrollOffset)
	{
	  //returns true if the click was in one of the anchors:
	  for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
		if(anchors[i].Clicked(cp, scrollOffset))  return true;
	  return false;
	}
	/// <summary>
	/// Determines which of the UseCase's Anchors the PointF (presumably,
	/// where a mouse click event took place) lies in (if any).
	/// </summary>
	/// <param name="cp">The PointF where the click took place.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the component where the UseCase lies.</param>
	/// <returns>The UseCaseAnchors value describing which Anchor the point cp
	/// lies in; this is UseCaseAnchors.None if the point cp does not lie
	/// in any of the UseCase's Anchors. Note that the method assumes there is no overlap
	/// among the various Anchors; if there is overlap, the precedence is given
	/// to the Anchor whose associated integer value (see UseCase.UseCaseAnchorsToInt)
	/// is the lowest.</returns>
	public UseCaseAnchors AnchorClicked(PointF cp, Size scrollOffset)
	{
	  //returns which anchor was clicked:
	  for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
		if(anchors[i].Clicked(cp, scrollOffset))  return UseCase.IntToUseCaseAnchors(i);
	  return UseCaseAnchors.None;
	}
	/// <summary>
	/// Saves (Serializes) the UseCase to the stream underneath the XmlTextWriter.
	/// The UseCase is saved as an Element named "UseCase", with eight
	/// attributes, one for each of the UseCase's properties (Width, Height,
	/// Filled, Color, Bordered, BrdColor, Text, and TxtColor). The dimension
	/// attributes are set to the string representation of their values;
	/// the color attributes are set to the string representation of the
	/// integer representation of the color; the boolean-property attributes are set to
	/// either "True" or "False".
	/// The UseCase Element also has one child Element, named "TopLeft", which
	/// contains the serialized Top-Left Anchor of the UseCase.
	/// The stream is flushed after the UseCase is serialized.
	/// </summary>
	/// <param name="x">The XmlTextWriter to which the UseCase whould be saved.</param>
	public virtual void SaveTo(XmlTextWriter x)
	{
	  x.WriteStartElement("UseCase", null);
	  x.WriteAttributeString("Width", width.ToString());
	  x.WriteAttributeString("Height", height.ToString());
	  x.WriteAttributeString("Filled", filled.ToString());
	  x.WriteAttributeString("Color", color.ToArgb().ToString());
	  x.WriteAttributeString("Bordered", bordered.ToString());
	  x.WriteAttributeString("BrdColor", brdColor.ToArgb().ToString());
	  x.WriteAttributeString("Text", text);
	  x.WriteAttributeString("TxtColor", txtColor.ToArgb().ToString());

	  x.WriteStartElement("TopLeft", null);
	  anchors[0].SaveTo(x);
	  x.WriteEndElement();

	  x.WriteEndElement();

	  x.Flush();
	}
	/// <summary>
	/// Reads (Deserializes) a UseCase from the given XmlTextReader.
	/// </summary>
	/// <param name="x">The XmlTextReader from which the UseCase should be deserialized.</param>
	public virtual void ReadFrom(XmlTextReader x)
	{
	  float w = 0.0f;
	  float h = 0.0f;

	  while(x.MoveToNextAttribute())
	  {
		switch(x.Name)
		{
		  case "Width":		  w = float.Parse(x.Value);			break;
		  case "Height":	  h = float.Parse(x.Value);			break;
		  case "Filled":	  filled=(x.Value==true.ToString());	break;
		  case "Color":		  color = Color.FromArgb(int.Parse(x.Value)); break;
		  case "Bordered":	  bordered = (x.Value==true.ToString());	  break;
		  case "BrdColor":	  brdColor= Color.FromArgb(int.Parse(x.Value));break;
		  case "Text":		  text = x.Value;								break;
		  case "TxtColor":	  txtColor = Color.FromArgb(int.Parse(x.Value));break;
		  default:														  break;
		}
	  }//WEND

	  bool b =  x.Read();
	  if(x.NodeType==XmlNodeType.Element && x.Name=="TopLeft")
	  {
		x.Read();
		anchors[0].ReadFrom(x);
	  }//WEND

	  while(x.NodeType!=XmlNodeType.EndElement)
		x.Read();

	  //Set width and height AFTER the TopLeft corner has been set:
	  this.Width=w;
	  this.Height=h;
	}

	#endregion

  }
}
