#region Copyright
/*
 * File Name: TestUseCases.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using System.Text;
using System.Xml;

#endregion

namespace myUML
{
  /// <summary>
  /// The UseCaseDiagramTool enumeration is defined to describe the
  /// tools available to the user when drawing a Use case Diagram:
  /// None:			No tool, used to indicate that no tools is selected, or that
  ///				the "Pointer" tool is selected;
  /// Communication:The Communication tool, used to draw Communications;
  /// UseCase:		The UseCase tool, used to draw UseCases;
  /// Actor:		The Actor tool, used to draw Actors.
  /// </summary>
  public enum UseCaseDiagramTool
  {
	None,
	Communication,
	UseCase,
	Actor
  }

  /// <summary>
  /// The TestUseCases class is defined to implement an environment where the
  /// user may test and use the myUML classes dealing with Use Case Diagrams.
  /// The clas inherits from the System.Windows.Forms.Form class.
  /// </summary>
  public class TestUseCases : System.Windows.Forms.Form
  {
	#region Constants

	/// <summary>
	/// Constant used to indicate that no figure is currently selected.
	/// </summary>
	private const int	NO_FIGURE_SELECTED			=-1;
	/// <summary>
	/// The index of the image associated with the "New Diagram" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_NEWDIAGRAM		=0;
	/// <summary>
	/// The index of the image associated with the "Open Diagram" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_OPENDIAGRAM		=1;
	/// <summary>
	/// The index of the image associated with the "Save Diagram" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_SAVEDIAGRAM		=2;
	/// <summary>
	/// The index of the image associated with the "Pointer Tool" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_POINTER			=3;
	/// <summary>
	/// The index of the image associated with the "Communication Tool" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_COMMUNICATION	=4;
	/// <summary>
	/// The index of the image associated with the "UseCase Tool" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_USECASE			=5;
	/// <summary>
	/// The index of the image associated with the "Actor Tool" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_ACTORTOOL		=6;
	/// <summary>
	/// The index of the image associated with the "Delete Tool" button
	/// in the toolbar, within the context of the iList_tBarBtnIcons ImageList.
	/// </summary>
	private const int	IMAGE_INDEX_DELETETOOL		=7;
	/// <summary>
	/// The maximum width for the Use Case Diagram.
	/// </summary>
	private const int	MAX_WIDTH					=1024;
	/// <summary>
	/// The maximum height for the Use Case Diagram.
	/// </summary>
	private const int	MAX_HEIGHT					=1024;
	/// <summary>
	/// The horizontal space to be preserved between the right edge of
	/// the pnl_drawable Panel and the right edge of the TestUseCases form.
	/// </summary>
	private const int	PNL_FORM_BUFF_HOR			=400;
	/// <summary>
	/// The difference between the height of the TestUseCases form
	/// and the height of the pnl_drawable Panel.
	/// </summary>
	private const int	PNL_FORM_BUFF_VER			=100;
	/// <summary>
	/// The horizontal space to be preserved between the right edge of
	/// the commDisplay, ucDisplay and acDisplay controls and the right
	/// edge of the TestUseCases form.
	/// </summary>
	private const int	DISPLAY_FORM_BUFF			=280;
	/// <summary>
	/// The vertical coordinate of the Location of the commDisplay, ucDisplay and
	/// acDisplay controls.
	/// </summary>
	private const int	DISPLAY_COORD_Y				=50;
	/// <summary>
	/// The minimum size for a new figure to be drawn.
	/// </summary>
	private const float MIN_FIGURE_SIZE				=6.0f;

	#endregion

	#region Private Data Fields

	/// <summary>
	/// The UseCaseDiagramTool value indicating which drawing tool is currently selected.
	/// </summary>
	private UseCaseDiagramTool	currTool			=UseCaseDiagramTool.None;
	/// <summary>
	/// A flag indicating whether the user is currently drawing a new figure
	/// or not.
	/// </summary>
	private bool				drawing				=false;
	/// <summary>
	/// The PointF where the user started drawing the figure he is currently
	/// drawing; set to (0.0f, 0.0f) when not in use.
	/// </summary>
	private PointF				startPoint			=new PointF(0.0f, 0.0f);
	/// <summary>
	/// The PointF where the mouse was after its last move; used only when the
	/// user is drawing a new figure; set to (0.0f, 0.0f) when not in use.
	/// </summary>
	private PointF				drawingPoint		=new PointF(0.0f, 0.0f);
	/// <summary>
	/// The ArrayList of figures (i.e. Communications, UseCases, and/or Actors)
	/// currently in the Use Case Diagram.
	/// </summary>
	private ArrayList			figures				=new ArrayList();
	/// <summary>
	/// A flag indicating whether the user is currently holding down the
	/// shift key.
	/// </summary>
	private bool				shiftPressed		=false;
	/// <summary>
	/// The number of figures currently selected.
	/// </summary>
	private int					numSelected			=0;
	/// <summary>
	/// Used only when there is a single figure currently selected;
	/// indicates the index, within the figures ArrayList, of the
	/// figure currently selected.
	/// </summary>
	private int					currSelected		=NO_FIGURE_SELECTED;

	#endregion

	#region Private GUI Controls

	private System.Windows.Forms.Panel pnl_drawable;
	private System.Windows.Forms.ImageList iList_tBarBtnIcons;
	private System.Windows.Forms.ToolBar tBar_Tools;
	private System.Windows.Forms.ToolBarButton btn_New;
	private System.Windows.Forms.ToolBarButton btn_Open;
	private System.Windows.Forms.ToolBarButton btn_Save;
	private System.Windows.Forms.ToolBarButton btn_Separator;
	private System.Windows.Forms.ToolBarButton btn_PointerTool;
	private System.Windows.Forms.ToolBarButton btn_CommunicationTool;
	private System.Windows.Forms.ToolBarButton btn_UseCaseTool;
	private System.Windows.Forms.ToolBarButton btn_ActorTool;
	private myUML.CommunicationDisplay commDisplay;
	private myUML.UseCaseDisplay ucDisplay;
	private myUML.ActorDisplay acDisplay;
    private System.Windows.Forms.ToolBarButton btn_Separator_2;
    private System.Windows.Forms.ToolBarButton btn_Delete;
	private System.ComponentModel.IContainer components;

	#endregion

	#region Constructors

	/// <summary>
	/// Instanciates a new TestUseCases form. By default, the
	/// Pointer tool is selected.
	/// </summary>
	public TestUseCases()
	{
	  //
	  // Required for Windows Form Designer support
	  InitializeComponent();

	  //Select the Pointer Tool:
	  this.btn_PointerTool.Pushed=true;
	}

	#endregion

	#region Protected Methods

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
	  if( disposing )
	  {
		if(components != null)
		{
		  components.Dispose();
		}
	  }
	  base.Dispose( disposing );
	}

	#endregion

	#region Private Methods

	/// <summary>
	/// Creates a New Use Case Diagram.
	/// First, it asks the user if he wishes to save the current
	/// Use Case Diagram to file.
	/// </summary>
	private void CreateNewDiagram()
	{
	  DialogResult dr;
	  if(figures.Count>0)
	  {
		dr = MessageBox.Show(this, "Do you wish to save the current Use Case Diagram?",
		  "Before Creating a new Diagram...", MessageBoxButtons.YesNoCancel);
		if(dr==DialogResult.Cancel) return;
		if(dr==DialogResult.Yes)	SaveDiagram();
	  }
	  ClearDiagram();
	}
	/// <summary>
	/// Opens a Use case Diagram from a file.
	/// First, it asks the user if he wishes to save the current
	/// Use Case Diagram to file.
	/// </summary>
	private void OpenDiagram()
	{
	  DialogResult dr;
	  if(figures.Count>0)
	  {
		dr = MessageBox.Show(this, "Do you wish to save the current Use Case Diagram?",
		  "Before Opening a new Diagram...", MessageBoxButtons.YesNoCancel);
		if(dr==DialogResult.Cancel) return;
		if(dr==DialogResult.Yes)	SaveDiagram();
	  }
	  ClearDiagram();

	  OpenFileDialog ofd = new OpenFileDialog();
	  ofd.AddExtension=true;
	  ofd.CheckFileExists=true;
	  ofd.CheckPathExists=true;
	  ofd.DefaultExt="xml";
	  ofd.Filter="XML file (*.xml)|*.xml";
	  ofd.FilterIndex=0;
	  ofd.InitialDirectory="C:\\My Documents";
	  ofd.RestoreDirectory=false;
	  ofd.Title="Open Use Case Diagram...";
	  dr = ofd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		string fn = ofd.FileName;
		try
		{
		  ReadXML(fn);
		}
		catch(Exception e)
		{
		  MessageBox.Show(this, e.Message, "Open Diagram: Error");
		}
	  }
	  //ELSE: do nothing: opening cancelled.

	}
	/// <summary>
	/// Saves the current Use Case Diagram to file.
	/// </summary>
	private void SaveDiagram()
	{
	  SaveFileDialog sfd = new SaveFileDialog();
	  sfd.AddExtension=true;
	  //	  sfd.CheckFileExists=true;
	  sfd.CheckPathExists=true;
	  sfd.CreatePrompt=true;
	  sfd.Filter="XML file (*.xml)|*.xml";
	  sfd.FilterIndex=0;
	  sfd.InitialDirectory="C:\\My Documents";
	  sfd.OverwritePrompt=true;
	  sfd.RestoreDirectory=false;
	  sfd.Title="Save Use Case Diagram...";
	  DialogResult dr = sfd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		string fn = sfd.FileName;
		try
		{
		  SaveXML(fn);
		}
		catch(Exception e)
		{
		  MessageBox.Show(this, e.Message, "Save Diagram: Error");
		}
	  }
	  //ELSE: do nothing: save cancelled
	}
	/// <summary>
	/// Saves the current Use Case Diagram to the specified file,
	/// using XML format.
	/// </summary>
	/// <param name="fn">The name of the file to save the diagram to.</param>
	private void SaveXML(string fn)
	{
	  XmlTextWriter xmlw = null;
	  try
	  {
		xmlw = new XmlTextWriter(fn, null);

		//Write header:
		xmlw.Formatting=Formatting.Indented;
		xmlw.WriteStartDocument(false);
		xmlw.WriteStartElement("UseCaseDiagram", null);
		xmlw.Flush();

		foreach(IUMLtoXML fig in figures)
		  fig.SaveTo(xmlw);
	  }
	  catch(Exception e)
	  {
		StringBuilder sb = new StringBuilder("An Error occurred while saving the Use Case Diagram\n");
		sb.Append("to the specified file ('");
		sb.Append(fn);
		sb.Append("')\nDetails:\n");
		sb.Append(e.ToString());
		throw new ApplicationException(sb.ToString());
	  }
	  finally
	  {
		if(xmlw!=null)
		{
		  xmlw.Flush();
		  xmlw.Close();
		}
	  }
	}
	/// <summary>
	/// Reads a Use case Diagram from the specified file.
	/// </summary>
	/// <param name="fn">The name of the file to be read.</param>
	private void ReadXML(string fn)
	{
	  XmlTextReader xmlr = null;
	  try
	  {
		xmlr = new XmlTextReader(fn);
		xmlr.WhitespaceHandling=WhitespaceHandling.None;
		while(xmlr.Read())
		{
		  switch(xmlr.NodeType)
		  {
			case XmlNodeType.Element:
			switch(xmlr.Name)
			{
			  case "Communication":
				Communication tmpC = new Communication();
				tmpC.ReadFrom(xmlr);
				figures.Add(tmpC);
				break;
			  case "UseCase":
				UseCase tmpUC = new UseCase();
				tmpUC.ReadFrom(xmlr);
				figures.Add(tmpUC);
				break;
			  case "Actor":
				Actor tmpA = new Actor();
				tmpA.ReadFrom(xmlr);
				figures.Add(tmpA);
				break;
			  default:
				break;
			}//SWITCH on Element's Name
			  break;
			default:
			  break;
		  }//SWITCH
		}//WEND
	  }
	  catch(Exception e)
	  {
		StringBuilder sb = new StringBuilder("An Error occurred while opening the Use Case Diagram\n");
		sb.Append("from the specified file ('");
		sb.Append(fn);
		sb.Append("')\nDetails:\n");
		sb.Append(e.ToString());
		throw new ApplicationException(sb.ToString());
	  }
	  finally
	  {
		if(xmlr!=null)
		  xmlr.Close();
		this.pnl_drawable.Invalidate();
	  }
	}
	/// <summary>
	/// Clears the Use Case Diagram displayed by the TestUseCases from.
	/// </summary>
	private void ClearDiagram()
	{
	  this.figures.Clear();
	  currSelected=NO_FIGURE_SELECTED;
	  numSelected=0;
	  DisposeDisplays();
	  this.btn_Delete.Enabled=false;
	  this.btn_Delete.Visible=false;
	  this.pnl_drawable.Invalidate();
	}
	/// <summary>
	/// Hides the commDisplay, ucDisplay, and acDisplay and
	/// disables them.
	/// </summary>
	private void DisposeDisplays()
	{
	  //Ensure we don't display the display:
	  if(commDisplay.Visible)
	  {
		commDisplay.Enabled=false;
		commDisplay.Visible=false;
	  }
	  if(ucDisplay.Visible)
	  {
		ucDisplay.Enabled=false;
		ucDisplay.Visible=false;
	  }
	  if(acDisplay.Visible)
	  {
		acDisplay.Enabled=false;
		acDisplay.Visible=false;
	  }
	}
	/// <summary>
	/// Determines the index (within the figures ArrayList)
	/// of the first selected figure.
	/// </summary>
	/// <returns>the index of the first selected figure in the figures ArrayList,
	/// or -1 if no figure in the ArrayList is selected.</returns>
	private int SelectedIndex()
	{
	  int x = -1;
	  foreach(object o in figures)
	  {
		x++;
		if(o is Communication)
		{
		  Communication tmpC = o as Communication;
		  if(tmpC.Selected)	return x;
		}
		else if(o is Actor)
		{
		  Actor tmpA = o as Actor;
		  if(tmpA.Selected)	return x;
		}
		else if(o is UseCase)
		{
		  UseCase tmpUC = o as UseCase;
		  if(tmpUC.Selected)  return x;
		}
	  }
	  return -1;
	}
	/// <summary>
	/// Deletes from the diagram any figure currently selected.
	/// </summary>
	private void DeleteSelectedFigures()
	{
	  int L = figures.Count;
	  for(int i=0; i<L; i++)
	  {
		object o = figures[i];
		if(o is Communication)
		{
		  Communication tmpC = o as Communication;
		  if(tmpC.Selected)
		  {
			figures.RemoveAt(i);
			i--;
			L--;
		  }
		}
		else if (o is Actor)
		{
		  Actor tmpA = o as Actor;
		  if(tmpA.Selected)
		  {
			figures.RemoveAt(i);
			i--;
			L--;
		  }
		}
		else if (o is UseCase)
		{
		  UseCase tmpUC = o as UseCase;
		  if(tmpUC.Selected)
		  {
			figures.RemoveAt(i);
			i--;
			L--;
		  }
		}
	  }//FOR

	  this.btn_Delete.Enabled=false;
	  this.btn_Delete.Visible=false;
	  numSelected=0;
	  currSelected=NO_FIGURE_SELECTED;
	  //Clear Display:
	  DisposeDisplays();
	  this.pnl_drawable.Invalidate();
	}
	/// <summary>
	/// Clears all of the selected figures; affects the
	/// numSelected and currSelected privates, and ensures that the
	/// commDisplay, ucDisplay and acDisplay are hidden and disabled.
	/// </summary>
	private void ClearSelections()
	{
	  //	  MessageBox.Show(this, "Clearing Selections");
	  foreach(object o in figures)
	  {
		if(o is Communication)
		  ((Communication)o).SetSelectedAnchor(CommunicationAnchors.All, false);
		else if(o is Actor)
		  ((Actor)o).Selected=false;
		else if(o is UseCase)
		  ((UseCase)o).Selected=false;
	  }//FOR
	  numSelected=0;
	  currSelected=NO_FIGURE_SELECTED;
	  //Clear Display:
	  DisposeDisplays();
	}
	/// <summary>
	/// Updates the currently selected figure in the figures ArrayList
	/// as specified by the given object.
	/// </summary>
	/// <param name="o">The updated figure.</param>
	private void UpdateFigure(object o)
	{
	  if(o is Communication)
	  {
		Communication tmpC = o as Communication;
		tmpC.SetSelectedAnchor(CommunicationAnchors.All, true);
		this.figures[currSelected]=tmpC;
	  }
	  else if(o is Actor)
	  {
		//This currently never happens!
		Actor tmpA = o as Actor;
		tmpA.Selected=true;
		this.figures[currSelected] = tmpA;
	  }
	  else if(o is UseCase)
	  {
		UseCase tmpUC = o as UseCase;
		tmpUC.Selected=true;
		this.figures[currSelected]=tmpUC;
	  }
	  else	return;	//Should never happen

	  this.pnl_drawable.Invalidate();
	}


	#region Handle GUI Controls events

	/// <summary>
	/// Handles button clicks on the tBar_Tools toolbar.
	/// The appearance of the tool bar buttons is appropriately changed,
	/// and the currently selected tool is updated.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void tBar_Tools_ButtonClick(object sender,
	  System.Windows.Forms.ToolBarButtonClickEventArgs e)
	{
	  switch(e.Button.ImageIndex)
	  {
		case IMAGE_INDEX_NEWDIAGRAM:
		  CreateNewDiagram();
		  break;
		case IMAGE_INDEX_OPENDIAGRAM:
		  OpenDiagram();
		  break;
		case IMAGE_INDEX_SAVEDIAGRAM:
		  SaveDiagram();
		  break;
		case IMAGE_INDEX_POINTER:
		  this.btn_PointerTool.Pushed=true;
		  this.btn_CommunicationTool.Pushed=false;
		  this.btn_UseCaseTool.Pushed=false;
		  this.btn_ActorTool.Pushed=false;
		  currTool = UseCaseDiagramTool.None;
		  break;
		case IMAGE_INDEX_COMMUNICATION:
		  this.btn_CommunicationTool.Pushed=true;
		  this.btn_UseCaseTool.Pushed=false;
		  this.btn_PointerTool.Pushed=false;
		  this.btn_ActorTool.Pushed=false;
		  currTool = UseCaseDiagramTool.Communication;
		  break;
		case IMAGE_INDEX_USECASE:
		  this.btn_UseCaseTool.Pushed=true;
		  this.btn_PointerTool.Pushed=false;
		  this.btn_CommunicationTool.Pushed=false;
		  this.btn_ActorTool.Pushed=false;
		  currTool = UseCaseDiagramTool.UseCase;
		  break;
		case IMAGE_INDEX_ACTORTOOL:
		  this.btn_ActorTool.Pushed=true;
		  this.btn_PointerTool.Pushed=false;
		  this.btn_CommunicationTool.Pushed=false;
		  this.btn_UseCaseTool.Pushed=false;
		  currTool = UseCaseDiagramTool.Actor;
		  break;
		case IMAGE_INDEX_DELETETOOL:
		  DeleteSelectedFigures();
		  break;
		default:
		  //Do nothing: should never happen, and also
		  //covers the case for IMAGE_INDEX_NOIMAGE.
		  break;
	  }//SWITCH on Clicked Buttons' ImageIndex
	}
	/// <summary>
	/// Handles the Resize event of the TestUseCases form by
	/// adjusting the width and height of the pnl_drawable Panel
	/// and the commDisplay, ucDisplay and acDisplay (if visible).
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void TestUseCases_Resize(object sender, System.EventArgs e)
	{
	  //Resize the panel according to the new dimensions:
	  int newW = this.Width;
	  int newH = this.Height;

	  if(newW<0)  newW=0;
	  if(newH<0)  newH=0;

	  if(commDisplay.Visible)
	  {
		commDisplay.Location=new Point((newW-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
	  }
	  if(ucDisplay.Visible)
	  {
		ucDisplay.Location=new Point((newW-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
	  }
	  if(acDisplay.Visible)
	  {
		acDisplay.Location=new Point((newW-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
	  }

	  newW-=PNL_FORM_BUFF_HOR;
	  newH-=PNL_FORM_BUFF_VER;

	  this.pnl_drawable.Width=newW;
	  this.pnl_drawable.Height=newH;
	}
	/// <summary>
	/// Handles a MouseDown event on the pbl_Drawable Panel.
	/// If the user was not drawing, and this is a single click, and there
	/// is some drawing tool currently selected, a new drawing is started.
	/// Otherwise, the method checks if the user clicked on some figure.
	/// Depending on the results of this check, and whether the user is
	/// holding the shift key or not, the figure may be selected or not.
	/// The commDisplay, ucDisplay, and acDisplay controls are updated
	/// accordingly.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void pnl_drawable_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
	{
	  //Start a drawing only if we are not drawing already,
	  //and this was a single click, and some drawing tool is selected:
	  if(	(!drawing)
		&&	(e.Clicks==1)
		&&	(currTool!=UseCaseDiagramTool.None)
		)
	  {
		//Set the startPoint :
		startPoint = new PointF(e.X, e.Y);
		//Mark we are drawing:
		drawing=true;
	  }
	  else if(	(!drawing)
		&&		(e.Clicks==1)
		&&		(currTool==UseCaseDiagramTool.None)
		)
	  {
		//Check if the click selected some figure:
		//stop as soon as one such figure is found
		//starting from the last one in the figures ArrayList:
		Size scrollOffset = new Size(this.pnl_drawable.AutoScrollPosition);
		PointF clickP = new PointF(e.X, e.Y);

		bool  gotone=false;
		int	  gotndex=-1;
		CommunicationAnchors ca = CommunicationAnchors.None;

		for(int i=figures.Count-1; i>=0; i--)
		{
		  object o = figures[i];
		  if(o is Communication)
		  {
			Communication tmpC = o as Communication;
			ca = tmpC.ClickedWhich(clickP, scrollOffset);
			if(ca!=CommunicationAnchors.None)
			{
			  gotone=true;
			  gotndex=i;
			  break;
			}
		  }
		  else if (o is UseCase)
		  {
			UseCase tmpUC = o as UseCase;
			if(tmpUC.Clicked(clickP, scrollOffset))
			{
			  gotone=true;
			  gotndex=i;
			  break;
			}
		  }
		  else if(o is Actor)
		  {
			Actor tmpA = o as Actor;
			if(tmpA.Clicked(clickP, scrollOffset))
			{
			  gotone=true;
			  gotndex=i;
			  break;
			}
		  }
		  //ELSE: do nothing, this should never happen!
		}//FOR

		if((!gotone) && (!shiftPressed))
		  ClearSelections();
		else if(gotone)
		{
		  object o = figures[gotndex];
		  if(o is Communication)
		  {
			Communication tmpC = o as Communication;
			if(tmpC.Selected)
			{
			  tmpC.SetSelectedAnchor(CommunicationAnchors.All, false);
			  numSelected--;
			}
			else
			{
			  if(!shiftPressed)
				ClearSelections();
			  tmpC.SetSelectedAnchor(ca, true);
			  numSelected++;
			}
		  }
		  else if (o is Actor)
		  {
			Actor tmpA = o as Actor;
			if(tmpA.Selected)
			{
			  tmpA.Selected=false;
			  numSelected--;
			}
			else
			{
			  if(!shiftPressed)
				ClearSelections();
			  tmpA.Selected=true;
			  numSelected++;
			}
		  }
		  else if(o is UseCase)
		  {
			UseCase tmpUC = o as UseCase;
			if(tmpUC.Selected)
			{
			  tmpUC.Selected=false;
			  numSelected--;
			}
			else
			{
			  if(!shiftPressed)
			  {
				ClearSelections();
			  }
			  tmpUC.Selected=true;
			  numSelected++;
			}
		  }
		}//ELSE (gotone)

		DisposeDisplays();

		//Check if we should diplay a CommunicationDisplay or
		//a UseCaseDisplay:
		if(numSelected==1)
		{
		  int x = SelectedIndex();
		  object o = figures[x];
		  if(o is Communication)
		  {
			Communication tmpC = o as Communication;
			commDisplay.Communication=tmpC;
			commDisplay.Location=new Point((this.Width-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
			commDisplay.Visible=true;
			commDisplay.Enabled=true;
		  }
		  else if (o is Actor)
		  {
			Actor tmpA = o as Actor;
			acDisplay.Actor=tmpA;
			acDisplay.Location=new Point((this.Width-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
			acDisplay.Visible=true;
			acDisplay.Enabled=true;
		  }
		  else if (o is UseCase)
		  {
			UseCase tmpUC = o as UseCase;
			ucDisplay.UseCase=tmpUC;
			ucDisplay.Location=new Point((this.Width-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
			ucDisplay.Visible=true;
			ucDisplay.Enabled=true;
		  }
		  currSelected=x;
		}
		this.pnl_drawable.Invalidate();

	  }

	  if (numSelected<1)
	  {
		//hide the deletion button:
		this.btn_Delete.Enabled=false;
		this.btn_Delete.Visible=false;
	  }
	  else
	  {
		this.btn_Delete.Enabled=true;
		this.btn_Delete.Visible=true;
	  }
	}
	/// <summary>
	/// Handles a MouseMove event of the pnl_drawable Panel.
	/// If the user is drawing a new figure, the drawingPoint PointF is
	/// updated to the current position of the mouse, and the panel is
	/// Invalidated.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void pnl_drawable_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
	{
	  if(drawing)
	  {
		//Set the drawingPoint:
		drawingPoint = new PointF(e.X, e.Y);

		//Ask for GUI refresh:
		this.pnl_drawable.Invalidate();
	  }//IF drawing
	  //ELSE: do nothing
	}
	/// <summary>
	/// Handles a MouseUp event on the pnl_drawable Panel.
	/// If the user is drawing a new figure, this indicates that the
	/// user has finished drawing. If the figure is large enough
	/// (i.e. the difference between the startPoint where the figure was
	/// started and the current point where the mouse has been released is
	/// greater than or equal to the MIN_FIGURE_SIZE constant), the new
	/// figure is created and added to the figures ArrayList. By default,
	/// the figure is selected and the pnl_drawable Panel Invalidated.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void pnl_drawable_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
	{
	  if(drawing)
	  {
		if(currTool!=UseCaseDiagramTool.None)
		{
		  //Set the endPoint:
		  PointF endPoint = new PointF(e.X, e.Y);

		  //Get the scroll offset (used to adjust the Points' coordinates):
		  SizeF scrollOffset = new SizeF(this.pnl_drawable.AutoScrollPosition);

		  //Variable used in more than one case:
		  float minx=0.0f;
		  float maxx=0.0f;
		  float miny=0.0f;
		  float maxy=0.0f;
		  float theW=0.0f;
		  float theH=0.0f;

		  //Add a new figure to the figures ArrayList: only if the
		  //startPoint and endPoint are at least MIN_FIGURE_SIZE away:
		  float delta = PointDiff(startPoint, endPoint);

		  if(delta>=MIN_FIGURE_SIZE)
		  {
			//Clear Selections:
			ClearSelections();

			switch(currTool)
			{
			  case UseCaseDiagramTool.Communication:
				//Make a new Communication: adjust the Points' coordinates
				//with the scroll offset.
				Communication tmpC = new Communication();
				tmpC.Start=new Anchor(new PointF(startPoint.X-scrollOffset.Width,
				  startPoint.Y-scrollOffset.Height));
				tmpC.End =new Anchor(new PointF(endPoint.X-scrollOffset.Width,
				  endPoint.Y-scrollOffset.Height));
				tmpC.Mid=myUML.Anchor.MidAnchor(tmpC.Start, tmpC.End);
				tmpC.SetSelectedAnchor(CommunicationAnchors.All, true);
				commDisplay.Communication=tmpC;
				commDisplay.Location=new Point((this.Width-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
				commDisplay.Visible=true;
				commDisplay.Enabled=true;
				figures.Add(tmpC);
				break;
			  case UseCaseDiagramTool.UseCase:
				//Make a new UseCase: adjust the Points' coordinates
				//with the scroll offset; use the lowest (X,Y) pair as root, and
				//calculate the width and height:

				startPoint.X=(startPoint.X-scrollOffset.Width);
				startPoint.Y=(startPoint.Y-scrollOffset.Height);
				endPoint.X=(endPoint.X-scrollOffset.Width);
				endPoint.Y=(endPoint.Y-scrollOffset.Height);

				minx = Math.Min(startPoint.X, endPoint.X);
				maxx = Math.Max(startPoint.X, endPoint.X);
				miny = Math.Min(startPoint.Y, endPoint.Y);
				maxy = Math.Max(startPoint.Y, endPoint.Y);

				theW = (maxx-minx);
				theH = (maxy-miny);
				UseCase tmpUC = new UseCase(new PointF(minx, miny), theW, theH);
				tmpUC.Selected=true;
				ucDisplay.UseCase=tmpUC;
				ucDisplay.Location=new Point((this.Width-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
				ucDisplay.Visible=true;
				ucDisplay.Enabled=true;
				figures.Add(tmpUC);
				break;
			  case UseCaseDiagramTool.Actor:
				//Make a new Actor: adjust the Points' coordinates
				//with the scroll offset; use the lowest (X,Y) pair as root, and
				//calculate the width and height:
				startPoint.X=(startPoint.X-scrollOffset.Width);
				startPoint.Y=(startPoint.Y-scrollOffset.Height);
				endPoint.X=(endPoint.X-scrollOffset.Width);
				endPoint.Y=(endPoint.Y-scrollOffset.Height);

				minx = Math.Min(startPoint.X, endPoint.X);
				maxx = Math.Max(startPoint.X, endPoint.X);
				miny = Math.Min(startPoint.Y, endPoint.Y);
				maxy = Math.Max(startPoint.Y, endPoint.Y);

				theW = (maxx-minx);
				theH = (maxy-miny);
				Actor tmpA = new Actor(new PointF(minx, miny), theW, theH);
				tmpA.Selected=true;
				acDisplay.Actor=tmpA;
				acDisplay.Location=new Point((this.Width-DISPLAY_FORM_BUFF), DISPLAY_COORD_Y);
				acDisplay.Visible=true;
				acDisplay.Enabled=true;
				figures.Add(tmpA);
				break;
			  default:
				//Do nothing: this should never happen;
				//it also covers the case for UseCaseDiagramTool.None
				break;
			}//SWITCH on currTool
		  }//IF delta>=MIN_FIGURE_SIZE

		  //Reset the startPoint and drawingPoint
		  startPoint = new PointF(0.0f, 0.0f);
		  drawingPoint = new PointF(0.0f, 0.0f);
		}//IF currTool!=DrawingTool.NONE
		//ELSE: do nothing: this should never happen!

		//Stop drawing:
		drawing=false;

		currSelected=(figures.Count-1);
		numSelected=1;
		this.btn_Delete.Enabled=true;
		this.btn_Delete.Visible=true;

		//Ask for a GUI refresh:
		this.pnl_drawable.Invalidate();

	  }//IF drawing
	  //ELSE: do nothing.
	}
	/// <summary>
	/// Handles a Paint event on the pnl_drawable Panel.
	/// ALl of the figures in the figures ArrayList are considered for
	/// painting (depending on their position and size).
	/// Additionally, if the user is drawing a new figure, the outline
	/// of the new figure is painted.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void pnl_drawable_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
	{
	  Graphics g = e.Graphics;
	  Size scrollOffset = new Size(this.pnl_drawable.AutoScrollPosition);

	  //Keep track of the largest X and Y found among the figures:
	  float topX=0.0f;
	  float topY=0.0f;

	  //For each Figure in the figures ArrayList:
	  foreach(object o in figures)
	  {
		//Check what the figure is:
		if(o is Communication)
		{
		  Communication tmpC = o as Communication;
		  tmpC.Paint(g, e.ClipRectangle, scrollOffset, MAX_WIDTH, MAX_HEIGHT, PaintMode.Standard);

		  topX=Math.Max(topX, tmpC.Start.CenterX);
		  topX=Math.Max(topX, tmpC.End.CenterX);
		  topY=Math.Max(topY, tmpC.Start.CenterY);
		  topY=Math.Max(topY, tmpC.End.CenterY);
		}
		else if(o is UseCase)
		{
		  UseCase tmpUC = o as UseCase;
		  tmpUC.Paint(g, e.ClipRectangle, scrollOffset, MAX_WIDTH, MAX_HEIGHT, PaintMode.Standard);

		  topX=Math.Max(topX, tmpUC[UseCaseAnchors.TopLeft].CenterX+tmpUC.Width);
		  topY=Math.Max(topY, tmpUC[UseCaseAnchors.TopLeft].CenterY+tmpUC.Height);
		}
		else if(o is Actor)
		{
		  Actor tmpA = o as Actor;
		  tmpA.Paint(g, e.ClipRectangle, scrollOffset, MAX_WIDTH, MAX_HEIGHT, PaintMode.Standard);

		  topX=Math.Max(topX, tmpA[UseCaseAnchors.TopLeft].CenterX+tmpA.Width);
		  topY=Math.Max(topY, tmpA[UseCaseAnchors.TopLeft].CenterY+tmpA.Height);
		}
		//ELSE: do nothing: this should never happen.
	  }//FOREACH Figure in figures

	  //Also Take care of the element being drawn, if we are drawing:
	  if(drawing)
	  {
		//Check for clipRectangle + scrollOffset to be in drawable range
		if (e.ClipRectangle.Top+scrollOffset.Width < MAX_WIDTH ||
		  e.ClipRectangle.Left+scrollOffset.Height < MAX_HEIGHT)
		{
		  //Keep track of the largest X and Y coordinate:
		  topX = Math.Max(topX, startPoint.X);
		  topX = Math.Max(topX, drawingPoint.X);
		  topY = Math.Max(topY, startPoint.Y);
		  topY = Math.Max(topY, drawingPoint.Y);

		  //Variable used in more than one case:
		  float minx=0.0f;
		  float maxx=0.0f;
		  float miny=0.0f;
		  float maxy=0.0f;
		  float theW=0.0f;
		  float theH=0.0f;
		  PointF tmpStart;
		  PointF tmpEnd;

		  //Depending on what's being drawn:
		  switch(currTool)
		  {
			case UseCaseDiagramTool.Communication:
			  //Make a temporary Communication, using the startPoint
			  //and drawingPoint adjusted by the scroll offset:
			  Communication tmpC = new Communication();
			  tmpC.Start=new Anchor(new PointF(startPoint.X-scrollOffset.Width,
				startPoint.Y-scrollOffset.Height));
			  tmpC.End =new Anchor(new PointF(drawingPoint.X-scrollOffset.Width,
				drawingPoint.Y-scrollOffset.Height));

			  //Draw it as a selection one:
			  tmpC.Paint(g, e.ClipRectangle, scrollOffset, MAX_WIDTH, MAX_HEIGHT, PaintMode.Outline);
			  break;
			case UseCaseDiagramTool.UseCase:
			  //Make a temporary Use Case, using the startPoint and drawingPoint
			  //coordinates, adjusted by scrollOffset; use the lowest (X,Y) pair
			  //as root, and caluclate the width and height:

			  tmpStart = startPoint;
			  tmpStart.X=(tmpStart.X-scrollOffset.Width);
			  tmpStart.Y=(tmpStart.Y-scrollOffset.Height);
			  tmpEnd = drawingPoint;
			  tmpEnd.X=(tmpEnd.X-scrollOffset.Width);
			  tmpEnd.Y=(tmpEnd.Y-scrollOffset.Height);

			  minx = Math.Min(tmpStart.X, tmpEnd.X);
			  maxx = Math.Max(tmpStart.X, tmpEnd.X);
			  miny = Math.Min(tmpStart.Y, tmpEnd.Y);
			  maxy = Math.Max(tmpStart.Y, tmpEnd.Y);

			  theW = (maxx-minx);
			  theH = (maxy-miny);

			  UseCase tmpUC = new UseCase(new PointF(minx, miny), theW, theH);

			  //Draw it as a selection one:
			  tmpUC.Paint(g, e.ClipRectangle, scrollOffset, MAX_WIDTH, MAX_HEIGHT, PaintMode.Outline);
			  break;
			case UseCaseDiagramTool.Actor:
			  //Make a temporary Actor, using the startPoint and drawingPoint
			  //coordinates, adjusted by scrollOffset; use the lowest (X,Y) pair
			  //as root, and caluclate the width and height:
			  tmpStart = startPoint;
			  tmpStart.X=(tmpStart.X-scrollOffset.Width);
			  tmpStart.Y=(tmpStart.Y-scrollOffset.Height);
			  tmpEnd = drawingPoint;
			  tmpEnd.X=(tmpEnd.X-scrollOffset.Width);
			  tmpEnd.Y=(tmpEnd.Y-scrollOffset.Height);

			  minx = Math.Min(tmpStart.X, tmpEnd.X);
			  maxx = Math.Max(tmpStart.X, tmpEnd.X);
			  miny = Math.Min(tmpStart.Y, tmpEnd.Y);
			  maxy = Math.Max(tmpStart.Y, tmpEnd.Y);

			  theW = (maxx-minx);
			  theH = (maxy-miny);

			  Actor tmpA = new Actor(new PointF(minx, miny), theW, theH);

			  //Draw it as a selection one:
			  tmpA.Paint(g, e.ClipRectangle, scrollOffset, MAX_WIDTH, MAX_HEIGHT, PaintMode.Outline);
			  break;
			default:
			  //Do nothing: this should never happen;
			  //also covers the case for UseCaseDiagramTool.None
			  break;
		  }//SWITCH on currTool
		}//IF clipRectangle+scrollOffset is in drawable range
	  }//IF drawing
	  //ELSE: do nothing.

	  //If topX or topY are >0, add 10 to them as buffer between the image element and the
	  //end of the panel:
	  if(topX>0.0f)  topX+=10.0f;
	  if(topY>0.0f)  topY+=10.0f;

	  //Set the AutoScrollMinSize according to topX and topY:
	  this.pnl_drawable.AutoScrollMinSize=new Size((int)Math.Ceiling(topX), (int)Math.Ceiling(topY));
	}
	/// <summary>
	/// Handles a KeyDown event on the TestUseCases form.
	/// In particular, it checks whether the Shift key is being pressed.
	/// If so, it sets the shiftPressed flag.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void TestUseCases_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
	{
	  if(e.Shift) shiftPressed=true;
	  e.Handled=false;
	}
	/// <summary>
	/// Handles a KeyUp event on the TestUseCases form.
	/// In particular, it sets the shiftPressed flag based upon the
	/// KeyEventArgs.Shift property (i.e. if the shift key is now released, it
	/// sets the flag to false).
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The event's arguments.</param>
	private void TestUseCases_KeyUp(object sender, System.Windows.Forms.KeyEventArgs e)
	{
	  shiftPressed=e.Shift;
	}

	#region Handler for events fired by CommunicationDisplay, UseCaseDisplay and ActorDisplay

	/*
	 * All of the following event handlers work the same way:
	 * They get the updated COmmunication/UseCase/Actor from the
	 * (respectively) commDisplay, ucDisplay, or acDisplay, and rely upon
	 * the UpdateFigure method to update the figure and repaint the
	 * pnl_drawable Panel accordingly.
	 * 
	 */

	private void ucDisplay_UseCaseBorderColorChanged(object sender,
	  myUML.UseCaseColorChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseBorderedChanged(object sender,
	  myUML.UseCaseBorderedChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseColorChanged(object sender,
	  myUML.UseCaseColorChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseLocationChanged(object sender,
	  myUML.UseCaseLocationChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseResized(object sender,
	  myUML.UseCaseResizeEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseTextChanged(object sender,
	  myUML.UseCaseTextChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseTextColorChanged(object sender,
	  myUML.UseCaseColorChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void ucDisplay_UseCaseFilledChanged(object sender,
	  myUML.UseCaseFilledChangedEventArgs e)
	{
	  UpdateFigure(ucDisplay.UseCase);
	}

	private void commDisplay_ArrowsChanged(object sender,
	  myUML.ArrowsChangedEventArgs e)
	{
	  UpdateFigure(commDisplay.Communication);
	}

	private void commDisplay_ColorChanged(object sender,
	  myUML.ColorChangedEventArgs e)
	{
	  UpdateFigure(commDisplay.Communication);
	}

	private void commDisplay_PointCoordChanged(object sender,
	  myUML.PointCoordChangedEventArgs e)
	{
	  UpdateFigure(commDisplay.Communication);
	}

	private void acDisplay_ActorBorderColorChanged(object sender,
	  myUML.ActorColorChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorBorderedChanged(object sender,
	  myUML.ActorBorderedChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorColorChanged(object sender,
	  myUML.ActorColorChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorLocationChanged(object sender,
	  myUML.ActorLocationChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorResized(object sender,
	  myUML.ActorResizeEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorTextChanged(object sender,
	  myUML.ActorTextChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorTextColorChanged(object sender,
	  myUML.ActorColorChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	private void acDisplay_ActorFilledChanged(object sender,
	  myUML.ActorFilledChangedEventArgs e)
	{
	  UpdateFigure(acDisplay.Actor);
	}

	#endregion

	#endregion


	#endregion


		#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.components = new System.ComponentModel.Container();
	  System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TestUseCases));
	  this.pnl_drawable = new System.Windows.Forms.Panel();
	  this.iList_tBarBtnIcons = new System.Windows.Forms.ImageList(this.components);
	  this.tBar_Tools = new System.Windows.Forms.ToolBar();
	  this.btn_New = new System.Windows.Forms.ToolBarButton();
	  this.btn_Open = new System.Windows.Forms.ToolBarButton();
	  this.btn_Save = new System.Windows.Forms.ToolBarButton();
	  this.btn_Separator = new System.Windows.Forms.ToolBarButton();
	  this.btn_PointerTool = new System.Windows.Forms.ToolBarButton();
	  this.btn_CommunicationTool = new System.Windows.Forms.ToolBarButton();
	  this.btn_UseCaseTool = new System.Windows.Forms.ToolBarButton();
	  this.btn_ActorTool = new System.Windows.Forms.ToolBarButton();
	  this.commDisplay = new myUML.CommunicationDisplay();
	  this.ucDisplay = new myUML.UseCaseDisplay();
	  this.acDisplay = new myUML.ActorDisplay();
	  this.btn_Separator_2 = new System.Windows.Forms.ToolBarButton();
	  this.btn_Delete = new System.Windows.Forms.ToolBarButton();
	  this.SuspendLayout();
	  // 
	  // pnl_drawable
	  // 
	  this.pnl_drawable.AutoScroll = true;
	  this.pnl_drawable.AutoScrollMargin = new System.Drawing.Size(5, 5);
	  this.pnl_drawable.BackColor = System.Drawing.Color.White;
	  this.pnl_drawable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_drawable.Location = new System.Drawing.Point(20, 50);
	  this.pnl_drawable.Name = "pnl_drawable";
	  this.pnl_drawable.Size = new System.Drawing.Size(400, 400);
	  this.pnl_drawable.TabIndex = 0;
	  this.pnl_drawable.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnl_drawable_MouseUp);
	  this.pnl_drawable.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl_drawable_Paint);
	  this.pnl_drawable.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnl_drawable_MouseMove);
	  this.pnl_drawable.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnl_drawable_MouseDown);
	  // 
	  // iList_tBarBtnIcons
	  // 
	  this.iList_tBarBtnIcons.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
	  this.iList_tBarBtnIcons.ImageSize = new System.Drawing.Size(16, 16);
	  this.iList_tBarBtnIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("iList_tBarBtnIcons.ImageStream")));
	  this.iList_tBarBtnIcons.TransparentColor = System.Drawing.Color.Transparent;
	  // 
	  // tBar_Tools
	  // 
	  this.tBar_Tools.AutoSize = false;
	  this.tBar_Tools.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
	  this.tBar_Tools.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																				  this.btn_New,
																				  this.btn_Open,
																				  this.btn_Save,
																				  this.btn_Separator,
																				  this.btn_PointerTool,
																				  this.btn_CommunicationTool,
																				  this.btn_UseCaseTool,
																				  this.btn_ActorTool,
																				  this.btn_Separator_2,
																				  this.btn_Delete});
	  this.tBar_Tools.DropDownArrows = true;
	  this.tBar_Tools.ImageList = this.iList_tBarBtnIcons;
	  this.tBar_Tools.Name = "tBar_Tools";
	  this.tBar_Tools.ShowToolTips = true;
	  this.tBar_Tools.Size = new System.Drawing.Size(792, 40);
	  this.tBar_Tools.TabIndex = 1;
	  this.tBar_Tools.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tBar_Tools_ButtonClick);
	  // 
	  // btn_New
	  // 
	  this.btn_New.ImageIndex = 0;
	  this.btn_New.ToolTipText = "New Diagram";
	  // 
	  // btn_Open
	  // 
	  this.btn_Open.ImageIndex = 1;
	  this.btn_Open.ToolTipText = "Open Diagram";
	  // 
	  // btn_Save
	  // 
	  this.btn_Save.ImageIndex = 2;
	  this.btn_Save.ToolTipText = "Save Diagram";
	  // 
	  // btn_Separator
	  // 
	  this.btn_Separator.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
	  // 
	  // btn_PointerTool
	  // 
	  this.btn_PointerTool.ImageIndex = 3;
	  this.btn_PointerTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
	  this.btn_PointerTool.ToolTipText = "Pointer Tool";
	  // 
	  // btn_CommunicationTool
	  // 
	  this.btn_CommunicationTool.ImageIndex = 4;
	  this.btn_CommunicationTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
	  this.btn_CommunicationTool.ToolTipText = "Communication Tool";
	  // 
	  // btn_UseCaseTool
	  // 
	  this.btn_UseCaseTool.ImageIndex = 5;
	  this.btn_UseCaseTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
	  this.btn_UseCaseTool.ToolTipText = "Use Case Tool";
	  // 
	  // btn_ActorTool
	  // 
	  this.btn_ActorTool.ImageIndex = 6;
	  this.btn_ActorTool.Style = System.Windows.Forms.ToolBarButtonStyle.ToggleButton;
	  this.btn_ActorTool.ToolTipText = "Actor Tool";
	  // 
	  // commDisplay
	  // 
	  this.commDisplay.Communication = null;
	  this.commDisplay.Enabled = false;
	  this.commDisplay.Location = new System.Drawing.Point(520, 50);
	  this.commDisplay.Name = "commDisplay";
	  this.commDisplay.Size = new System.Drawing.Size(250, 190);
	  this.commDisplay.TabIndex = 2;
	  this.commDisplay.Visible = false;
	  this.commDisplay.ColorChanged += new myUML.ColorChangedHandler(this.commDisplay_ColorChanged);
	  this.commDisplay.ArrowsChanged += new myUML.ArrowsChangedHandler(this.commDisplay_ArrowsChanged);
	  this.commDisplay.PointCoordChanged += new myUML.PointCoordChangedHandler(this.commDisplay_PointCoordChanged);
	  // 
	  // ucDisplay
	  // 
	  this.ucDisplay.Enabled = false;
	  this.ucDisplay.Location = new System.Drawing.Point(520, 50);
	  this.ucDisplay.Name = "ucDisplay";
	  this.ucDisplay.Size = new System.Drawing.Size(250, 190);
	  this.ucDisplay.TabIndex = 3;
	  this.ucDisplay.UseCase = null;
	  this.ucDisplay.Visible = false;
	  this.ucDisplay.UseCaseLocationChanged += new myUML.UseCaseLocationChangedEventHandler(this.ucDisplay_UseCaseLocationChanged);
	  this.ucDisplay.UseCaseBorderedChanged += new myUML.UseCaseBorderedChangedEventHandler(this.ucDisplay_UseCaseBorderedChanged);
	  this.ucDisplay.UseCaseColorChanged += new myUML.UseCaseColorChangedHandler(this.ucDisplay_UseCaseColorChanged);
	  this.ucDisplay.UseCaseTextColorChanged += new myUML.UseCaseTextColorChangedHandler(this.ucDisplay_UseCaseTextColorChanged);
	  this.ucDisplay.UseCaseResized += new myUML.UseCaseResizeEventHandler(this.ucDisplay_UseCaseResized);
	  this.ucDisplay.UseCaseTextChanged += new myUML.UseCaseTextChangedHandler(this.ucDisplay_UseCaseTextChanged);
	  this.ucDisplay.UseCaseBorderColorChanged += new myUML.UseCaseBorderColorChangedHandler(this.ucDisplay_UseCaseBorderColorChanged);
	  this.ucDisplay.UseCaseFilledChanged += new myUML.UseCaseFilledChangedEventHandler(this.ucDisplay_UseCaseFilledChanged);
	  // 
	  // acDisplay
	  // 
	  this.acDisplay.Actor = null;
	  this.acDisplay.Enabled = false;
	  this.acDisplay.Location = new System.Drawing.Point(520, 50);
	  this.acDisplay.Name = "acDisplay";
	  this.acDisplay.Size = new System.Drawing.Size(250, 190);
	  this.acDisplay.TabIndex = 4;
	  this.acDisplay.Visible = false;
	  this.acDisplay.ActorTextColorChanged += new myUML.ActorTextColorChangedHandler(this.acDisplay_ActorTextColorChanged);
	  this.acDisplay.ActorTextChanged += new myUML.ActorTextChangedHandler(this.acDisplay_ActorTextChanged);
	  this.acDisplay.ActorBorderColorChanged += new myUML.ActorBorderColorChangedHandler(this.acDisplay_ActorBorderColorChanged);
	  this.acDisplay.ActorFilledChanged += new myUML.ActorFilledChangedEventHandler(this.acDisplay_ActorFilledChanged);
	  this.acDisplay.ActorColorChanged += new myUML.ActorColorChangedHandler(this.acDisplay_ActorColorChanged);
	  this.acDisplay.ActorLocationChanged += new myUML.ActorLocationChangedEventHandler(this.acDisplay_ActorLocationChanged);
	  this.acDisplay.ActorBorderedChanged += new myUML.ActorBorderedChangedEventHandler(this.acDisplay_ActorBorderedChanged);
	  this.acDisplay.ActorResized += new myUML.ActorResizeEventHandler(this.acDisplay_ActorResized);
	  // 
	  // btn_Separator_2
	  // 
	  this.btn_Separator_2.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
	  // 
	  // btn_Delete
	  // 
	  this.btn_Delete.ImageIndex = 7;
	  this.btn_Delete.ToolTipText = "Delete the selected figure(s)";
	  this.btn_Delete.Visible = false;
	  // 
	  // TestUseCases
	  // 
	  this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
	  this.ClientSize = new System.Drawing.Size(792, 466);
	  this.Controls.AddRange(new System.Windows.Forms.Control[] {
																  this.acDisplay,
																  this.ucDisplay,
																  this.commDisplay,
																  this.tBar_Tools,
																  this.pnl_drawable});
	  this.KeyPreview = true;
	  this.Name = "TestUseCases";
	  this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
	  this.Text = "Test Use Cases";
	  this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TestUseCases_KeyDown);
	  this.Resize += new System.EventHandler(this.TestUseCases_Resize);
	  this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TestUseCases_KeyUp);
	  this.ResumeLayout(false);

	}
		#endregion


	#region Public Methods

	/// <summary>
	/// Calculates the distance between two given PointFs.
	/// </summary>
	/// <param name="pa">The first PointF.</param>
	/// <param name="pb">The second PointF.</param>
	/// <returns>the length of the distance between the two PointFs.</returns>
	public float PointDiff(PointF pa, PointF pb)
	{
	  float dx = pb.X-pa.X;
	  dx*=dx;
	  float dy = pb.Y-pa.Y;
	  dy*=dy;
	  float s = dx+dy;
	  float r = (float)(Math.Sqrt(s));
	  return r;
	}

	#endregion


  }
}
