#region Copyright
/*
 * File Name: UseCaseDisplay.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using System.Text;

#endregion

namespace myUML
{

  #region EventArguments and Delegates

  /// <summary>
  /// The UseCaseLocationChangedEventArgs class is defined to describe the arguments
  /// of a UseCaseLocationChanged event.
  /// </summary>
  public class UseCaseLocationChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The Coordinate value indicating which coordinate was changed.
	/// </summary>
	public Coordinate			  Coord			=Coordinate.X;
	/// <summary>
	/// The new value of the coordinate, in the form of a float value.
	/// </summary>
	public float				  NewCoordinate	=0.0f;

	/// <summary>
	/// Instanciates a new UseCaseLocationChangedEventArgs object, with the Coord,
	/// and NewCoordinate properties set as specified by the parameters.
	/// </summary>
	/// <param name="inC">The Coordinate value indicating which coordinate was changed.</param>
	/// <param name="inf">The new value of the coordinate, in the form of a float value.</param>
	public UseCaseLocationChangedEventArgs(Coordinate inC, float inf)
	{
	  Coord = inC;
	  NewCoordinate = inf;
	}
  }
  /// <summary>
  /// Signature of the Event Handler for a UseCaseLocationChanged event.
  /// </summary>
  public delegate void UseCaseLocationChangedEventHandler(object sender,
  UseCaseLocationChangedEventArgs e);

  /// <summary>
  /// The UseCaseResizeEventArgs class is defined to describe the arguments
  /// of a UseCaseResize event.
  /// </summary>
  public class UseCaseResizeEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new width of the useCase.
	/// </summary>
	public	float		Width =0.0f;
	/// <summary>
	/// The new Height of the Usecase.
	/// </summary>
	public	float		Height=0.0f;

	/// <summary>
	/// Instanciates a new UseCaseResizeEventArgs object, with the Width,
	/// and Height properties set as specified by the parameters.
	/// </summary>
	/// <param name="newW">The new width of the UseCase.</param>
	/// <param name="newH">The new height of the UseCase.</param>
	public UseCaseResizeEventArgs(float newW, float newH)
	{
	  Width=newW;
	  Height=newH;
	}
  }
  /// <summary>
  /// Signature of the Event Handler for a UseCaseResize event.
  /// </summary>
  public delegate void UseCaseResizeEventHandler(object sender, UseCaseResizeEventArgs e);

  /// <summary>
  /// The UseCaseFilledChangedEventArgs class is defined to describe the arguments
  /// of a UseCaseFilledChanged event.
  /// </summary>
  public class UseCaseFilledChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new value of the Filled property.
	/// </summary>
	public bool			Filled	=false;

	/// <summary>
	/// Instanciates a new UseCaseFilledChangedEventArgs object, with the Filled
	/// property set as specified by the parameter.
	/// </summary>
	/// <param name="b">The new value of the Filled property.</param>
	public UseCaseFilledChangedEventArgs(bool b) : base()
	{ Filled=b; }
  }
  /// <summary>
  /// Signature of the Event Handler for a UseCaseFilledChanged event.
  /// </summary>
  public delegate void UseCaseFilledChangedEventHandler(object sender, UseCaseFilledChangedEventArgs e);

  /// <summary>
  /// The UseCaseBorderedChangedEventArgs class is defined to describe the arguments
  /// of a UseCaseBorderedChanged event.
  /// </summary>
  public class UseCaseBorderedChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new value of the Bordered property.
	/// </summary>
	public bool			Bordered	=false;

	/// <summary>
	/// Instanciates a new UseCaseBorderedChangedEventArgs object, with the Bordered
	/// property set as specified by the parameter.
	/// </summary>
	/// <param name="b">The new value of the Bordered property.</param>
	public UseCaseBorderedChangedEventArgs(bool b) : base()
	{ Bordered=b; }
  }
  /// <summary>
  /// Signature of the Event Handler for a UseCaseBorderedChanged event.
  /// </summary>
  public delegate void UseCaseBorderedChangedEventHandler(object sender,
  UseCaseBorderedChangedEventArgs e);

  /// <summary>
  /// The UseCaseColorChangedEventArgs class is defined to describe the arguments
  /// of a UseCaseColorChanged, UseCaseTextColorChanged, or UseCaseBorderColorChanged event.
  /// </summary>
  public class UseCaseColorChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new Color for the useCase.
	/// </summary>
	public Color				NewColor = Color.Black;

	/// <summary>
	/// Instanciates a new UseCaseColorChangedEventArgs object, with the NewColor
	/// property set as specified by the parameter.
	/// </summary>
	/// <param name="inC">The new Color of the UseCase.</param>
	public UseCaseColorChangedEventArgs(Color inC) : base()
	{ NewColor=inC; }
  }
  /// <summary>
  /// Signature of the Event Handler for a UseCaseColorChanged event.
  /// </summary>
  public delegate void UseCaseColorChangedHandler(object sender, UseCaseColorChangedEventArgs e);
  /// <summary>
  /// Signature of the Event Handler for a UseCaseTextColorChanged event.
  /// </summary>
  public delegate void UseCaseTextColorChangedHandler(object sender, UseCaseColorChangedEventArgs e);
  /// <summary>
  /// Signature of the Event Handler for a UseCaseBorderColorChanged event.
  /// </summary>
  public delegate void UseCaseBorderColorChangedHandler(object sender, UseCaseColorChangedEventArgs e);

  /// <summary>
  /// The UseCaseTextChangedEventArgs class is defined to describe the arguments
  /// of a UseCaseTextChanged event.
  /// </summary>
  public class UseCaseTextChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new Text of the UseCase.
	/// </summary>
	public string				NewText	="";

	/// <summary>
	/// Instanciates a new UseCaseTextChangedEventArgs object, with the NewText
	/// property set as specified by the parameter.
	/// </summary>
	/// <param name="inC">The new Color of the UseCase.</param>
	public UseCaseTextChangedEventArgs(string inT) : base()
	{ NewText = inT; }
  }
  /// <summary>
  /// Signature of the Event Handler for a UseCaseTextChanged event.
  /// </summary>
  public delegate void UseCaseTextChangedHandler(object sender, UseCaseTextChangedEventArgs e);

  #endregion

  /// <summary>
  /// The UseCaseDisplay control is defined to let a client application display
  /// the details regarding a given UseCase object.
  /// The UseCaseDisplay class inherits from the System.Windows.Forms.UserControl
  /// class.
  /// </summary>
  public class UseCaseDisplay : System.Windows.Forms.UserControl
  {
	#region Private Data Fields

	/// <summary>
	/// The string representation of the X coordinate of the UseCase's
	/// Top-Left Anchor.
	/// </summary>
	private string		  saveX	="";
	/// <summary>
	/// The string representation of the Y coordinate of the UseCase's
	/// Top-Left Anchor.
	/// </summary>
	private string		  saveY	="";
	/// <summary>
	/// The string representation of the UseCase's width.
	/// </summary>
	private	string		  saveW	="";
	/// <summary>
	/// The string representation of the UseCase's height.
	/// </summary>
	private string		  saveH	="";
	/// <summary>
	/// The value of the UseCase's Filled property.
	/// </summary>
	private	bool		  saveFilled  =false;
	/// <summary>
	/// The Color of the UseCase.
	/// </summary>
	private	Color		  saveColor	  =Color.White;
	/// <summary>
	/// The value of the UseCase's Bordered property.
	/// </summary>
	private bool		  saveBordered=true;
	/// <summary>
	/// The BrdColor property of the UseCase.
	/// </summary>
	private Color		  saveBrdColor=Color.Black;
	/// <summary>
	/// The Text of the UseCase.
	/// </summary>
	private string		  saveText	  ="";
	/// <summary>
	/// The TxtColor property of the UseCase.
	/// </summary>
	private Color		  saveTxtColor=Color.Black;
	/// <summary>
	/// Private flag, set to true when the values displayed in the GUI elements
	/// are being modified because of the internals of the UseCaseDisplay.
	/// </summary>
	private bool		  initializing=false;
	/// <summary>
	/// Private flag indicating when the UseCaseDisplay holds no
	/// UseCase to be displayed.
	/// </summary>
	private bool		  noUseCase=true;

	#endregion

	#region Events

	/// <summary>
	/// A UseCaseLocationChanged event is fired when one of the coordinates
	/// displayed by the UseCaseDisplay (the UseCase's Location X and Y
	/// coordinate) is properly modified by the user. Note that this event
	/// is fired only after the text boxes used for specifying the coordinates
	/// loose focus.
	/// </summary>
	public event UseCaseLocationChangedEventHandler UseCaseLocationChanged;
	/// <summary>
	/// A UseCaseResized event is fired when one of the dimensions of
	/// the UseCase (width or height) is properly modified by the user.
	/// Note that the event is fired only after the text box displaying
	/// the coordinate has lost focus.
	/// </summary>
	public event UseCaseResizeEventHandler			UseCaseResized;
	/// <summary>
	/// A UseCaseFilledChanged event is fired when the user changes the
	/// value of the check_Filled checkbox to change the Filled property
	/// of the UseCase.
	/// </summary>
	public event UseCaseFilledChangedEventHandler	UseCaseFilledChanged;
	/// <summary>
	/// A UseCaseBorderedChanged event is fired when the user changes the
	/// value of the check_Bordered checkbox to change the Bordered property
	/// of the UseCase.
	/// </summary>
	public event UseCaseBorderedChangedEventHandler	UseCaseBorderedChanged;
	/// <summary>
	/// A UseCaseColorChanged event is fired when the user changes the Color
	/// of the UseCase.
	/// </summary>
	public event UseCaseColorChangedHandler			UseCaseColorChanged;
	/// <summary>
	/// A UseCaseTextColorChanged event is fired when the user changes the
	/// TxtColor of the UseCase.
	/// </summary>
	public event UseCaseTextColorChangedHandler		UseCaseTextColorChanged;
	/// <summary>
	/// A UseCaseBorderColor event is fired when the user changes the
	/// BrdColor of the UseCase.
	/// </summary>
	public event UseCaseBorderColorChangedHandler	UseCaseBorderColorChanged;
	/// <summary>
	/// A UseCaseTextChanged event is fired when the user changes the
	/// Text associated with the UseCase. Note that this event is fired
	/// every time the text in the tBox_Text textbox is changed.
	/// </summary>
	public event UseCaseTextChangedHandler			UseCaseTextChanged;

	#endregion

	#region GUI Controls

    private System.Windows.Forms.TextBox tBox_LocY;
    private System.Windows.Forms.Label lbl_LocY;
    private System.Windows.Forms.TextBox tBox_LocX;
    private System.Windows.Forms.Label lbl_LocX;
    private System.Windows.Forms.Label lbl_Location;
    private System.Windows.Forms.Label lbl_Width;
    private System.Windows.Forms.TextBox tBox_Width;
    private System.Windows.Forms.TextBox tBox_Height;
    private System.Windows.Forms.Label lbl_Height;
    private System.Windows.Forms.Label lbl_Filled;
    private System.Windows.Forms.CheckBox check_Filled;
    private System.Windows.Forms.Button btn_ColorPick;
    private System.Windows.Forms.Button btn_BrdColorPick;
    private System.Windows.Forms.CheckBox check_Bordered;
    private System.Windows.Forms.Label lbl_Bordered;
    private System.Windows.Forms.Button btn_TxtColorPick;
    private System.Windows.Forms.Label lbl_TextColor;
    private System.Windows.Forms.TextBox tBox_Text;
    private System.Windows.Forms.Label lbl_Text;
    private System.Windows.Forms.Panel pnl_Color;
    private System.Windows.Forms.Panel pnl_BrdColor;
    private System.Windows.Forms.Panel pnl_TxtColor;
	/// <summary> 
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	#endregion

	#region Public Attributes

	/// <summary>
	/// Gets or sets the UseCase displayed by the UseCaseDisplay.
	/// if the UseCaseDisplay is displaying no UseCase, the attribute
	/// returns null.
	/// If this property is set ot null, the UseCaseDisplay is set
	/// to display no UseCase.
	/// </summary>
	public UseCase	UseCase
	{
	  get
	  {
		if(noUseCase) return null;

		PointF tl = new PointF(float.Parse(saveX), float.Parse(saveY));
		float w = float.Parse(saveW);
		float h = float.Parse(saveH);
		UseCase r = new UseCase(tl, w, h);
		r.Filled=saveFilled;
		r.Color=saveColor;
		r.Bordered=saveBordered;
		r.BrdColor=saveBrdColor;
		r.Text = saveText;
		r.TxtColor = saveTxtColor;
		return r;
	  }
	  set
	  {
		if(value==null)
		  InitEmpty();
		else
		  SaveUseCase(value);
	  }
	}

	#endregion

	#region Constructors

	/// <summary>
	/// Parameterized Constructor: Instanciates a UseCaseDisplay set
	/// to display the given UseCase.
	/// </summary>
	/// <param name="inUC">The UseCase to be displayed.</param>
	public UseCaseDisplay(UseCase inUC)
	{
	  // This call is required by the Windows.Forms Form Designer.
	  InitializeComponent();

	  SaveUseCase(inUC);
	}
	/// <summary>
	/// Default Constructors: instanciates a UseCaseDisplay set to
	/// display no UseCase.
	/// </summary>
	public UseCaseDisplay()
	{
	  // This call is required by the Windows.Forms Form Designer.
	  InitializeComponent();

	  InitEmpty();
	}

	#endregion

	#region Private Methods

	/// <summary>
	/// Sets the UseCaseDisplay to display no UseCase.
	/// Disables all of the GUI controls of the UseCaseDisplay.
	/// </summary>
	private void InitEmpty()
	{
	  initializing=true;

	  saveX = "0";
	  saveY	= "0";
	  saveW	= "0";
	  saveH	= "0";
	  saveFilled  =false;
	  saveColor	  =Color.White;
	  saveBordered=true;
	  saveBrdColor=Color.Black;
	  saveText	  ="";
	  saveTxtColor=Color.Black;

	  UpdateGUI();
	  noUseCase=true;
	  this.tBox_LocX.Enabled=true;
	  this.tBox_LocY.Enabled=true;
	  this.tBox_Width.Enabled=true;
	  this.tBox_Height.Enabled=true;
	  this.check_Filled.Enabled=true;
	  this.btn_ColorPick.Enabled=true;
	  this.check_Bordered.Enabled=true;
	  this.btn_BrdColorPick.Enabled=true;
	  this.tBox_Text.Enabled=true;
	  this.btn_TxtColorPick.Enabled=true;

	  initializing=false;
	}
	/// <summary>
	/// Sets the UseCaseDisplay to display the given UseCase.
	/// Enables all of the GUI Controls of the UseCaseDisplay.
	/// </summary>
	/// <param name="inUC">The UseCase to be displayed.</param>
	private void SaveUseCase(UseCase inUC)
	{
	  initializing=true;
	  saveX		  = inUC[UseCaseAnchors.TopLeft].CenterX.ToString();
	  saveY		  = inUC[UseCaseAnchors.TopLeft].CenterY.ToString();
	  saveW		  = inUC.Width.ToString();
	  saveH		  = inUC.Height.ToString();
	  saveFilled  = inUC.Filled;
	  saveColor	  = inUC.Color;
	  saveBordered= inUC.Bordered;
	  saveBrdColor= inUC.BrdColor;
	  saveText	  = inUC.Text;
	  saveTxtColor= inUC.TxtColor;

	  UpdateGUI();
	  noUseCase=false;
	  this.tBox_LocX.Enabled=true;
	  this.tBox_LocY.Enabled=true;
	  this.tBox_Width.Enabled=true;
	  this.tBox_Height.Enabled=true;
	  this.check_Filled.Enabled=true;
	  this.btn_ColorPick.Enabled=true;
	  this.check_Bordered.Enabled=true;
	  this.btn_BrdColorPick.Enabled=true;
	  this.tBox_Text.Enabled=true;
	  this.btn_TxtColorPick.Enabled=true;
	  initializing=false;
	}
	/// <summary>
	/// Updates the GUI Control of the UseCaseDisplay to match
	/// the values in the private fields of the UseCaseDisplay.
	/// </summary>
	private void UpdateGUI()
	{
	  this.tBox_LocX.Text=saveX;
	  this.tBox_LocY.Text=saveY;
	  this.tBox_Width.Text=saveW;
	  this.tBox_Height.Text=saveH;
	  this.check_Filled.Checked=saveFilled;
	  this.pnl_Color.BackColor=saveColor;
	  this.check_Bordered.Checked=saveBordered;
	  this.pnl_BrdColor.BackColor=saveBrdColor;
	  this.tBox_Text.Text=saveText;
	  this.pnl_TxtColor.BackColor=saveTxtColor;
	}
	/// <summary>
	/// Announces (via MessageBox) that the specified coordinate
	/// is invalid.
	/// </summary>
	/// <param name="s">The string representation of the invalid coordinate.</param>
	private void AnnounceBadCoordinate(string s)
	{
	  StringBuilder sb = new StringBuilder("The value you specified for the use case's location\n");
	  sb.Append("coordinate ("+s+") is not a valid coordinate.\n");
	  sb.Append("The coordinate will be reset to its previous value.\n");
	  MessageBox.Show(this, sb.ToString(), "Invalid Coordinate:");
	}
	/// <summary>
	/// Announces (via MessageBox) that the specified dimension
	/// is invalid.
	/// </summary>
	/// <param name="s">The string representation of the invalid dimension.</param>
	private void AnnounceBadDimension(string s)
	{
	  StringBuilder sb = new StringBuilder("The value you specified for the use case's dimension\n");
	  sb.Append("("+s+") is not a valid dimension.\n");
	  sb.Append("The dimension will be reset to its previous value.\n");
	  MessageBox.Show(this, sb.ToString(), "Invalid Dimension:");
	}

	#region Handle events from the GUI Controls

	/// <summary>
	/// Handles the Leave (i.e. LooseFocus) event for the text boxes used to
	/// display the coordinates of the UseCase's Location.
	/// The new coordinate is validated (see ValidLocationCoordinate method). If
	/// the new coordinate is valid (and different from the previous value
	/// of the same coordinate), the OnLocationChanged method is invoked
	/// to fire a new UseCaseLocationChanged event. If the new coordinate is invalid,
	/// the AnnounceBadCoordinate method is invoked.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void locCoord_LooseFocus(object sender, System.EventArgs e)
	{
	  string ntxt ="";
	  string otxt ="";
	  Coordinate whichCoordinate = Coordinate.X;

	  TextBox tbox = sender as TextBox;
	  if(tbox==null)  return;

	  switch(tbox.Name)
	  {
		case "tBox_LocX":
		  otxt = saveX;
		  ntxt = this.tBox_LocX.Text;
		  whichCoordinate = Coordinate.X;
		  break;
		case "tBox_LocY":
		  otxt = saveY;
		  ntxt = this.tBox_LocY.Text;
		  whichCoordinate = Coordinate.Y;
		  break;
		default:
		  return;
	  }
	  float newVal = 0.0f;
	  if(ValidLocationCoordinate(ntxt, ref newVal))
	  {
		switch(whichCoordinate)
		{
		  case Coordinate.X:
			saveX = ntxt;
			break;
		  case Coordinate.Y:
			saveY = ntxt;
			break;
		  default:
			break;
		}
		if(!initializing)
		  OnLocationChanged(new UseCaseLocationChangedEventArgs(whichCoordinate, newVal));
	  }
	  else
	  {
		AnnounceBadCoordinate(ntxt);
		tbox.Text=otxt;
	  }
	}
	/// <summary>
	/// Handles the Leave (i.e. LooseFocus) event for the text boxes used to
	/// display the dimensions of the UseCase.
	/// The new dimension is validated (see ValidDimension method). If
	/// the new dimension is valid (and different from the previous value
	/// of the same coordinate), the OnUseCaseResized method is invoked
	/// to fire a new UseCaseResized event. If the new coordinate is invalid,
	/// the AnnounceBadDimension method is invoked.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void dimension_LooseFocus(object sender, System.EventArgs e)
	{
	  string ntxt ="";
	  string otxt ="";

	  TextBox tbox = sender as TextBox;
	  if(tbox==null)  return;

	  switch(tbox.Name)
	  {
		case "tBox_Width":
		  ntxt = this.tBox_Width.Text;
		  otxt = saveW;
		  break;
		case "tBox_Height":
		  ntxt = this.tBox_Height.Text;
		  otxt = saveH;
		  break;
		default:
		  return;
	  }
	  float f = 0.0f;
	  if(ValidDimension(ntxt, ref f))
	  {
		switch(tbox.Name)
		{
		  case "tBox_Width":
			saveW=ntxt;
			break;
		  case "tBox_Height":
			saveH=ntxt;
			break;
		  default:
			return;
		}
		float fw = float.Parse(this.tBox_Width.Text);
		float fh = float.Parse(this.tBox_Height.Text);
		if(!initializing)
		  OnUseCaseResized(new UseCaseResizeEventArgs(fw, fh));
	  }
	  else
	  {
		AnnounceBadDimension(ntxt);
		tbox.Text=otxt;
	  }
	}
	/// <summary>
	/// Handles the CheckedChanged event of the check_Filled checkbox.
	/// Invokes the OnUseCaseFilledChanged method to fire a new
	/// UseCaseFilledChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void check_Filled_CheckedChanged(object sender, System.EventArgs e)
	{
	  saveFilled = this.check_Filled.Checked;
	  if(!initializing)
		OnUseCaseFilledChanged(new UseCaseFilledChangedEventArgs(saveFilled));
	}
	/// <summary>
	/// Handles the CheckedChanged event of the check_Bordered checkbox.
	/// Invokes the OnUseCaseBorderedChanged method to fire a new
	/// UseCaseBorderedChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void check_Bordered_CheckedChanged(object sender, System.EventArgs e)
	{
	  saveBordered = this.check_Bordered.Checked;
	  if(!initializing)
		OnUseCaseBorderedChanged(new UseCaseBorderedChangedEventArgs(saveFilled));
	}
	/// <summary>
	/// Handles the Click event of the btn_ColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_Color panel is colored in the choosen Color, and
	/// the OnUseCaseColorChanged method is invoked to fire a new
	/// UseCaseColorChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_ColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveColor)
		{
		  saveColor = newColor;
		  this.pnl_Color.BackColor=saveColor;
		  if(!initializing)
			OnUseCaseColorChanged(new UseCaseColorChangedEventArgs(saveColor));
		}
	  }
	}
	/// <summary>
	/// Handles the Click event of the btn_TxtColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_TxtColor panel is colored in the choosen Color, and
	/// the OnUseCaseTextColorChanged method is invoked to fire a new
	/// UseCaseTextColorChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_TxtColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveTxtColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveTxtColor)
		{
		  saveTxtColor = newColor;
		  this.pnl_TxtColor.BackColor=saveTxtColor;
		  if(!initializing)
			OnUseCaseTextColorChanged(new UseCaseColorChangedEventArgs(saveColor));
		}
	  }
	}
	/// <summary>
	/// Handles the Click event of the btn_BrdColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_BrdColor panel is colored in the choosen Color, and
	/// the OnUseCaseBorderColorChanged method is invoked to fire a new
	/// UseCaseBorderColorChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_BrdColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveBrdColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveBrdColor)
		{
		  saveBrdColor = newColor;
		  this.pnl_BrdColor.BackColor=saveBrdColor;
		  if(!initializing)
			OnUseCaseBorderColorChanged(new UseCaseColorChangedEventArgs(saveBrdColor));
		}
	  }
	}
	/// <summary>
	/// Handles the TextChanged event of the tBox_Text text box. If the
	/// new text is different than the previous one, the OnUseCaseTextChanged
	/// method is invoked to fire a new UseCaseTextChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void tBox_Text_TextChanged(object sender, System.EventArgs e)
	{
	  string ntxt = this.tBox_Text.Text;
	  if(ntxt!=saveText)
	  {
		saveText = ntxt;
		if(!initializing)
		  OnUseCaseTextChanged(new UseCaseTextChangedEventArgs(saveText));
	  }
	}

	#endregion

	#endregion

	#region Protected Methods

	/// <summary> 
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
	  if( disposing )
	  {
		if(components != null)
		{
		  components.Dispose();
		}
	  }
	  base.Dispose( disposing );
	}

	#region Custom Event Handlers

	/// <summary>
	/// Fires a new UseCaseLocationChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseLocationChangedEventArgs describing the event.</param>
	protected virtual void OnLocationChanged(UseCaseLocationChangedEventArgs e)
	{ if(UseCaseLocationChanged!=null) UseCaseLocationChanged(this, e); }
	/// <summary>
	/// Fires a new UseCaseResize event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseResizeEventArgs describing the event.</param>
	protected virtual void OnUseCaseResized(UseCaseResizeEventArgs e)
	{ if(UseCaseResized!=null) UseCaseResized(this, e); }
	/// <summary>
	/// Fires a new UseCaseFilledChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseFilledChangedEventArgs describing the event.</param>
	protected virtual void OnUseCaseFilledChanged(UseCaseFilledChangedEventArgs e)
	{ if(UseCaseFilledChanged!=null) UseCaseFilledChanged(this, e); }	
	/// <summary>
	/// Fires a new UseCaseBorderedChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseBorderedChangedEventArgs describing the event.</param>
	protected virtual void OnUseCaseBorderedChanged(UseCaseBorderedChangedEventArgs e)
	{ if(UseCaseBorderedChanged!=null) UseCaseBorderedChanged(this, e); }
	/// <summary>
	/// Fires a new UseCaseColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseColorChangedEventArgs describing the event.</param>
	protected virtual void OnUseCaseColorChanged(UseCaseColorChangedEventArgs e)
	{ if(UseCaseColorChanged!=null) UseCaseColorChanged(this, e); }
	/// <summary>
	/// Fires a new UseCaseColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseColorChangedEventArgs describing the event.</param>
	protected virtual void OnUseCaseTextColorChanged(UseCaseColorChangedEventArgs e)
	{ if(UseCaseTextColorChanged!=null) UseCaseTextColorChanged(this, e); }
	/// <summary>
	/// Fires a new UseCaseColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseColorChangedEventArgs describing the event.</param>
	protected virtual void OnUseCaseBorderColorChanged(UseCaseColorChangedEventArgs e)
	{ if(UseCaseBorderColorChanged!=null) UseCaseBorderColorChanged(this, e); }
	/// <summary>
	/// Fires a new UseCaseTextChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The UseCaseTextChangedEventArgs describing the event.</param>
	protected virtual void OnUseCaseTextChanged(UseCaseTextChangedEventArgs e)
	{ if(UseCaseTextChanged!=null) UseCaseTextChanged(this, e); }

	#endregion

	#endregion

		#region Component Designer generated code
	/// <summary> 
	/// Required method for Designer support - do not modify 
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.tBox_LocY = new System.Windows.Forms.TextBox();
	  this.lbl_LocY = new System.Windows.Forms.Label();
	  this.tBox_LocX = new System.Windows.Forms.TextBox();
	  this.lbl_LocX = new System.Windows.Forms.Label();
	  this.lbl_Location = new System.Windows.Forms.Label();
	  this.lbl_Width = new System.Windows.Forms.Label();
	  this.tBox_Width = new System.Windows.Forms.TextBox();
	  this.tBox_Height = new System.Windows.Forms.TextBox();
	  this.lbl_Height = new System.Windows.Forms.Label();
	  this.lbl_Filled = new System.Windows.Forms.Label();
	  this.check_Filled = new System.Windows.Forms.CheckBox();
	  this.btn_ColorPick = new System.Windows.Forms.Button();
	  this.btn_BrdColorPick = new System.Windows.Forms.Button();
	  this.check_Bordered = new System.Windows.Forms.CheckBox();
	  this.lbl_Bordered = new System.Windows.Forms.Label();
	  this.btn_TxtColorPick = new System.Windows.Forms.Button();
	  this.lbl_TextColor = new System.Windows.Forms.Label();
	  this.tBox_Text = new System.Windows.Forms.TextBox();
	  this.lbl_Text = new System.Windows.Forms.Label();
	  this.pnl_Color = new System.Windows.Forms.Panel();
	  this.pnl_BrdColor = new System.Windows.Forms.Panel();
	  this.pnl_TxtColor = new System.Windows.Forms.Panel();
	  this.SuspendLayout();
	  // 
	  // tBox_LocY
	  // 
	  this.tBox_LocY.Location = new System.Drawing.Point(190, 10);
	  this.tBox_LocY.Name = "tBox_LocY";
	  this.tBox_LocY.Size = new System.Drawing.Size(50, 20);
	  this.tBox_LocY.TabIndex = 9;
	  this.tBox_LocY.Text = "";
	  this.tBox_LocY.Leave += new System.EventHandler(this.locCoord_LooseFocus);
	  // 
	  // lbl_LocY
	  // 
	  this.lbl_LocY.Location = new System.Drawing.Point(160, 10);
	  this.lbl_LocY.Name = "lbl_LocY";
	  this.lbl_LocY.Size = new System.Drawing.Size(20, 20);
	  this.lbl_LocY.TabIndex = 8;
	  this.lbl_LocY.Text = "Y=";
	  this.lbl_LocY.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_LocX
	  // 
	  this.tBox_LocX.Location = new System.Drawing.Point(100, 10);
	  this.tBox_LocX.Name = "tBox_LocX";
	  this.tBox_LocX.Size = new System.Drawing.Size(50, 20);
	  this.tBox_LocX.TabIndex = 7;
	  this.tBox_LocX.Text = "";
	  this.tBox_LocX.Leave += new System.EventHandler(this.locCoord_LooseFocus);
	  // 
	  // lbl_LocX
	  // 
	  this.lbl_LocX.Location = new System.Drawing.Point(70, 10);
	  this.lbl_LocX.Name = "lbl_LocX";
	  this.lbl_LocX.Size = new System.Drawing.Size(20, 20);
	  this.lbl_LocX.TabIndex = 6;
	  this.lbl_LocX.Text = "X=";
	  this.lbl_LocX.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_Location
	  // 
	  this.lbl_Location.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Location.Location = new System.Drawing.Point(5, 10);
	  this.lbl_Location.Name = "lbl_Location";
	  this.lbl_Location.Size = new System.Drawing.Size(55, 20);
	  this.lbl_Location.TabIndex = 5;
	  this.lbl_Location.Text = "Location:";
	  this.lbl_Location.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_Width
	  // 
	  this.lbl_Width.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Width.Location = new System.Drawing.Point(5, 40);
	  this.lbl_Width.Name = "lbl_Width";
	  this.lbl_Width.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Width.TabIndex = 10;
	  this.lbl_Width.Text = "Width:";
	  this.lbl_Width.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_Width
	  // 
	  this.tBox_Width.Location = new System.Drawing.Point(65, 40);
	  this.tBox_Width.Name = "tBox_Width";
	  this.tBox_Width.Size = new System.Drawing.Size(50, 20);
	  this.tBox_Width.TabIndex = 11;
	  this.tBox_Width.Text = "";
	  this.tBox_Width.Leave += new System.EventHandler(this.dimension_LooseFocus);
	  // 
	  // tBox_Height
	  // 
	  this.tBox_Height.Location = new System.Drawing.Point(190, 40);
	  this.tBox_Height.Name = "tBox_Height";
	  this.tBox_Height.Size = new System.Drawing.Size(50, 20);
	  this.tBox_Height.TabIndex = 13;
	  this.tBox_Height.Text = "";
	  this.tBox_Height.Leave += new System.EventHandler(this.dimension_LooseFocus);
	  // 
	  // lbl_Height
	  // 
	  this.lbl_Height.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Height.Location = new System.Drawing.Point(130, 40);
	  this.lbl_Height.Name = "lbl_Height";
	  this.lbl_Height.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Height.TabIndex = 12;
	  this.lbl_Height.Text = "Height:";
	  this.lbl_Height.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_Filled
	  // 
	  this.lbl_Filled.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Filled.Location = new System.Drawing.Point(5, 70);
	  this.lbl_Filled.Name = "lbl_Filled";
	  this.lbl_Filled.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Filled.TabIndex = 14;
	  this.lbl_Filled.Text = "Filled?";
	  this.lbl_Filled.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // check_Filled
	  // 
	  this.check_Filled.Location = new System.Drawing.Point(65, 70);
	  this.check_Filled.Name = "check_Filled";
	  this.check_Filled.Size = new System.Drawing.Size(20, 20);
	  this.check_Filled.TabIndex = 15;
	  this.check_Filled.CheckedChanged += new System.EventHandler(this.check_Filled_CheckedChanged);
	  // 
	  // btn_ColorPick
	  // 
	  this.btn_ColorPick.Location = new System.Drawing.Point(190, 70);
	  this.btn_ColorPick.Name = "btn_ColorPick";
	  this.btn_ColorPick.Size = new System.Drawing.Size(50, 20);
	  this.btn_ColorPick.TabIndex = 18;
	  this.btn_ColorPick.Text = "&Pick...";
	  this.btn_ColorPick.Click += new System.EventHandler(this.btn_ColorPick_Click);
	  // 
	  // btn_BrdColorPick
	  // 
	  this.btn_BrdColorPick.Location = new System.Drawing.Point(190, 100);
	  this.btn_BrdColorPick.Name = "btn_BrdColorPick";
	  this.btn_BrdColorPick.Size = new System.Drawing.Size(50, 20);
	  this.btn_BrdColorPick.TabIndex = 22;
	  this.btn_BrdColorPick.Text = "&Pick...";
	  this.btn_BrdColorPick.Click += new System.EventHandler(this.btn_BrdColorPick_Click);
	  // 
	  // check_Bordered
	  // 
	  this.check_Bordered.Location = new System.Drawing.Point(65, 100);
	  this.check_Bordered.Name = "check_Bordered";
	  this.check_Bordered.Size = new System.Drawing.Size(20, 20);
	  this.check_Bordered.TabIndex = 20;
	  this.check_Bordered.CheckedChanged += new System.EventHandler(this.check_Bordered_CheckedChanged);
	  // 
	  // lbl_Bordered
	  // 
	  this.lbl_Bordered.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Bordered.Location = new System.Drawing.Point(5, 100);
	  this.lbl_Bordered.Name = "lbl_Bordered";
	  this.lbl_Bordered.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Bordered.TabIndex = 19;
	  this.lbl_Bordered.Text = "Border?";
	  this.lbl_Bordered.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // btn_TxtColorPick
	  // 
	  this.btn_TxtColorPick.Location = new System.Drawing.Point(190, 160);
	  this.btn_TxtColorPick.Name = "btn_TxtColorPick";
	  this.btn_TxtColorPick.Size = new System.Drawing.Size(50, 20);
	  this.btn_TxtColorPick.TabIndex = 27;
	  this.btn_TxtColorPick.Text = "P&ick...";
	  this.btn_TxtColorPick.Click += new System.EventHandler(this.btn_TxtColorPick_Click);
	  // 
	  // lbl_TextColor
	  // 
	  this.lbl_TextColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_TextColor.Location = new System.Drawing.Point(10, 160);
	  this.lbl_TextColor.Name = "lbl_TextColor";
	  this.lbl_TextColor.Size = new System.Drawing.Size(55, 20);
	  this.lbl_TextColor.TabIndex = 25;
	  this.lbl_TextColor.Text = "Txt Color:";
	  this.lbl_TextColor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_Text
	  // 
	  this.tBox_Text.Location = new System.Drawing.Point(70, 130);
	  this.tBox_Text.Name = "tBox_Text";
	  this.tBox_Text.Size = new System.Drawing.Size(170, 20);
	  this.tBox_Text.TabIndex = 24;
	  this.tBox_Text.Text = "";
	  this.tBox_Text.TextChanged += new System.EventHandler(this.tBox_Text_TextChanged);
	  // 
	  // lbl_Text
	  // 
	  this.lbl_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Text.Location = new System.Drawing.Point(10, 130);
	  this.lbl_Text.Name = "lbl_Text";
	  this.lbl_Text.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Text.TabIndex = 23;
	  this.lbl_Text.Text = "Text:";
	  this.lbl_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // pnl_Color
	  // 
	  this.pnl_Color.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_Color.Location = new System.Drawing.Point(90, 70);
	  this.pnl_Color.Name = "pnl_Color";
	  this.pnl_Color.Size = new System.Drawing.Size(90, 20);
	  this.pnl_Color.TabIndex = 28;
	  // 
	  // pnl_BrdColor
	  // 
	  this.pnl_BrdColor.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_BrdColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_BrdColor.Location = new System.Drawing.Point(90, 100);
	  this.pnl_BrdColor.Name = "pnl_BrdColor";
	  this.pnl_BrdColor.Size = new System.Drawing.Size(90, 20);
	  this.pnl_BrdColor.TabIndex = 29;
	  // 
	  // pnl_TxtColor
	  // 
	  this.pnl_TxtColor.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_TxtColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_TxtColor.Location = new System.Drawing.Point(70, 160);
	  this.pnl_TxtColor.Name = "pnl_TxtColor";
	  this.pnl_TxtColor.Size = new System.Drawing.Size(110, 20);
	  this.pnl_TxtColor.TabIndex = 30;
	  // 
	  // UseCaseDisplay
	  // 
	  this.Controls.AddRange(new System.Windows.Forms.Control[] {
																  this.pnl_TxtColor,
																  this.pnl_BrdColor,
																  this.pnl_Color,
																  this.btn_TxtColorPick,
																  this.lbl_TextColor,
																  this.tBox_Text,
																  this.lbl_Text,
																  this.btn_BrdColorPick,
																  this.check_Bordered,
																  this.lbl_Bordered,
																  this.btn_ColorPick,
																  this.check_Filled,
																  this.lbl_Filled,
																  this.tBox_Height,
																  this.lbl_Height,
																  this.tBox_Width,
																  this.lbl_Width,
																  this.tBox_LocY,
																  this.lbl_LocY,
																  this.tBox_LocX,
																  this.lbl_LocX,
																  this.lbl_Location});
	  this.Name = "UseCaseDisplay";
	  this.Size = new System.Drawing.Size(250, 190);
	  this.ResumeLayout(false);

	}
		#endregion

	#region Public Methods

	/// <summary>
	/// Determines whether the given string represents a valid coordinate
	/// for the UseCase's Location.
	/// </summary>
	/// <param name="s">The string to be validated.</param>
	/// <returns>true if the string s represents a valid float value; false otherwise.</returns>
	public bool ValidLocationCoordinate(string s, ref float f)
	{
	  try
	  {
		f = float.Parse(s);
	  }
	  catch(Exception)
	  {
		return false;
	  }
	  return true;
	}
	/// <summary>
	/// Determines whether the given string represents a valid dimension
	/// for the UseCase. If so, the float parameter is set to be the value
	/// represented by the string.
	/// </summary>
	/// <param name="s">The string to be validated.</param>
	/// <param name="f">The parameter to be set to the value represented by the string
	/// s if this is a valid dimension.</param>
	/// <returns>true if s is a valid dimension (i.e. represents a valid float value);
	/// false otherwise.</returns>
	public bool ValidDimension(string s, ref float f)
	{
	  try
	  {
		f = float.Parse(s);
	  }
	  catch(Exception)
	  {
		return false;
	  }
	  if(f<0.0f)  return false;
	  return true;
	}

	#endregion

  }
}
