#region Copyright
/*
 * File Name: Actor.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Drawing;

using System.Xml;

//Un-comment if you need MessageBoxes to debug
//using System.Collections;
//using System.ComponentModel;
//using System.Windows.Forms;

#endregion

namespace myUML
{
  /// <summary>
  /// The Actor class is defined to represent Actors in a Use Case Diagram.
  /// Actors are roles that people or object play within the context of the Use
  /// Case. They are associated with UseCase via Communications, representing
  /// the participation of the Actor to the given Use Case.
  /// Graphically, Actors are rendered as stick figures.
  /// The Actor class inherits from the UseCase class most of its
  /// internals, but overrides the UseCase Paint method, and provides an alternative
  /// implementation of the the SaveTo method for the IUMLtoXML interface.
  /// </summary>
  public class Actor : UseCase
  {
	#region Constructors

	/// <summary>
	/// Instanciates a new Actor with its top-left corner in the
	/// specified position, the given width and height.
	/// </summary>
	/// <param name="inTL">The PointF where the top-left Anchor of the new Actor
	/// should be centered.</param>
	/// <param name="inW">The width of the Actor.</param>
	/// <param name="inH">The height of the Actor.</param>
	public Actor(PointF inTL, float inW, float inH) :base(inTL, inW, inH)
	{ }
	/// <summary>
	/// Default Constructor: instanciates a new Actor, with its properties set to
	/// their default values (see the UseCase default constructor).
	/// </summary>
	public Actor() : base() { }

	#endregion

	#region Public Methods

	/// <summary>
	/// Overrides the Paint method inherited from the UseCase class.
	/// Behaves similarly, but renders the Actor as a stick figure,
	/// with any associated text right below it.
	/// </summary>
	/// <param name="g">The Graphics over which the Actor should be painted.</param>
	/// <param name="clipRectangle">The Rectangle defining the clip area that is currently
	/// being painted on the Graphics g.</param>
	/// <param name="scrollOffset">The Size describing the offset due to the position of
	/// scrollbars surrounding the Graphics g.</param>
	/// <param name="MAX_DRAW_WIDTH">The Maximum X coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="MAX_DRAW_HEIGHT">The Maximum Y coordinate to be drawn on the
	/// Graphics g.</param>
	/// <param name="pm">The PaintMode to be used.</param>
	public override void Paint(Graphics g, Rectangle clipRectangle, Size scrollOffset,
	  int MAX_DRAW_WIDTH, int MAX_DRAW_HEIGHT, PaintMode pm)
	{
	  //Check for clipRectangle + scrollOffset to be in drawable range
	  if (clipRectangle.Top+scrollOffset.Width < MAX_DRAW_WIDTH ||
		clipRectangle.Left+scrollOffset.Height < MAX_DRAW_HEIGHT)
	  {
		RectangleF tmpRectangle = new RectangleF(
		  anchors[UseCase.UseCaseAnchorsToInt(UseCaseAnchors.TopLeft)].Center+scrollOffset,
		  new SizeF(width, height));

		//Set Up the appropriate Pen and Brush:
		Pen pen = new Pen(brdColor);
		Brush brush = new SolidBrush(color);

		//If in Outline PaintMode, make the pen blue and dashed:
		if(pm==PaintMode.Outline)
		{
		  pen.Color=Color.Blue;
		  pen.Width=2;
		  pen.DashPattern=new float[] {5, 2};
		}

		//Set up the rectangle for the head:
		float wHalf = width/(2.0f);
		float hSixth= height/(6.0f);
		float headX = tmpRectangle.Left+(wHalf-hSixth);
		float hThird = height/(3.0f);
		PointF headRoot = new PointF(headX, tmpRectangle.Top);
		SizeF headSize = new SizeF(hThird, hThird);
		RectangleF headR = new RectangleF(headRoot, headSize);

		//If filled: fill the rectangle, unless painting in Outline mode:
		if(filled && pm!=PaintMode.Outline)
		  g.FillRectangle(brush, tmpRectangle);

		//Draw the head:
		g.DrawEllipse(pen,
		  headR.Left, headR.Top, headR.Width, headR.Height);

		//Set up the points for the arms:
		float armsY = tmpRectangle.Top+hThird;
		PointF armsStart = new PointF(tmpRectangle.Left, armsY);
		PointF armsEnd	 = new PointF(tmpRectangle.Left+tmpRectangle.Width, armsY);

		//Draw the arms:
		g.DrawLine(pen, armsStart, armsEnd);

		//Set up the points for the mid section:
		PointF midStart = new PointF(tmpRectangle.Left+wHalf, armsY);
		PointF midEnd	= new PointF(tmpRectangle.Left+wHalf, (armsY+hThird));

		//Draw the mid section:
		g.DrawLine(pen, midStart, midEnd);

		//Set up the rhs leg:
		PointF legEnd = new PointF(tmpRectangle.Left+tmpRectangle.Width,
		  tmpRectangle.Top+tmpRectangle.Height);
		//Draw the rhs leg:
		g.DrawLine(pen, midEnd, legEnd);

		//Set up the lhs leg:
		legEnd.X=tmpRectangle.Left;
		//Draw the lhs leg:
		g.DrawLine(pen, midEnd, legEnd);

		//IF selected: draw the anchor points (unless painting in Outline mode
		if(selected && pm!=PaintMode.Outline)
		{
		  for(int i=0; i<NUM_USE_CASE_ANCHORS; i++)
			anchors[i].Paint(g, clipRectangle, scrollOffset, MAX_DRAW_WIDTH, MAX_DRAW_HEIGHT, pm);
		}//IF selected and not painting in Outline mode

		//Text?
		if(text.Length>0 && pm==PaintMode.Standard)
		{
		  PointF txtPoint = new PointF(tmpRectangle.Left, tmpRectangle.Top+tmpRectangle.Height);
		  SizeF txtBox = g.MeasureString(text, arialFont10);
		  //If there is text to be displayed, it extends the bounding box, if the
		  //Actor is filled:
		  if(filled)
		  {
			g.FillRectangle(brush,
			  txtPoint.X, txtPoint.Y, tmpRectangle.Width, txtBox.Height);

		  }//IF filled
		  txtPoint.X+=(width/2.0f);
		  txtPoint.X-=(txtBox.Width/2.0f);
		  g.DrawString(text, new Font("Arial", 10), new SolidBrush(txtColor), txtPoint);
		}//IF text.Length>0

	  }//IF in drawable size
	}

	/// <summary>
	/// Saves (Serializes) the Actor to the given XmlTextWriter.
	/// SImilar to the UseCase.SaveTo(XmlTextWriter) method, except for the
	/// name of the Element (which is "Actor" in this case).
	/// </summary>
	/// <param name="x">The XmlTextWriter to which the Actor whould be saved.</param>
	public override void SaveTo(XmlTextWriter x)
	{
	  x.WriteStartElement("Actor", null);
	  x.WriteAttributeString("Width", width.ToString());
	  x.WriteAttributeString("Height", height.ToString());
	  x.WriteAttributeString("Filled", filled.ToString());
	  x.WriteAttributeString("Color", color.ToArgb().ToString());
	  x.WriteAttributeString("Bordered", bordered.ToString());
	  x.WriteAttributeString("BrdColor", brdColor.ToArgb().ToString());
	  x.WriteAttributeString("Text", text);
	  x.WriteAttributeString("TxtColor", txtColor.ToArgb().ToString());

	  x.WriteStartElement("TopLeft", null);
	  anchors[0].SaveTo(x);
	  x.WriteEndElement();

	  x.WriteEndElement();

	  x.Flush();
	}

	#endregion

  }
}
