#region Copyright
/*
 * File Name: CommunicationDisplay.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.Text;

#endregion

namespace myUML
{
  /// <summary>
  /// The Coordinate enum is defined to describe the two possible
  /// coordinates that a PointCoordChangedEvent might be dealing with:
  /// X	The X coordinate;
  /// Y	The Y coordinate.
  /// </summary>
  public enum Coordinate
  {
	X,
	Y
  }

  #region EventArguments and Delegates

  /// <summary>
  /// The PointCoordChangedEventArgs class is defined to describe the arguments
  /// of a PointCoordChanged event.
  /// </summary>
  public class PointCoordChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new value of the coordinate that has been changed (in the form of a string).
	/// </summary>
	public string				  NewCoordinate	="";
	/// <summary>
	/// The CommunicationAnchors value indicating which Anchor was changed.
	/// </summary>
	public CommunicationAnchors	  Point			=CommunicationAnchors.None;
	/// <summary>
	/// The Coordinate value indicating which coordinate was changed.
	/// </summary>
	public Coordinate			  Coord			=Coordinate.X;

	/// <summary>
	/// Instanciates a new PointCoordChangedEventArgs object, with the NewCoordinate,
	/// Point and Coord properties set as specified by the parameters.
	/// </summary>
	/// <param name="inVal">The new value of the coordinate, in the form of a string.</param>
	/// <param name="inP">The COmmunicationAnchors value indicating which Anchor was changed.</param>
	/// <param name="inC">The Coordinate value indicating which coordinate was changed.</param>
	public PointCoordChangedEventArgs(string inVal, CommunicationAnchors inP, Coordinate inC)
	{
	  NewCoordinate = inVal;
	  Point = inP;
	  Coord = inC;
	}
  }
  /// <summary>
  /// Signature of the Event Handler for a PointCoordChanged event.
  /// </summary>
  public delegate void PointCoordChangedHandler(object sender, PointCoordChangedEventArgs e);

  /// <summary>
  /// The ArrowsChangedEventArgs class is defined to describe the arguments
  /// of a ArrowsChanged event.
  /// </summary>
  public class ArrowsChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new ArrowEnds value.
	/// </summary>
	public ArrowEnds			NewArrows = ArrowEnds.None;

	/// <summary>
	/// Instanciates a new ArrowsChangedEventArgs object, with the NewArrows property
	/// set as specified by the parameter.
	/// </summary>
	/// <param name="inA">The new ArrowEnds value.</param>
	public ArrowsChangedEventArgs(ArrowEnds inA)
	{
	  NewArrows = inA;
	}
  }
  /// <summary>
  /// Signature of the Event Handler for a ArrowsChanged event.
  /// </summary>
  public delegate void ArrowsChangedHandler(object sender, ArrowsChangedEventArgs e);

  /// <summary>
  /// The ColorChangedEventArgs class is defined to describe the arguments
  /// of a ColorChanged event.
  /// </summary>
  public class ColorChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new Color.
	/// </summary>
	public Color				NewColor = Color.Black;

	/// <summary>
	/// Instanciates a new ColorChangedEventArgs object, with the NewColor property
	/// set as specified by the parameter.
	/// </summary>
	/// <param name="inC">The new Color value.</param>
	public ColorChangedEventArgs(Color inC)
	{ NewColor=inC; }
  }
  /// <summary>
  /// Signature of the Event Handler for a ColorChanged event.
  /// </summary>
  public delegate void ColorChangedHandler(object sender, ColorChangedEventArgs e);

  #endregion

  /// <summary>
  /// The CommunicationDisplay control is defined to let a client application display
  /// the details regarding a given Communication object.
  /// The CommunicationDisplay class inherits from the System.Windows.Forms.UserControl
  /// class.
  /// </summary>
  public class CommunicationDisplay : System.Windows.Forms.UserControl
  {
	#region Constants

	/// <summary>
	/// Index, in the cBox_Arrows ComboBox, of the "None" option.
	/// </summary>
	private const int ARROWS_NONE_INDEX	  =0;
	/// <summary>
	/// Index, in the cBox_Arrows ComboBox, of the "Starting" option.
	/// </summary>
	private const int ARROWS_START_INDEX  =1;
	/// <summary>
	/// Index, in the cBox_Arrows ComboBox, of the "Ending" option.
	/// </summary>
	private const int ARROWS_END_INDEX	  =2;
	/// <summary>
	/// Index, in the cBox_Arrows ComboBox, of the "Both" option.
	/// </summary>
	private const int ARROWS_BOTH_INDEX	  =3;

	#endregion

	#region Private Data Fields

	/// <summary>
	/// The Color of the Communication, as set by the user via GUI.
	/// </summary>
	private	Color		  saveColor		=Color.White;
	/// <summary>
	/// The string representation of the X coordinate of the Start Anchor
	/// of the Communication, as set by the user via GUI.
	/// </summary>
	private	string		  saveStartX	="";
	/// <summary>
	/// The string representation of the Y coordinate of the Start Anchor
	/// of the Communication, as set by the user via GUI.
	/// </summary>
	private string		  saveStartY	="";
	/// <summary>
	/// The string representation of the X coordinate of the End Anchor
	/// of the Communication, as set by the user via GUI.
	/// </summary>
	private string		  saveEndX		="";
	/// <summary>
	/// The string representation of the Y coordinate of the End Anchor
	/// of the Communication, as set by the user via GUI.
	/// </summary>
	private string		  saveEndY		="";
	/// <summary>
	/// The Arrows property of the Communication, as set by the user via GUI.
	/// </summary>
	private	int			  saveArrowsNdex=ARROWS_NONE_INDEX;
	/// <summary>
	/// Private flag, set to true when the values displayed in the GUI elements
	/// are being modified because of the internals of the CommunicationDisplay.
	/// </summary>
	private bool		  initializing	=false;
	/// <summary>
	/// Private flag indicating when the CommunicationDisplay holds no
	/// Communication to be displayed.
	/// </summary>
	private bool		  noCommunication=true;

	#endregion

	#region Events

	/// <summary>
	/// A PointCoordChanged event is fired when one of the coordinates
	/// displayed by the CommunicationDisplay (Start Anchor's X and Y, and End
	/// Anchor's X and Y) is properly modified by the user. Note that this event
	/// is fired only after the text boxes used for specifying the coordinates
	/// loose focus.
	/// </summary>
	public event PointCoordChangedHandler PointCoordChanged;
	/// <summary>
	/// An ArrowsChanged event is fired when the item selected in the
	/// Arrows ComboBox is changed by the user.
	/// </summary>
	public event ArrowsChangedHandler	  ArrowsChanged;
	/// <summary>
	/// A ColorChanged event is fired when the user selects a new Color
	/// for the Communication.
	/// </summary>
	public event ColorChangedHandler	  ColorChanged;

	#endregion

	#region Private GUI Controls

    private System.Windows.Forms.Label lbl_Start;
    private System.Windows.Forms.Label lbl_StartX;
    private System.Windows.Forms.TextBox tBox_StartX;
    private System.Windows.Forms.TextBox tBox_StartY;
    private System.Windows.Forms.Label lbl_StartY;
    private System.Windows.Forms.TextBox tBox_EndY;
    private System.Windows.Forms.Label lbl_EndY;
    private System.Windows.Forms.TextBox tBox_EndX;
    private System.Windows.Forms.Label lbl_EndX;
    private System.Windows.Forms.Label lbl_End;
    private System.Windows.Forms.Label lbl_Arrows;
    private System.Windows.Forms.ComboBox cBox_Arrows;
    private System.Windows.Forms.Label lbl_Color;
    private System.Windows.Forms.Button btn_ColorPick;
    private System.Windows.Forms.Panel pnl_Color;

	/// <summary> 
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	#endregion

	#region Public Attributes

	/// <summary>
	/// Gets or sets the Communication displayed by the CommunicationDisplay.
	/// If the CommunicationDisplay is not displaying any communication, it
	/// returns null.
	/// If this property is set to null, the CommunicationDisplay is set
	/// to display no Communication.
	/// </summary>
	public Communication  Communication
	{
	  get
	  {
		if(noCommunication)
		  return null;
		Communication r = new Communication();
		r.Start=new Anchor(new PointF(float.Parse(saveStartX), float.Parse(saveStartY)) );
		r.End=new Anchor(new PointF(float.Parse(saveEndX), float.Parse(saveEndY)) );
		r.Mid=myUML.Anchor.MidAnchor(r.Start, r.End);
		switch(saveArrowsNdex)
		{
		  case ARROWS_NONE_INDEX:	r.Arrows=ArrowEnds.None;	  break;
		  case ARROWS_START_INDEX:	r.Arrows=ArrowEnds.Starting;  break;
		  case ARROWS_END_INDEX:	r.Arrows=ArrowEnds.Ending;	  break;
		  case ARROWS_BOTH_INDEX:	r.Arrows=ArrowEnds.Both;	  break;
		  default:					r.Arrows=ArrowEnds.None;	  break;
		}//SWITCH
		r.Color = saveColor;
		return r;
	  }
	  set
	  {
		if(value==null)
		  InitEmpty();
		else
		  SaveCommunication(value);
	  }
	}

	#endregion

	#region Constructors

	/// <summary>
	/// Default Constructors: instanciates a CommunicationDisplay set to
	/// display no Communication.
	/// </summary>
	public CommunicationDisplay()
	{
	  // This call is required by the Windows.Forms Form Designer.
	  InitializeComponent();

	  InitEmpty();
	}
	/// <summary>
	/// Parameterized Constructor: Instanciates a CommunicationDisplay set
	/// to display the given Communication.
	/// </summary>
	/// <param name="inC">The Communication to be displayed.</param>
	public CommunicationDisplay(Communication inC)
	{
	  // This call is required by the Windows.Forms Form Designer.
	  InitializeComponent();

	  SaveCommunication(inC);
	}

	#endregion

	#region Private Methods

	/// <summary>
	/// Sets the CommunicationDisplay to display no communication.
	/// Disables all of the GUI controls of the CommunicationDisplay.
	/// </summary>
	private void InitEmpty()
	{
	  initializing = true;
	  saveColor		  = Color.White;
	  saveStartX	  = "0";
	  saveStartY	  = "0";
	  saveEndX		  = "0";
	  saveEndY		  = "0";
	  saveArrowsNdex  = ARROWS_NONE_INDEX;
	  UpdateGUI();
	  noCommunication=true;
	  this.tBox_StartX.Enabled=false;
	  this.tBox_StartY.Enabled=false;
	  this.tBox_EndX.Enabled=false;
	  this.tBox_EndY.Enabled=false;
	  this.cBox_Arrows.Enabled=false;
	  this.btn_ColorPick.Enabled=false;

	  initializing = false;
	}
	/// <summary>
	/// Sets the CommunicationDisplay to display the given Communication.
	/// Enables all of the GUI Controls of the CommunicationDisplay.
	/// </summary>
	/// <param name="inC">The Communication to be displayed.</param>
	private void SaveCommunication(Communication inC)
	{
	  initializing=true;
	  saveColor		  = inC.Color;
	  saveStartX	  = inC.Start.CenterX.ToString();
	  saveStartY	  = inC.Start.CenterY.ToString();
	  saveEndX		  = inC.End.CenterX.ToString();
	  saveEndY		  = inC.End.CenterY.ToString();
	  switch(inC.Arrows)
	  {
		case ArrowEnds.None:	saveArrowsNdex=ARROWS_NONE_INDEX;	break;
		case ArrowEnds.Starting:saveArrowsNdex=ARROWS_START_INDEX;	break;
		case ArrowEnds.Ending:	saveArrowsNdex=ARROWS_END_INDEX;	break;
		case ArrowEnds.Both:	saveArrowsNdex=ARROWS_BOTH_INDEX;	break;
		default:													break;
	  }
	  UpdateGUI();
	  this.tBox_StartX.Enabled=true;
	  this.tBox_StartY.Enabled=true;
	  this.tBox_EndX.Enabled=true;
	  this.tBox_EndY.Enabled=true;
	  this.cBox_Arrows.Enabled=true;
	  this.btn_ColorPick.Enabled=true;
	  noCommunication=false;
	  initializing = false;
	}
	/// <summary>
	/// Updates the GUI Control of the CommunicationDisplay to match
	/// the values in the private fields of the CommunicationDisplay.
	/// </summary>
	private void UpdateGUI()
	{
	  this.tBox_StartX.Text=saveStartX;
	  this.tBox_StartY.Text=saveStartY;

	  this.tBox_EndX.Text=saveEndX;
	  this.tBox_EndY.Text=saveEndY;

	  switch(saveArrowsNdex)
	  {
		case ARROWS_NONE_INDEX:		this.cBox_Arrows.SelectedIndex=ARROWS_NONE_INDEX;	break;
		case ARROWS_START_INDEX:	this.cBox_Arrows.SelectedIndex=ARROWS_START_INDEX;	break;
		case ARROWS_END_INDEX:		this.cBox_Arrows.SelectedIndex=ARROWS_END_INDEX;	break;
		case ARROWS_BOTH_INDEX:		this.cBox_Arrows.SelectedIndex=ARROWS_BOTH_INDEX;	break;
		default:					this.cBox_Arrows.SelectedIndex=ARROWS_NONE_INDEX;	break;
	  }//SWITCH on arrows

	  this.pnl_Color.BackColor=saveColor;
	}
	/// <summary>
	/// Announces (via MessageBox) that the specified coordinate
	/// is invalid.
	/// </summary>
	/// <param name="s">The string representation of the invalid coordinate.</param>
	private void AnnounceBadCoordinate(string s)
	{
	  StringBuilder sb = new StringBuilder("The value you specified for the point's coordinate\n");
	  sb.Append("("+s+") is not a valid point coordinate.\n");
	  sb.Append("The point's coordinate will be reset to its previous value.\n");
	  MessageBox.Show(this, sb.ToString(), "Invalid Coordinate:");
	}

	#region Handle events from the GUI Controls

	/// <summary>
	/// Handles the Leave (i.e. LooseFocus) event for the text boxes used to
	/// display the coordinates of the Communication's Anchors.
	/// The new coordinate is validated (see ValidPointCoord method). If
	/// the new coordinate is valid (and different from the previous value
	/// of the same coordinate), the OnPointCoordChanged method is invoked
	/// to fire a new PointCoordChanged event. If the new coordinate is invalid,
	/// the AnnounceBadCoordinate method is invoked.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void pointCoords_LooseFocus(object sender, System.EventArgs e)
	{
	  TextBox tbox = sender as TextBox;
	  if(tbox==null)  return;

	  string ntxt = tbox.Text;
	  string otxt ="";
	  CommunicationAnchors whichPoint = CommunicationAnchors.None;
	  Coordinate whichCoord = Coordinate.X;

	  switch(tbox.Name)
	  {
		case "tBox_StartX":
		  otxt = saveStartX;
		  whichCoord=Coordinate.X;
		  whichPoint = CommunicationAnchors.Start;
		  break;
		case "tBox_StartY":
		  otxt = saveStartY;
		  whichCoord=Coordinate.Y;
		  whichPoint = CommunicationAnchors.Start;
		  break;
		case "tBox_EndX":
		  otxt = saveEndX;
		  whichCoord=Coordinate.X;
		  whichPoint = CommunicationAnchors.End;
		  break;
		case "tBox_EndY":
		  otxt = saveEndY;
		  whichCoord=Coordinate.Y;
		  whichPoint = CommunicationAnchors.End;
		  break;
		default:
		  break;
	  }//SWITCH on tbox's name
	  if(ValidPointCoord(ntxt))
	  {
		//Save the new value:
		switch(tbox.Name)
		{
		  case "tBox_StartX":
			saveStartX = ntxt;
			break;
		  case "tBox_StartY":
			saveStartY = ntxt;
			break;
		  case "tBox_EndX":
			saveEndX = ntxt;
			break;
		  case "tBox_EndY":
			saveEndY = ntxt;
			break;
		  default:
			break;
		}//SWITCH on tbox's name
		if(!initializing)
		  OnPointCoordChanged(new PointCoordChangedEventArgs(ntxt, whichPoint, whichCoord));
	  }
	  else
	  {
		AnnounceBadCoordinate(ntxt);
		tbox.Text=otxt;
	  }
	}

	/// <summary>
	/// Handles the SelectedIndexChanged event of the cBox_Arrows ComboBox.
	/// If the new selected index is different than the previous one,
	/// the OnArrowsChanged method is invoked to fire a new ArrowsChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void cBox_Arrows_SelectedIndexChanged(object sender, System.EventArgs e)
	{
	  int newNdex = this.cBox_Arrows.SelectedIndex;
	  if(newNdex!=saveArrowsNdex)
	  {
		saveArrowsNdex=newNdex;
		ArrowEnds ae = ArrowEnds.None;
		switch(saveArrowsNdex)
		{
		  case ARROWS_NONE_INDEX:	  ae=ArrowEnds.None;	  break;
		  case ARROWS_START_INDEX:	  ae=ArrowEnds.Starting;  break;
		  case ARROWS_END_INDEX:	  ae=ArrowEnds.Ending;	  break;
		  case ARROWS_BOTH_INDEX:	  ae=ArrowEnds.Both;	  break;
		  default:					  ae=ArrowEnds.None;	  break;
		}
		if(!initializing)
		  OnArrowsChanged(new ArrowsChangedEventArgs(ae));
	  }
	}

	/// <summary>
	/// Handles the Click event of the btn_ColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_Color panel is colored in the choosen Color, and
	/// the OnColorChanged method is invoked to fire a new ColorChanged
	/// event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_ColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveColor)
		{
		  saveColor = newColor;
		  this.pnl_Color.BackColor=saveColor;
		  if(!initializing)
			OnColorChanged(new ColorChangedEventArgs(saveColor));
		}
	  }
	}

	#endregion

	#endregion

	#region Protected Methods

	/// <summary> 
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
	  if( disposing )
	  {
		if(components != null)
		{
		  components.Dispose();
		}
	  }
	  base.Dispose( disposing );
	}

	#region Custom Event Handlers

	/// <summary>
	/// Fires a new PointCoordChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The PointCoordChangedEventArgs describing the event.</param>
	protected virtual void OnPointCoordChanged(PointCoordChangedEventArgs e)
	{ if(PointCoordChanged!=null) PointCoordChanged(this, e); }
	/// <summary>
	/// Fires a new ArrowsChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ArrowsChangedEventArgs describing the event.</param>
	protected virtual void OnArrowsChanged(ArrowsChangedEventArgs e)
	{ if(ArrowsChanged!=null) ArrowsChanged(this, e); }
	/// <summary>
	/// Fires a new ColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ColorChangedEventArgs describing the event.</param>
	protected virtual void OnColorChanged(ColorChangedEventArgs e)
	{ if(ColorChanged!=null) ColorChanged(this, e); }

	#endregion

	#endregion

		#region Component Designer generated code
	/// <summary> 
	/// Required method for Designer support - do not modify 
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.lbl_Start = new System.Windows.Forms.Label();
	  this.lbl_StartX = new System.Windows.Forms.Label();
	  this.tBox_StartX = new System.Windows.Forms.TextBox();
	  this.tBox_StartY = new System.Windows.Forms.TextBox();
	  this.lbl_StartY = new System.Windows.Forms.Label();
	  this.tBox_EndY = new System.Windows.Forms.TextBox();
	  this.lbl_EndY = new System.Windows.Forms.Label();
	  this.tBox_EndX = new System.Windows.Forms.TextBox();
	  this.lbl_EndX = new System.Windows.Forms.Label();
	  this.lbl_End = new System.Windows.Forms.Label();
	  this.lbl_Arrows = new System.Windows.Forms.Label();
	  this.cBox_Arrows = new System.Windows.Forms.ComboBox();
	  this.lbl_Color = new System.Windows.Forms.Label();
	  this.btn_ColorPick = new System.Windows.Forms.Button();
	  this.pnl_Color = new System.Windows.Forms.Panel();
	  this.SuspendLayout();
	  // 
	  // lbl_Start
	  // 
	  this.lbl_Start.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Start.Location = new System.Drawing.Point(10, 10);
	  this.lbl_Start.Name = "lbl_Start";
	  this.lbl_Start.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Start.TabIndex = 0;
	  this.lbl_Start.Text = "Start:";
	  this.lbl_Start.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_StartX
	  // 
	  this.lbl_StartX.Location = new System.Drawing.Point(70, 10);
	  this.lbl_StartX.Name = "lbl_StartX";
	  this.lbl_StartX.Size = new System.Drawing.Size(20, 20);
	  this.lbl_StartX.TabIndex = 1;
	  this.lbl_StartX.Text = "X=";
	  this.lbl_StartX.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_StartX
	  // 
	  this.tBox_StartX.Location = new System.Drawing.Point(100, 10);
	  this.tBox_StartX.Name = "tBox_StartX";
	  this.tBox_StartX.Size = new System.Drawing.Size(50, 20);
	  this.tBox_StartX.TabIndex = 2;
	  this.tBox_StartX.Text = "";
	  this.tBox_StartX.Leave += new System.EventHandler(this.pointCoords_LooseFocus);
	  // 
	  // tBox_StartY
	  // 
	  this.tBox_StartY.Location = new System.Drawing.Point(190, 10);
	  this.tBox_StartY.Name = "tBox_StartY";
	  this.tBox_StartY.Size = new System.Drawing.Size(50, 20);
	  this.tBox_StartY.TabIndex = 4;
	  this.tBox_StartY.Text = "";
	  this.tBox_StartY.Leave += new System.EventHandler(this.pointCoords_LooseFocus);
	  // 
	  // lbl_StartY
	  // 
	  this.lbl_StartY.Location = new System.Drawing.Point(160, 10);
	  this.lbl_StartY.Name = "lbl_StartY";
	  this.lbl_StartY.Size = new System.Drawing.Size(20, 20);
	  this.lbl_StartY.TabIndex = 3;
	  this.lbl_StartY.Text = "Y=";
	  this.lbl_StartY.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_EndY
	  // 
	  this.tBox_EndY.Location = new System.Drawing.Point(190, 40);
	  this.tBox_EndY.Name = "tBox_EndY";
	  this.tBox_EndY.Size = new System.Drawing.Size(50, 20);
	  this.tBox_EndY.TabIndex = 9;
	  this.tBox_EndY.Text = "";
	  this.tBox_EndY.Leave += new System.EventHandler(this.pointCoords_LooseFocus);
	  // 
	  // lbl_EndY
	  // 
	  this.lbl_EndY.Location = new System.Drawing.Point(160, 40);
	  this.lbl_EndY.Name = "lbl_EndY";
	  this.lbl_EndY.Size = new System.Drawing.Size(20, 20);
	  this.lbl_EndY.TabIndex = 8;
	  this.lbl_EndY.Text = "Y=";
	  this.lbl_EndY.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_EndX
	  // 
	  this.tBox_EndX.Location = new System.Drawing.Point(100, 40);
	  this.tBox_EndX.Name = "tBox_EndX";
	  this.tBox_EndX.Size = new System.Drawing.Size(50, 20);
	  this.tBox_EndX.TabIndex = 7;
	  this.tBox_EndX.Text = "";
	  this.tBox_EndX.Leave += new System.EventHandler(this.pointCoords_LooseFocus);
	  // 
	  // lbl_EndX
	  // 
	  this.lbl_EndX.Location = new System.Drawing.Point(70, 40);
	  this.lbl_EndX.Name = "lbl_EndX";
	  this.lbl_EndX.Size = new System.Drawing.Size(20, 20);
	  this.lbl_EndX.TabIndex = 6;
	  this.lbl_EndX.Text = "X=";
	  this.lbl_EndX.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_End
	  // 
	  this.lbl_End.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_End.Location = new System.Drawing.Point(10, 40);
	  this.lbl_End.Name = "lbl_End";
	  this.lbl_End.Size = new System.Drawing.Size(50, 20);
	  this.lbl_End.TabIndex = 5;
	  this.lbl_End.Text = "End:";
	  this.lbl_End.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_Arrows
	  // 
	  this.lbl_Arrows.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Arrows.Location = new System.Drawing.Point(10, 70);
	  this.lbl_Arrows.Name = "lbl_Arrows";
	  this.lbl_Arrows.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Arrows.TabIndex = 10;
	  this.lbl_Arrows.Text = "Arrows:";
	  this.lbl_Arrows.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // cBox_Arrows
	  // 
	  this.cBox_Arrows.Items.AddRange(new object[] {
													 "None",
													 "Starting",
													 "Ending",
													 "Both"});
	  this.cBox_Arrows.Location = new System.Drawing.Point(70, 70);
	  this.cBox_Arrows.Name = "cBox_Arrows";
	  this.cBox_Arrows.Size = new System.Drawing.Size(170, 21);
	  this.cBox_Arrows.TabIndex = 11;
	  this.cBox_Arrows.SelectedIndexChanged += new System.EventHandler(this.cBox_Arrows_SelectedIndexChanged);
	  // 
	  // lbl_Color
	  // 
	  this.lbl_Color.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Color.Location = new System.Drawing.Point(10, 100);
	  this.lbl_Color.Name = "lbl_Color";
	  this.lbl_Color.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Color.TabIndex = 12;
	  this.lbl_Color.Text = "Color:";
	  this.lbl_Color.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // btn_ColorPick
	  // 
	  this.btn_ColorPick.Location = new System.Drawing.Point(180, 100);
	  this.btn_ColorPick.Name = "btn_ColorPick";
	  this.btn_ColorPick.Size = new System.Drawing.Size(60, 20);
	  this.btn_ColorPick.TabIndex = 14;
	  this.btn_ColorPick.Text = "&Pick...";
	  this.btn_ColorPick.Click += new System.EventHandler(this.btn_ColorPick_Click);
	  // 
	  // pnl_Color
	  // 
	  this.pnl_Color.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_Color.ForeColor = System.Drawing.Color.Transparent;
	  this.pnl_Color.Location = new System.Drawing.Point(70, 100);
	  this.pnl_Color.Name = "pnl_Color";
	  this.pnl_Color.Size = new System.Drawing.Size(100, 20);
	  this.pnl_Color.TabIndex = 20;
	  // 
	  // CommunicationDisplay
	  // 
	  this.Controls.AddRange(new System.Windows.Forms.Control[] {
																  this.pnl_Color,
																  this.btn_ColorPick,
																  this.lbl_Color,
																  this.cBox_Arrows,
																  this.lbl_Arrows,
																  this.tBox_EndY,
																  this.lbl_EndY,
																  this.tBox_EndX,
																  this.lbl_EndX,
																  this.lbl_End,
																  this.tBox_StartY,
																  this.lbl_StartY,
																  this.tBox_StartX,
																  this.lbl_StartX,
																  this.lbl_Start});
	  this.Name = "CommunicationDisplay";
	  this.Size = new System.Drawing.Size(250, 190);
	  this.ResumeLayout(false);

	}
		#endregion


	#region Public Methods

	/// <summary>
	/// Determines whether the given string represents a valid coordinate
	/// for one of the Communication's Anchors.
	/// </summary>
	/// <param name="s">The string to be validated.</param>
	/// <returns>true if the string s represents a valid float value; false otherwise.</returns>
	public bool ValidPointCoord(string s)
	{
	  try
	  {
		float f = float.Parse(s);
	  }
	  catch(Exception)
	  {
		return false;
	  }
	  return true;
	}

	#endregion

  }
}
