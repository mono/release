#region Copyright
/*
 * File Name: IUMLtoXML.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Xml;

#endregion

namespace myUML
{
  /// <summary>
  /// The IUMLtoXML interface defines methods that should allow the
  /// transformation of objects (of the myUML Project) to and from
  /// XML format.
  /// </summary>
  public interface IUMLtoXML
  {
	/// <summary>
	/// The implementation of this method should serialize the object in
	/// properly formatted XML format, and send it to the stream
	/// underlying the given XmlTextWriter.
	/// </summary>
	/// <param name="x">The XmlTextWriter to which the object should be saved.</param>
	void SaveTo(XmlTextWriter x);
	/// <summary>
	/// The implementation of this method should de-serialize the object
	/// from the stream underlying the given XmltextReader. The format of
	/// the XML element from which the object should be de-serialized is
	/// un-defined, but should be defined by the same class' implementation
	/// of the SaveTo method.
	/// </summary>
	/// <param name="x">The XmltextReader from which the object should be read.</param>
	void ReadFrom(XmlTextReader x);
  }
}
