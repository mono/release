#region Copyright
/*
 * File Name: TestEntry.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

#endregion

namespace myUML
{
  /// <summary>
  /// The TestEntry class is defined to provide a single entry point to the
  /// Testing environment for the myUML Project. It simply
  /// displays a form with a series of buttons, each leading to a
  /// different testing environment, where different functionalities of
  /// the project may be tested.
  /// The TestEntry class inherits from the System.Windows.Forms.Form class.
  /// </summary>
  public class TestEntry : System.Windows.Forms.Form
  {
    private System.Windows.Forms.Button btn_TestUseCases;
	/// <summary>
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	public TestEntry()
	{
	  //
	  // Required for Windows Form Designer support
	  InitializeComponent();
	}

	/// <summary>
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
	  if( disposing )
	  {
		if (components != null) 
		{
		  components.Dispose();
		}
	  }
	  base.Dispose( disposing );
	}

		#region Windows Form Designer generated code
	/// <summary>
	/// Required method for Designer support - do not modify
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.btn_TestUseCases = new System.Windows.Forms.Button();
	  this.SuspendLayout();
	  // 
	  // btn_TestUseCases
	  // 
	  this.btn_TestUseCases.Location = new System.Drawing.Point(50, 50);
	  this.btn_TestUseCases.Name = "btn_TestUseCases";
	  this.btn_TestUseCases.Size = new System.Drawing.Size(200, 20);
	  this.btn_TestUseCases.TabIndex = 0;
	  this.btn_TestUseCases.Text = "Test &Use Cases";
	  this.btn_TestUseCases.Click += new System.EventHandler(this.btn_TestUseCases_Click);
	  // 
	  // TestEntry
	  // 
	  this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
	  this.ClientSize = new System.Drawing.Size(292, 366);
	  this.Controls.AddRange(new System.Windows.Forms.Control[] {
																  this.btn_TestUseCases});
	  this.Name = "TestEntry";
	  this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
	  this.Text = "Test myUML";
	  this.ResumeLayout(false);

	}
		#endregion

	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main() 
	{
	  Application.Run(new TestEntry());
	}

    private void btn_TestUseCases_Click(object sender, System.EventArgs e)
	{
	  TestUseCases tuc = new TestUseCases();
	  DialogResult dr = tuc.ShowDialog(this);
	}
  }
}
