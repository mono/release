#region Copyright
/*
 * File Name: ActorDisplay.cs
 * Project:	  myUML
 * Version:	  0.10	23-SEP-2K3
 * Author:	  FR
 * 
 * Copyright:	  This code belongs to the myUML project.
 *				  All of the code in the myUML project is
 *				  provided "as-is", for non-commercial purpose.
 *				  Feel free to use the code as you see fit
 *				  for any non-commercial purpose, provided you
 *				  credit the author in your source code.
 *				  Since the myUML project is provided
 *				  "as-is", the author does not assume any
 *				  responsibility for any problem you may incur
 *				  by using the code in the project.
 *				  Feedback is appreciated (see the
 *				  "Contact" section below), and the
 *				  author will provided proper credit as needed.
 *				  If you intend to use this code in any commercial
 *				  application, you must contact the author and
 *				  receive proper authorization.
 * 
 * Contact:		  Frank "Olorin" Rizzi: fkh1000@yahoo.com
 * 
 * History:
 * v.1.0		  23-SEP-2K3
 *				  First Draft, by FR.
 * 
 */
#endregion

#region External Dependencies

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

using System.Text;

#endregion

namespace myUML
{
  #region EventArguments and Delegates

  /// <summary>
  /// The ActorLocationChangedEventArgs class is defined to describe the arguments
  /// of a ActorLocationChanged event.
  /// </summary>
  public class ActorLocationChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The Coordinate value indicating which coordinate was changed.
	/// </summary>
	public Coordinate			  Coord			=Coordinate.X;
	/// <summary>
	/// The new value of the coordinate, in the form of a float value.
	/// </summary>
	public float				  NewCoordinate	=0.0f;

	/// <summary>
	/// Instanciates a new ActorLocationChangedEventArgs object, with the Coord,
	/// and NewCoordinate properties set as specified by the parameters.
	/// </summary>
	/// <param name="inC">The Coordinate value indicating which coordinate was changed.</param>
	/// <param name="inf">The new value of the coordinate, in the form of a float value.</param>
	public ActorLocationChangedEventArgs(Coordinate inC, float inf)
	{
	  Coord = inC;
	  NewCoordinate = inf;
	}
  }
  /// <summary>
  /// Signature of the Event Handler for a ActorLocationChanged event.
  /// </summary>
  public delegate void ActorLocationChangedEventHandler(object sender,
  ActorLocationChangedEventArgs e);

  /// <summary>
  /// The ActorResizeEventArgs class is defined to describe the arguments
  /// of a ActorResize event.
  /// </summary>
  public class ActorResizeEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new width of the Actor.
	/// </summary>
	public	float		Width =0.0f;
	/// <summary>
	/// The new height of the Actor.
	/// </summary>
	public	float		Height=0.0f;

	/// <summary>
	/// Instanciates a new ActorResizeEventArgs object, with the WIdth,
	/// and Height properties set as specified by the parameters.
	/// </summary>
	/// <param name="newW">The new width of the Actor..</param>
	/// <param name="newH">The new height of the Actor.</param>
	public ActorResizeEventArgs(float newW, float newH)
	{
	  Width=newW;
	  Height=newH;
	}
  }
  /// <summary>
  /// Signature of the Event Handler for a ActorResize event.
  /// </summary>
  public delegate void ActorResizeEventHandler(object sender, ActorResizeEventArgs e);

  /// <summary>
  /// The ActorFilledChangedEventArgs class is defined to describe the arguments
  /// of a ActorFilledChanged event.
  /// </summary>
  public class ActorFilledChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new value of the Actor's Filled property.
	/// </summary>
	public bool			Filled	=false;

	/// <summary>
	/// Instanciates a new ActorFilledChangedEventArgs with the Filled property set
	/// as indicated by the parameter.
	/// </summary>
	/// <param name="b">The new value of the Actor's Filled property.</param>
	public ActorFilledChangedEventArgs(bool b) : base()
	{ Filled=b; }
  }
  /// <summary>
  /// Signature of the Event Handler for a ActorFilledChanged event.
  /// </summary>
  public delegate void ActorFilledChangedEventHandler(object sender, ActorFilledChangedEventArgs e);

  /// <summary>
  /// The ActorBorderedChangedEventArgs class is defined to describe the arguments
  /// of a ActorBorderedChanged event.
  /// </summary>
  public class ActorBorderedChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new value of the Actor's Bordered property.
	/// </summary>
	public bool			Bordered	=false;

	/// <summary>
	/// Instanciates a new ActorBorderedChangedEventArgs with the Bordered
	/// property set as indicated by the parameter.
	/// </summary>
	/// <param name="b">The new value of the Actor's Bordered property.</param>
	public ActorBorderedChangedEventArgs(bool b) : base()
	{ Bordered=b; }
  }
  /// <summary>
  /// Signature of the Event Handler for a ActorBorderedChanged event.
  /// </summary>
  public delegate void ActorBorderedChangedEventHandler(object sender,
  ActorBorderedChangedEventArgs e);

  /// <summary>
  /// The ActorColorChangedEventArgs class is defined to describe the arguments
  /// of a ActorColorChanged event.
  /// </summary>
  public class ActorColorChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new Color of the Actor.
	/// </summary>
	public Color				NewColor = Color.Black;

	/// <summary>
	/// Instanciates a new ActorColorChangedEventARgs with the NewColor
	/// property set as indicated by the parameter.
	/// </summary>
	/// <param name="inC">The new Color of the Actor.</param>
	public ActorColorChangedEventArgs(Color inC) : base()
	{ NewColor=inC; }
  }
  /// <summary>
  /// Signature of the Event handler for a ActorColorChanged event.
  /// </summary>
  public delegate void ActorColorChangedHandler(object sender, ActorColorChangedEventArgs e);
  /// <summary>
  /// Signature of the Event handler for a ActorTextColorChanged event.
  /// </summary>
  public delegate void ActorTextColorChangedHandler(object sender, ActorColorChangedEventArgs e);
  /// <summary>
  /// Signature of the Event handler for a ActorBorderColorChanged event.
  /// </summary>
  public delegate void ActorBorderColorChangedHandler(object sender, ActorColorChangedEventArgs e);

  /// <summary>
  /// The ActorTextChangedEventArgs class is defined to describe the arguments
  /// of a ActorTextChanged event.
  /// </summary>
  public class ActorTextChangedEventArgs : System.EventArgs
  {
	/// <summary>
	/// The new Text of the Actor.
	/// </summary>
	public string				NewText	="";

	/// <summary>
	/// Instanciates a new ActorTextChangedEventArgs with the NewText
	/// property set as indicated by the parameter.
	/// </summary>
	/// <param name="inT">The new Text of the Actor.</param>
	public ActorTextChangedEventArgs(string inT) : base()
	{ NewText = inT; }
  }
  /// <summary>
  /// Signature of the Event Handler for a ActorTextChanged event.
  /// </summary>
  public delegate void ActorTextChangedHandler(object sender, ActorTextChangedEventArgs e);

  #endregion

  /// <summary>
  /// The ActorDisplay control is defined to let a client application display
  /// the details regarding a given Actor object.
  /// The ActorDisplay class inherits from the System.Windows.Forms.UserControl
  /// class.
  /// </summary>
  public class ActorDisplay : System.Windows.Forms.UserControl
  {
	#region Private Data Fields

	/// <summary>
	/// The string representation of the X coordinate of the Actor's
	/// Top-Left Anchor.
	/// </summary>
	private string		  saveX	="";
	/// <summary>
	/// The string representation of the Y coordinate of the Actor's
	/// Top-Left Anchor.
	/// </summary>
	private string		  saveY	="";
	/// <summary>
	/// The string representation of the Actor's width.
	/// </summary>
	private	string		  saveW	="";
	/// <summary>
	/// The string representation of the Actor's height.
	/// </summary>
	private string		  saveH	="";
	/// <summary>
	/// The value of the Actor's Filled property.
	/// </summary>
	private	bool		  saveFilled  =false;
	/// <summary>
	/// The Color of the Actor.
	/// </summary>
	private	Color		  saveColor	  =Color.White;
	/// <summary>
	/// The value of the Actor's Bordered property.
	/// </summary>
	private bool		  saveBordered=true;
	/// <summary>
	/// The BrdColor property of the Actor.
	/// </summary>
	private Color		  saveBrdColor=Color.Black;
	/// <summary>
	/// The Text of the Actor.
	/// </summary>
	private string		  saveText	  ="";
	/// <summary>
	/// The TxtColor property of the Actor.
	/// </summary>
	private Color		  saveTxtColor=Color.Black;
	/// <summary>
	/// Private flag, set to true when the values displayed in the GUI elements
	/// are being modified because of the internals of the ActorDisplay.
	/// </summary>
	private bool		  initializing=false;
	/// <summary>
	/// Private flag indicating when the ActorDisplay holds no
	/// Actor to be displayed.
	/// </summary>
	private bool		  noActor=true;

	#endregion

	#region Events

	/// <summary>
	/// A ActorLocationChanged event is fired when one of the coordinates
	/// displayed by the ActorDisplay (the Actor's Location X and Y
	/// coordinate) is properly modified by the user. Note that this event
	/// is fired only after the text boxes used for specifying the coordinates
	/// loose focus.
	/// </summary>
	public event ActorLocationChangedEventHandler ActorLocationChanged;
	/// <summary>
	/// A ActorResize event is fired when one of the dimensions of
	/// the Actor (width or height) is properly modified by the user.
	/// Note that the event is fired only after the text box displaying
	/// the coordinate has lost focus.
	/// </summary>
	public event ActorResizeEventHandler			ActorResized;
	/// <summary>
	/// A ActorFilledChanged event is fired when the user changes the
	/// value of the check_Filled checkbox to change the Filled property
	/// of the Actor.
	/// </summary>
	public event ActorFilledChangedEventHandler	ActorFilledChanged;
	/// <summary>
	/// A ActorBorderedChanged event is fired when the user changes the
	/// value of the check_Bordered checkbox to change the Bordered property
	/// of the Actor.
	/// </summary>
	public event ActorBorderedChangedEventHandler	ActorBorderedChanged;
	/// <summary>
	/// A ActorColorChanged event is fired when the user changes the Color
	/// of the Actor.
	/// </summary>
	public event ActorColorChangedHandler			ActorColorChanged;
	/// <summary>
	/// A ActorTextColorChanged event is fired when the user changes the
	/// TxtColor of the Actor.
	/// </summary>
	public event ActorTextColorChangedHandler		ActorTextColorChanged;
	/// <summary>
	/// A ActorBorderColor event is fired when the user changes the
	/// BrdColor of the Actor.
	/// </summary>
	public event ActorBorderColorChangedHandler	ActorBorderColorChanged;
	/// <summary>
	/// A ActorTextChanged event is fired when the user changes the
	/// Text associated with the Actor. Note that this event is fired
	/// every time the text in the tBox_Text textbox is changed.
	/// </summary>
	public event ActorTextChangedHandler			ActorTextChanged;

	#endregion

	#region GUI Controls

	private System.Windows.Forms.Panel pnl_TxtColor;
	private System.Windows.Forms.Panel pnl_BrdColor;
	private System.Windows.Forms.Panel pnl_Color;
	private System.Windows.Forms.Button btn_TxtColorPick;
	private System.Windows.Forms.Label lbl_TextColor;
	private System.Windows.Forms.TextBox tBox_Text;
	private System.Windows.Forms.Label lbl_Text;
	private System.Windows.Forms.Button btn_BrdColorPick;
	private System.Windows.Forms.CheckBox check_Bordered;
	private System.Windows.Forms.Label lbl_Bordered;
	private System.Windows.Forms.Button btn_ColorPick;
	private System.Windows.Forms.CheckBox check_Filled;
	private System.Windows.Forms.Label lbl_Filled;
	private System.Windows.Forms.TextBox tBox_Height;
	private System.Windows.Forms.Label lbl_Height;
	private System.Windows.Forms.TextBox tBox_Width;
	private System.Windows.Forms.Label lbl_Width;
	private System.Windows.Forms.TextBox tBox_LocY;
	private System.Windows.Forms.Label lbl_LocY;
	private System.Windows.Forms.TextBox tBox_LocX;
	private System.Windows.Forms.Label lbl_LocX;
	private System.Windows.Forms.Label lbl_Location;
	/// <summary> 
	/// Required designer variable.
	/// </summary>
	private System.ComponentModel.Container components = null;

	#endregion

	#region Public Attributes

	/// <summary>
	/// Gets or sets the Actor displayed by the ActorDisplay.
	/// if the ActorDisplay is displaying no Actor, the attribute
	/// returns null.
	/// If this property is set ot null, the ActorDisplay is set
	/// to display no Actor.
	/// </summary>
	public Actor	Actor
	{
	  get
	  {
		if(noActor) return null;

		PointF tl = new PointF(float.Parse(saveX), float.Parse(saveY));
		float w = float.Parse(saveW);
		float h = float.Parse(saveH);
		Actor r = new Actor(tl, w, h);
		r.Filled=saveFilled;
		r.Color=saveColor;
		r.Bordered=saveBordered;
		r.BrdColor=saveBrdColor;
		r.Text = saveText;
		r.TxtColor = saveTxtColor;
		return r;
	  }
	  set
	  {
		if(value==null)
		  InitEmpty();
		else
		  SaveActor(value);
	  }
	}

	#endregion

	#region Constructors

	/// <summary>
	/// Parameterized Constructor: Instanciates a ActorDisplay set
	/// to display the given Actor.
	/// </summary>
	/// <param name="inA">The Actor to be displayed.</param>
	public ActorDisplay(Actor inA)
	{
	  // This call is required by the Windows.Forms Form Designer.
	  InitializeComponent();

	  SaveActor(inA);
	}
	/// <summary>
	/// Default Constructors: instanciates a ActorDisplay set to
	/// display no Actor.
	/// </summary>
	public ActorDisplay()
	{
	  // This call is required by the Windows.Forms Form Designer.
	  InitializeComponent();

	  InitEmpty();
	}

	#endregion

	#region Private Methods

	/// <summary>
	/// Sets the ActorDisplay to display no Actor.
	/// Disables all of the GUI controls of the ActorDisplay.
	/// </summary>
	private void InitEmpty()
	{
	  initializing=true;

	  saveX = "0";
	  saveY	= "0";
	  saveW	= "0";
	  saveH	= "0";
	  saveFilled  =false;
	  saveColor	  =Color.White;
	  saveBordered=true;
	  saveBrdColor=Color.Black;
	  saveText	  ="";
	  saveTxtColor=Color.Black;

	  UpdateGUI();
	  noActor=true;
	  this.tBox_LocX.Enabled=true;
	  this.tBox_LocY.Enabled=true;
	  this.tBox_Width.Enabled=true;
	  this.tBox_Height.Enabled=true;
	  this.check_Filled.Enabled=true;
	  this.btn_ColorPick.Enabled=true;
	  this.check_Bordered.Enabled=true;
	  this.btn_BrdColorPick.Enabled=true;
	  this.tBox_Text.Enabled=true;
	  this.btn_TxtColorPick.Enabled=true;

	  initializing=false;
	}
	/// <summary>
	/// Sets the ActorDisplay to display the given Actor.
	/// Enables all of the GUI Controls of the ActorDisplay.
	/// </summary>
	/// <param name="inA">The Actor to be displayed.</param>
	private void SaveActor(Actor inA)
	{
	  initializing=true;
	  saveX		  = inA[UseCaseAnchors.TopLeft].CenterX.ToString();
	  saveY		  = inA[UseCaseAnchors.TopLeft].CenterY.ToString();
	  saveW		  = inA.Width.ToString();
	  saveH		  = inA.Height.ToString();
	  saveFilled  = inA.Filled;
	  saveColor	  = inA.Color;
	  saveBordered= inA.Bordered;
	  saveBrdColor= inA.BrdColor;
	  saveText	  = inA.Text;
	  saveTxtColor= inA.TxtColor;

	  UpdateGUI();
	  noActor=false;
	  this.tBox_LocX.Enabled=true;
	  this.tBox_LocY.Enabled=true;
	  this.tBox_Width.Enabled=true;
	  this.tBox_Height.Enabled=true;
	  this.check_Filled.Enabled=true;
	  this.btn_ColorPick.Enabled=true;
	  this.check_Bordered.Enabled=true;
	  this.btn_BrdColorPick.Enabled=true;
	  this.tBox_Text.Enabled=true;
	  this.btn_TxtColorPick.Enabled=true;
	  initializing=false;
	}

	/// <summary>
	/// Updates the GUI Control of the ActorDisplay to match
	/// the values in the private fields of the ActorDisplay.
	/// </summary>
	private void UpdateGUI()
	{
	  this.tBox_LocX.Text=saveX;
	  this.tBox_LocY.Text=saveY;
	  this.tBox_Width.Text=saveW;
	  this.tBox_Height.Text=saveH;
	  this.check_Filled.Checked=saveFilled;
	  this.pnl_Color.BackColor=saveColor;
	  this.check_Bordered.Checked=saveBordered;
	  this.pnl_BrdColor.BackColor=saveBrdColor;
	  this.tBox_Text.Text=saveText;
	  this.pnl_TxtColor.BackColor=saveTxtColor;
	}
	/// <summary>
	/// Announces (via MessageBox) that the specified coordinate
	/// is invalid.
	/// </summary>
	/// <param name="s">The string representation of the invalid coordinate.</param>
	private void AnnounceBadCoordinate(string s)
	{
	  StringBuilder sb = new StringBuilder("The value you specified for the actor's location\n");
	  sb.Append("coordinate ("+s+") is not a valid coordinate.\n");
	  sb.Append("The coordinate will be reset to its previous value.\n");
	  MessageBox.Show(this, sb.ToString(), "Invalid Coordinate:");
	}
	/// <summary>
	/// Announces (via MessageBox) that the specified dimension
	/// is invalid.
	/// </summary>
	/// <param name="s">The string representation of the invalid dimension.</param>
	private void AnnounceBadDimension(string s)
	{
	  StringBuilder sb = new StringBuilder("The value you specified for the actor's dimension\n");
	  sb.Append("("+s+") is not a valid dimension.\n");
	  sb.Append("The dimension will be reset to its previous value.\n");
	  MessageBox.Show(this, sb.ToString(), "Invalid Dimension:");
	}

	#region Handle events from the GUI Controls

	/// <summary>
	/// Handles the Leave (i.e. LooseFocus) event for the text boxes used to
	/// display the coordinates of the Actor's Location.
	/// The new coordinate is validated (see ValidLocationCoordinate method). If
	/// the new coordinate is valid (and different from the previous value
	/// of the same coordinate), the OnLocationChanged method is invoked
	/// to fire a new ActorLocationChanged event. If the new coordinate is invalid,
	/// the AnnounceBadCoordinate method is invoked.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void locCoord_LooseFocus(object sender, System.EventArgs e)
	{
	  string ntxt ="";
	  string otxt ="";
	  Coordinate whichCoordinate = Coordinate.X;

	  TextBox tbox = sender as TextBox;
	  if(tbox==null)  return;

	  switch(tbox.Name)
	  {
		case "tBox_LocX":
		  otxt = saveX;
		  ntxt = this.tBox_LocX.Text;
		  whichCoordinate = Coordinate.X;
		  break;
		case "tBox_LocY":
		  otxt = saveY;
		  ntxt = this.tBox_LocY.Text;
		  whichCoordinate = Coordinate.Y;
		  break;
		default:
		  return;
	  }
	  float newVal = 0.0f;
	  if(ValidLocationCoordinate(ntxt, ref newVal))
	  {
		switch(whichCoordinate)
		{
		  case Coordinate.X:
			saveX = ntxt;
			break;
		  case Coordinate.Y:
			saveY = ntxt;
			break;
		  default:
			break;
		}
		if(!initializing)
		  OnLocationChanged(new ActorLocationChangedEventArgs(whichCoordinate, newVal));
	  }
	  else
	  {
		AnnounceBadCoordinate(ntxt);
		tbox.Text=otxt;
	  }
	}
	/// <summary>
	/// Handles the Leave (i.e. LooseFocus) event for the text boxes used to
	/// display the dimensions of the Actor.
	/// The new dimension is validated (see ValidDimension method). If
	/// the new dimension is valid (and different from the previous value
	/// of the same coordinate), the OnActorResized method is invoked
	/// to fire a new ActorResized event. If the new coordinate is invalid,
	/// the AnnounceBadDimension method is invoked.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void dimension_LooseFocus(object sender, System.EventArgs e)
	{
	  string ntxt ="";
	  string otxt ="";

	  TextBox tbox = sender as TextBox;
	  if(tbox==null)  return;

	  switch(tbox.Name)
	  {
		case "tBox_Width":
		  ntxt = this.tBox_Width.Text;
		  otxt = saveW;
		  break;
		case "tBox_Height":
		  ntxt = this.tBox_Height.Text;
		  otxt = saveH;
		  break;
		default:
		  return;
	  }
	  float f = 0.0f;
	  if(ValidDimension(ntxt, ref f))
	  {
		switch(tbox.Name)
		{
		  case "tBox_Width":
			saveW=ntxt;
			break;
		  case "tBox_Height":
			saveH=ntxt;
			break;
		  default:
			return;
		}
		float fw = float.Parse(this.tBox_Width.Text);
		float fh = float.Parse(this.tBox_Height.Text);
		if(!initializing)
		  OnActorResized(new ActorResizeEventArgs(fw, fh));
	  }
	  else
	  {
		AnnounceBadDimension(ntxt);
		tbox.Text=otxt;
	  }
	}
	/// <summary>
	/// Handles the CheckedChanged event of the check_Filled checkbox.
	/// Invokes the OnActorFilledChanged method to fire a new
	/// ActorFilledChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void check_Filled_CheckedChanged(object sender, System.EventArgs e)
	{
	  saveFilled = this.check_Filled.Checked;
	  if(!initializing)
		OnActorFilledChanged(new ActorFilledChangedEventArgs(saveFilled));
	}
	/// <summary>
	/// Handles the CheckedChanged event of the check_Bordered checkbox.
	/// Invokes the OnActorBorderedChanged method to fire a new
	/// ActorBorderedChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void check_Bordered_CheckedChanged(object sender, System.EventArgs e)
	{
	  saveBordered = this.check_Bordered.Checked;
	  if(!initializing)
		OnActorBorderedChanged(new ActorBorderedChangedEventArgs(saveFilled));
	}
	/// <summary>
	/// Handles the Click event of the btn_ColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_Color panel is colored in the choosen Color, and
	/// the OnActorColorChanged method is invoked to fire a new
	/// ActorColorChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_ColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveColor)
		{
		  saveColor = newColor;
		  this.pnl_Color.BackColor=saveColor;
		  if(!initializing)
			OnActorColorChanged(new ActorColorChangedEventArgs(saveColor));
		}
	  }
	}
	/// <summary>
	/// Handles the Click event of the btn_TxtColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_TxtColor panel is colored in the choosen Color, and
	/// the OnActorTextColorChanged method is invoked to fire a new
	/// ActorTextColorChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_TxtColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveTxtColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveTxtColor)
		{
		  saveTxtColor = newColor;
		  this.pnl_TxtColor.BackColor=saveTxtColor;
		  if(!initializing)
			OnActorTextColorChanged(new ActorColorChangedEventArgs(saveColor));
		}
	  }
	}
	/// <summary>
	/// Handles the Click event of the btn_BrdColorPick Button.
	/// Displays a ColorDialog to let the user select a new Color.
	/// If the selected Color is different than the previous one,
	/// the pnl_BrdColor panel is colored in the choosen Color, and
	/// the OnActorBorderColorChanged method is invoked to fire a new
	/// ActorBorderColorChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void btn_BrdColorPick_Click(object sender, System.EventArgs e)
	{
	  ColorDialog cd = new ColorDialog();
	  cd.AllowFullOpen=false;
	  cd.SolidColorOnly=true;
	  cd.AnyColor=false;
	  cd.Color=saveBrdColor;
	  DialogResult dr = cd.ShowDialog(this);
	  if(dr==DialogResult.OK)
	  {
		Color newColor = cd.Color;
		if(newColor!=saveBrdColor)
		{
		  saveBrdColor = newColor;
		  this.pnl_BrdColor.BackColor=saveBrdColor;
		  if(!initializing)
			OnActorBorderColorChanged(new ActorColorChangedEventArgs(saveBrdColor));
		}
	  }
	}
	/// <summary>
	/// Handles the TextChanged event of the tBox_Text text box. If the
	/// new text is different than the previous one, the OnActorTextChanged
	/// method is invoked to fire a new ActorTextChanged event.
	/// </summary>
	/// <param name="sender">The object sending the event.</param>
	/// <param name="e">The System.EventArgs describing the event.</param>
	private void tBox_Text_TextChanged(object sender, System.EventArgs e)
	{
	  string ntxt = this.tBox_Text.Text;
	  if(ntxt!=saveText)
	  {
		saveText = ntxt;
		if(!initializing)
		  OnActorTextChanged(new ActorTextChangedEventArgs(saveText));
	  }
	}

	#endregion

	#endregion

	#region Protected Methods

	/// <summary> 
	/// Clean up any resources being used.
	/// </summary>
	protected override void Dispose( bool disposing )
	{
	  if( disposing )
	  {
		if(components != null)
		{
		  components.Dispose();
		}
	  }
	  base.Dispose( disposing );
	}

	#region Custom Event Handlers

	/// <summary>
	/// Fires a new ActorLocationChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorLocationChangedEventArgs describing the event.</param>
	protected virtual void OnLocationChanged(ActorLocationChangedEventArgs e)
	{ if(ActorLocationChanged!=null) ActorLocationChanged(this, e); }
	/// <summary>
	/// Fires a new ActorResize event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorResizeEventArgs describing the event.</param>
	protected virtual void OnActorResized(ActorResizeEventArgs e)
	{ if(ActorResized!=null) ActorResized(this, e); }
	/// <summary>
	/// Fires a new ActorFilledChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorFilledChangedEventArgs describing the event.</param>
	protected virtual void OnActorFilledChanged(ActorFilledChangedEventArgs e)
	{ if(ActorFilledChanged!=null) ActorFilledChanged(this, e); }	
	/// <summary>
	/// Fires a new ActorBorderedChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorBorderedChangedEventArgs describing the event.</param>
	protected virtual void OnActorBorderedChanged(ActorBorderedChangedEventArgs e)
	{ if(ActorBorderedChanged!=null) ActorBorderedChanged(this, e); }
	/// <summary>
	/// Fires a new ActorColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorColorChangedEventArgs describing the event.</param>
	protected virtual void OnActorColorChanged(ActorColorChangedEventArgs e)
	{ if(ActorColorChanged!=null) ActorColorChanged(this, e); }
	/// <summary>
	/// Fires a new ActorColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorColorChangedEventArgs describing the event.</param>
	protected virtual void OnActorTextColorChanged(ActorColorChangedEventArgs e)
	{ if(ActorTextColorChanged!=null) ActorTextColorChanged(this, e); }
	/// <summary>
	/// Fires a new ActorColorChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorColorChangedEventArgs describing the event.</param>
	protected virtual void OnActorBorderColorChanged(ActorColorChangedEventArgs e)
	{ if(ActorBorderColorChanged!=null) ActorBorderColorChanged(this, e); }
	/// <summary>
	/// Fires a new ActorTextChanged event if any handler is registered.
	/// </summary>
	/// <param name="e">The ActorTextChangedEventArgs describing the event.</param>
	protected virtual void OnActorTextChanged(ActorTextChangedEventArgs e)
	{ if(ActorTextChanged!=null) ActorTextChanged(this, e); }


	#endregion


	#endregion

		#region Component Designer generated code
	/// <summary> 
	/// Required method for Designer support - do not modify 
	/// the contents of this method with the code editor.
	/// </summary>
	private void InitializeComponent()
	{
	  this.pnl_TxtColor = new System.Windows.Forms.Panel();
	  this.pnl_BrdColor = new System.Windows.Forms.Panel();
	  this.pnl_Color = new System.Windows.Forms.Panel();
	  this.btn_TxtColorPick = new System.Windows.Forms.Button();
	  this.lbl_TextColor = new System.Windows.Forms.Label();
	  this.tBox_Text = new System.Windows.Forms.TextBox();
	  this.lbl_Text = new System.Windows.Forms.Label();
	  this.btn_BrdColorPick = new System.Windows.Forms.Button();
	  this.check_Bordered = new System.Windows.Forms.CheckBox();
	  this.lbl_Bordered = new System.Windows.Forms.Label();
	  this.btn_ColorPick = new System.Windows.Forms.Button();
	  this.check_Filled = new System.Windows.Forms.CheckBox();
	  this.lbl_Filled = new System.Windows.Forms.Label();
	  this.tBox_Height = new System.Windows.Forms.TextBox();
	  this.lbl_Height = new System.Windows.Forms.Label();
	  this.tBox_Width = new System.Windows.Forms.TextBox();
	  this.lbl_Width = new System.Windows.Forms.Label();
	  this.tBox_LocY = new System.Windows.Forms.TextBox();
	  this.lbl_LocY = new System.Windows.Forms.Label();
	  this.tBox_LocX = new System.Windows.Forms.TextBox();
	  this.lbl_LocX = new System.Windows.Forms.Label();
	  this.lbl_Location = new System.Windows.Forms.Label();
	  this.SuspendLayout();
	  // 
	  // pnl_TxtColor
	  // 
	  this.pnl_TxtColor.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_TxtColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_TxtColor.Location = new System.Drawing.Point(70, 160);
	  this.pnl_TxtColor.Name = "pnl_TxtColor";
	  this.pnl_TxtColor.Size = new System.Drawing.Size(110, 20);
	  this.pnl_TxtColor.TabIndex = 52;
	  // 
	  // pnl_BrdColor
	  // 
	  this.pnl_BrdColor.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_BrdColor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_BrdColor.Location = new System.Drawing.Point(90, 100);
	  this.pnl_BrdColor.Name = "pnl_BrdColor";
	  this.pnl_BrdColor.Size = new System.Drawing.Size(90, 20);
	  this.pnl_BrdColor.TabIndex = 51;
	  // 
	  // pnl_Color
	  // 
	  this.pnl_Color.BackColor = System.Drawing.Color.Transparent;
	  this.pnl_Color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
	  this.pnl_Color.Location = new System.Drawing.Point(90, 70);
	  this.pnl_Color.Name = "pnl_Color";
	  this.pnl_Color.Size = new System.Drawing.Size(90, 20);
	  this.pnl_Color.TabIndex = 50;
	  // 
	  // btn_TxtColorPick
	  // 
	  this.btn_TxtColorPick.Location = new System.Drawing.Point(190, 160);
	  this.btn_TxtColorPick.Name = "btn_TxtColorPick";
	  this.btn_TxtColorPick.Size = new System.Drawing.Size(50, 20);
	  this.btn_TxtColorPick.TabIndex = 49;
	  this.btn_TxtColorPick.Text = "P&ick...";
	  this.btn_TxtColorPick.Click += new System.EventHandler(this.btn_TxtColorPick_Click);
	  // 
	  // lbl_TextColor
	  // 
	  this.lbl_TextColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_TextColor.Location = new System.Drawing.Point(10, 160);
	  this.lbl_TextColor.Name = "lbl_TextColor";
	  this.lbl_TextColor.Size = new System.Drawing.Size(55, 20);
	  this.lbl_TextColor.TabIndex = 48;
	  this.lbl_TextColor.Text = "Txt Color:";
	  this.lbl_TextColor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_Text
	  // 
	  this.tBox_Text.Location = new System.Drawing.Point(70, 130);
	  this.tBox_Text.Name = "tBox_Text";
	  this.tBox_Text.Size = new System.Drawing.Size(170, 20);
	  this.tBox_Text.TabIndex = 47;
	  this.tBox_Text.Text = "";
	  this.tBox_Text.TextChanged += new System.EventHandler(this.tBox_Text_TextChanged);
	  // 
	  // lbl_Text
	  // 
	  this.lbl_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Text.Location = new System.Drawing.Point(10, 130);
	  this.lbl_Text.Name = "lbl_Text";
	  this.lbl_Text.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Text.TabIndex = 46;
	  this.lbl_Text.Text = "Text:";
	  this.lbl_Text.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // btn_BrdColorPick
	  // 
	  this.btn_BrdColorPick.Location = new System.Drawing.Point(190, 100);
	  this.btn_BrdColorPick.Name = "btn_BrdColorPick";
	  this.btn_BrdColorPick.Size = new System.Drawing.Size(50, 20);
	  this.btn_BrdColorPick.TabIndex = 45;
	  this.btn_BrdColorPick.Text = "&Pick...";
	  this.btn_BrdColorPick.Click += new System.EventHandler(this.btn_BrdColorPick_Click);
	  // 
	  // check_Bordered
	  // 
	  this.check_Bordered.Location = new System.Drawing.Point(65, 100);
	  this.check_Bordered.Name = "check_Bordered";
	  this.check_Bordered.Size = new System.Drawing.Size(20, 20);
	  this.check_Bordered.TabIndex = 44;
	  this.check_Bordered.CheckedChanged += new System.EventHandler(this.check_Bordered_CheckedChanged);
	  // 
	  // lbl_Bordered
	  // 
	  this.lbl_Bordered.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Bordered.Location = new System.Drawing.Point(5, 100);
	  this.lbl_Bordered.Name = "lbl_Bordered";
	  this.lbl_Bordered.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Bordered.TabIndex = 43;
	  this.lbl_Bordered.Text = "Border?";
	  this.lbl_Bordered.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // btn_ColorPick
	  // 
	  this.btn_ColorPick.Location = new System.Drawing.Point(190, 70);
	  this.btn_ColorPick.Name = "btn_ColorPick";
	  this.btn_ColorPick.Size = new System.Drawing.Size(50, 20);
	  this.btn_ColorPick.TabIndex = 42;
	  this.btn_ColorPick.Text = "&Pick...";
	  this.btn_ColorPick.Click += new System.EventHandler(this.btn_ColorPick_Click);
	  // 
	  // check_Filled
	  // 
	  this.check_Filled.Location = new System.Drawing.Point(65, 70);
	  this.check_Filled.Name = "check_Filled";
	  this.check_Filled.Size = new System.Drawing.Size(20, 20);
	  this.check_Filled.TabIndex = 41;
	  this.check_Filled.CheckedChanged += new System.EventHandler(this.check_Filled_CheckedChanged);
	  // 
	  // lbl_Filled
	  // 
	  this.lbl_Filled.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Filled.Location = new System.Drawing.Point(5, 70);
	  this.lbl_Filled.Name = "lbl_Filled";
	  this.lbl_Filled.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Filled.TabIndex = 40;
	  this.lbl_Filled.Text = "Filled?";
	  this.lbl_Filled.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_Height
	  // 
	  this.tBox_Height.Location = new System.Drawing.Point(190, 40);
	  this.tBox_Height.Name = "tBox_Height";
	  this.tBox_Height.Size = new System.Drawing.Size(50, 20);
	  this.tBox_Height.TabIndex = 39;
	  this.tBox_Height.Text = "";
	  this.tBox_Height.Leave += new System.EventHandler(this.dimension_LooseFocus);
	  // 
	  // lbl_Height
	  // 
	  this.lbl_Height.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Height.Location = new System.Drawing.Point(130, 40);
	  this.lbl_Height.Name = "lbl_Height";
	  this.lbl_Height.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Height.TabIndex = 38;
	  this.lbl_Height.Text = "Height:";
	  this.lbl_Height.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_Width
	  // 
	  this.tBox_Width.Location = new System.Drawing.Point(65, 40);
	  this.tBox_Width.Name = "tBox_Width";
	  this.tBox_Width.Size = new System.Drawing.Size(50, 20);
	  this.tBox_Width.TabIndex = 37;
	  this.tBox_Width.Text = "";
	  this.tBox_Width.Leave += new System.EventHandler(this.dimension_LooseFocus);
	  // 
	  // lbl_Width
	  // 
	  this.lbl_Width.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Width.Location = new System.Drawing.Point(5, 40);
	  this.lbl_Width.Name = "lbl_Width";
	  this.lbl_Width.Size = new System.Drawing.Size(50, 20);
	  this.lbl_Width.TabIndex = 36;
	  this.lbl_Width.Text = "Width:";
	  this.lbl_Width.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_LocY
	  // 
	  this.tBox_LocY.Location = new System.Drawing.Point(190, 10);
	  this.tBox_LocY.Name = "tBox_LocY";
	  this.tBox_LocY.Size = new System.Drawing.Size(50, 20);
	  this.tBox_LocY.TabIndex = 35;
	  this.tBox_LocY.Text = "";
	  this.tBox_LocY.Leave += new System.EventHandler(this.locCoord_LooseFocus);
	  // 
	  // lbl_LocY
	  // 
	  this.lbl_LocY.Location = new System.Drawing.Point(160, 10);
	  this.lbl_LocY.Name = "lbl_LocY";
	  this.lbl_LocY.Size = new System.Drawing.Size(20, 20);
	  this.lbl_LocY.TabIndex = 34;
	  this.lbl_LocY.Text = "Y=";
	  this.lbl_LocY.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // tBox_LocX
	  // 
	  this.tBox_LocX.Location = new System.Drawing.Point(100, 10);
	  this.tBox_LocX.Name = "tBox_LocX";
	  this.tBox_LocX.Size = new System.Drawing.Size(50, 20);
	  this.tBox_LocX.TabIndex = 33;
	  this.tBox_LocX.Text = "";
	  this.tBox_LocX.Leave += new System.EventHandler(this.locCoord_LooseFocus);
	  // 
	  // lbl_LocX
	  // 
	  this.lbl_LocX.Location = new System.Drawing.Point(70, 10);
	  this.lbl_LocX.Name = "lbl_LocX";
	  this.lbl_LocX.Size = new System.Drawing.Size(20, 20);
	  this.lbl_LocX.TabIndex = 32;
	  this.lbl_LocX.Text = "X=";
	  this.lbl_LocX.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // lbl_Location
	  // 
	  this.lbl_Location.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
	  this.lbl_Location.Location = new System.Drawing.Point(5, 10);
	  this.lbl_Location.Name = "lbl_Location";
	  this.lbl_Location.Size = new System.Drawing.Size(55, 20);
	  this.lbl_Location.TabIndex = 31;
	  this.lbl_Location.Text = "Location:";
	  this.lbl_Location.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
	  // 
	  // ActorDisplay
	  // 
	  this.Controls.AddRange(new System.Windows.Forms.Control[] {
																  this.pnl_TxtColor,
																  this.pnl_BrdColor,
																  this.pnl_Color,
																  this.btn_TxtColorPick,
																  this.lbl_TextColor,
																  this.tBox_Text,
																  this.lbl_Text,
																  this.btn_BrdColorPick,
																  this.check_Bordered,
																  this.lbl_Bordered,
																  this.btn_ColorPick,
																  this.check_Filled,
																  this.lbl_Filled,
																  this.tBox_Height,
																  this.lbl_Height,
																  this.tBox_Width,
																  this.lbl_Width,
																  this.tBox_LocY,
																  this.lbl_LocY,
																  this.tBox_LocX,
																  this.lbl_LocX,
																  this.lbl_Location});
	  this.Name = "ActorDisplay";
	  this.Size = new System.Drawing.Size(250, 190);
	  this.ResumeLayout(false);

	}
		#endregion


	#region Public Methods

	/// <summary>
	/// Determines whether the given string represents a valid coordinate
	/// for the Actor's Location.
	/// </summary>
	/// <param name="s">The string to be validated.</param>
	/// <returns>true if the string s represents a valid float value; false otherwise.</returns>
	public bool ValidLocationCoordinate(string s, ref float f)
	{
	  try
	  {
		f = float.Parse(s);
	  }
	  catch(Exception)
	  {
		return false;
	  }
	  return true;
	}
	/// <summary>
	/// Determines whether the given string represents a valid dimension
	/// for the Actor. If so, the float parameter is set to be the value
	/// represented by the string.
	/// </summary>
	/// <param name="s">The string to be validated.</param>
	/// <param name="f">The parameter to be set to the value represented by the string
	/// s if this is a valid dimension.</param>
	/// <returns>true if s is a valid dimension (i.e. represents a valid float value);
	/// false otherwise.</returns>
	public bool ValidDimension(string s, ref float f)
	{
	  try
	  {
		f = float.Parse(s);
	  }
	  catch(Exception)
	  {
		return false;
	  }
	  if(f<0.0f)  return false;
	  return true;
	}

	#endregion


  }
}
