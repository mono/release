using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using STI_Library.Win32Controls;
namespace STI_Library
{
	/// <summary>
	/// Summary description for TestForm.
	/// </summary>
	public class TestForm : System.Windows.Forms.Form
	{
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private STI_PushButton pButton;
		private STI_ToggleButton tButton;
		private STI_DropDownListBoxButton ddlButton;
		private STI_Library.Win32Controls.STI_PushButton pushButton1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private STI_DropDownListBox ddListbox;
		public TestForm()
		{
			//
			// Required for Windows Form Designer support
			//
			
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		public static void Main()
		{
			Application.Run(new TestForm());
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TestForm));
			this.pButton = new STI_Library.Win32Controls.STI_PushButton();
			this.tButton = new STI_Library.Win32Controls.STI_ToggleButton();
			this.ddlButton = new STI_Library.Win32Controls.STI_DropDownListBoxButton();
			this.ddListbox = new STI_Library.Win32Controls.STI_DropDownListBox();
			this.pushButton1 = new STI_Library.Win32Controls.STI_PushButton();
			this.panel1 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			((System.ComponentModel.ISupportInitialize)(this.ddlButton)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.ddListbox)).BeginInit();
			this.tabControl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pButton
			// 
			this.pButton.Image = ((System.Drawing.Bitmap)(resources.GetObject("pButton.Image")));
			this.pButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.pButton.Location = new System.Drawing.Point(48, 176);
			this.pButton.Name = "pButton";
			this.pButton.Size = new System.Drawing.Size(88, 24);
			this.pButton.TabIndex = 0;
			this.pButton.Text = "Previous";
			this.pButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tButton
			// 
			this.tButton.Image = ((System.Drawing.Bitmap)(resources.GetObject("tButton.Image")));
			this.tButton.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.tButton.Location = new System.Drawing.Point(64, 96);
			this.tButton.Name = "tButton";
			this.tButton.Size = new System.Drawing.Size(40, 40);
			this.tButton.TabIndex = 1;
			this.tButton.Text = "Save";
			this.tButton.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// ddlButton
			// 
			this.ddlButton.Anchor = ((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.ddlButton.Image = ((System.Drawing.Bitmap)(resources.GetObject("ddlButton.Image")));
			this.ddlButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.ddlButton.Location = new System.Drawing.Point(320, 136);
			this.ddlButton.Name = "ddlButton";
			this.ddlButton.Size = new System.Drawing.Size(56, 24);
			this.ddlButton.TabIndex = 2;
			this.ddlButton.Text = "Add";
			this.ddlButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.ddlButton.ItemSelected += new STI_Library.Win32Controls.STI_DropDownListBoxButton.ItemSelectedEventHandler(this.ddlButton_ItemSelected);
			// 
			// ddListbox
			// 
			this.ddListbox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.ddListbox.DroppedDown = false;
			this.ddListbox.Location = new System.Drawing.Point(280, 32);
			this.ddListbox.Name = "ddListbox";
			this.ddListbox.TabIndex = 3;
			this.ddListbox.Click += new System.EventHandler(this.ddListbox_Click);
			// 
			// pushButton1
			// 
			this.pushButton1.Image = ((System.Drawing.Bitmap)(resources.GetObject("pushButton1.Image")));
			this.pushButton1.Location = new System.Drawing.Point(152, 176);
			this.pushButton1.Name = "pushButton1";
			this.pushButton1.Size = new System.Drawing.Size(80, 24);
			this.pushButton1.TabIndex = 4;
			this.pushButton1.Text = "Next";
			this.pushButton1.Click += new System.EventHandler(this.pushButton1_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.SystemColors.GrayText;
			this.panel1.Location = new System.Drawing.Point(264, 192);
			this.panel1.Name = "panel1";
			this.panel1.TabIndex = 5;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(184, 72);
			this.button1.Name = "button1";
			this.button1.TabIndex = 6;
			this.button1.Text = "button1";
			// 
			// comboBox1
			// 
			this.comboBox1.Location = new System.Drawing.Point(328, 96);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(144, 21);
			this.comboBox1.TabIndex = 7;
			this.comboBox1.Text = "comboBox1";
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.tabPage1,
																					  this.tabPage2,
																					  this.tabPage3});
			this.tabControl1.Location = new System.Drawing.Point(224, 328);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(248, 128);
			this.tabControl1.TabIndex = 8;
			// 
			// tabPage1
			// 
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Size = new System.Drawing.Size(240, 102);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "tabPage1";
			// 
			// tabPage2
			// 
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(240, 102);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "tabPage2";
			// 
			// tabPage3
			// 
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(240, 102);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "tabPage3";
			// 
			// TestForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.ControlLight;
			this.ClientSize = new System.Drawing.Size(640, 477);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tabControl1,
																		  this.comboBox1,
																		  this.button1,
																		  this.panel1,
																		  this.pushButton1,
																		  this.pButton,
																		  this.tButton,
																		  this.ddlButton,
																		  this.ddListbox});
			this.Name = "TestForm";
			this.Text = "TestForm";
			this.Load += new System.EventHandler(this.TestForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.ddlButton)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.ddListbox)).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void ddlButton_ItemSelected(object sender, STI_Library.HelperClasses.ItemSelectedEventArgs e)
		{
			this.Text=e.SelectedItem.ToString();
		}

		private void pushButton1_Click(object sender, System.EventArgs e)
		{
			Text+="Click";
		}

		private void TestForm_Load(object sender, System.EventArgs e)
		{
			this.ddListbox.List.Items.Add("Puto");
			this.ddListbox.List.Items.Add("Alvaro");
			this.ddListbox.List.Items.Add("Dino");
			this.ddListbox.List.Items.Add("Ryno");
			this.ddListbox.List.Items.Add("alala");

			this.ddlButton.List.Items.AddRange(this.ddListbox.List.Items);
		}

		private void ddListbox_Click(object sender, System.EventArgs e)
		{
			
		}
	}
}
