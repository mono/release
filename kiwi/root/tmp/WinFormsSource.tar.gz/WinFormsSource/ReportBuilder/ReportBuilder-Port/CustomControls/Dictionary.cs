using System;
using System.Resources;
using System.Globalization;
using System.Collections;

namespace CustomControls.Globalization
{
	public class Dictionary
	{
		
		private static ResXResourceReader _Resx=null;
		private static string path="Dictionary.resx";
		private static Hashtable _HT=null;


		private static ResXResourceReader Resx
		{
			get
			{
				if(System.IO.File.Exists(path))
				{
					if(_Resx==null)
					{
						_Resx= new ResXResourceReader(path);
					}
				}
				return _Resx;
			}
		}

		private static Hashtable HT
		{
			get
			{
				if(_HT==null && Resx!=null)
				{
					_HT= new Hashtable();
					foreach(DictionaryEntry de in Resx )
					{
						_HT.Add(de.Key, de.Value);
					}
					_Resx.Close();
					_Resx=null;
				}
				return _HT;
			}
		}


		

	
		public Dictionary()
		{
		
		}

	
		public static string Translate(string Text,CultureInfo ci)
		{
			if(HT!=null)
			{
				string langText=ci.TwoLetterISOLanguageName.ToUpper()+ "_" + Text;
				object sText= HT[langText].ToString();
				if(sText!=null){return sText.ToString();}
				else{return null;}
			}
			return Text;
		}

		public static string Translate(string Text)
		{
			if(HT!=null)
			{
				CultureInfo ci=System.Globalization.CultureInfo.CurrentCulture;
				object sText=HT[ci.TwoLetterISOLanguageName.ToUpper()+ "_" + Text];
				if(sText!=null){return sText.ToString();}
				else{return null;}
			
			}
			return null;
		}

		public static string GetLocalizedText(string Text)
		{			
			string text=CustomControls.Globalization.Dictionary.Translate(Text);
			if(text!=null ){return text;}
			return Text;
		}
		public static string GetLocalizedText(string Text,CultureInfo ci)
		{			
			string text=CustomControls.Globalization.Dictionary.Translate(Text,ci);
			if(text!=null ){return text;}
			return Text;
		}

	}
}
