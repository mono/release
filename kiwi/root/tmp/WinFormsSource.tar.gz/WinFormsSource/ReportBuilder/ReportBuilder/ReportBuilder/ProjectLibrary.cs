using System;
using System.Windows.Forms;
using ProjectLibrary.General;
using System.Data;
using CustomControls.ApplicationBlocks;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using ProjectLibrary.Controls;

namespace ProjectLibrary.Controls
{
	public class PDataGrid:DataGrid, IPrintable
	{
		public DataView GetSource()
		{
			DataView source=null;
			if(ListManager!=null && ListManager.List !=null && ListManager.List is DataView){source= (DataView)ListManager.List;}
			return source;
		}

		public TableStyle  GetTableStyle()
		{
			CustomControls.ApplicationBlocks.TableStyle ts=null;
			DataGridTableStyle tableStyle=GetTableActiveStyle();
		
			if (tableStyle!=null)
			{
				ts=new TableStyle();
				ts.BackColor=tableStyle.BackColor;
				ts.AlternatingBackColor=tableStyle.AlternatingBackColor;
				ts.GridLineColor=tableStyle.GridLineColor;
				ts.RowHeight=tableStyle.PreferredRowHeight;

				if(tableStyle.GridLineStyle==DataGridLineStyle.None)
				{
					ts.HGridLine=false;
					ts.VGridLine=false;
				}
				foreach(DataGridColumnStyle c in tableStyle.GridColumnStyles )
				{
					ColumnStyle cs= new ColumnStyle(ts);
					cs.Alignment=c.Alignment;
					cs.HeaderText=c.HeaderText;
					cs.MappingName=c.MappingName;
					cs.NullText=c.NullText;
					cs.Width=c.Width;
					
					if(c is DataGridTextBoxColumn)
					{
						cs.Format=((DataGridTextBoxColumn)c).Format;
					}
					//Prevent MappingName from beeing displayed
					cs.PropertyCommands.Add(new CustomControls.HelperClasses.PropertyCommand("MappingName",false,true));
			
					ts.ColumnStyles.Add(cs);
										
				}
			}
		
			return ts;
		}
	
		private DataGridTableStyle GetTableActiveStyle()
		{
			DataGridTableStyle ts=null;
			string mappingName=GetMappingName(this.DataSource);
			ts= this.TableStyles[mappingName];
			if(ts==null){ts=CreateDefaultTableStyle();}
			return ts;
		}

		private DataGridTableStyle CreateDefaultTableStyle()
		{
			DataGridTableStyle ts=null;
			if(ListManager!=null )
			{
				ts= new DataGridTableStyle(ListManager);	
				ts.BackColor=BackColor;
				ts.GridLineColor=GridLineColor;
				ts.GridLineStyle=GridLineStyle;
				ts.AlternatingBackColor=AlternatingBackColor;
			}

			return ts;
		}

		private string GetMappingName(object src)  
		{
			string mappingName=string.Empty;

			if(ListManager!=null && ListManager.List !=null )
			{
				IList myList = ListManager.List;
				ITypedList tList = (ITypedList) myList;
				if(tList!=null){mappingName=tList.GetListName(null);}
			}
		
			return mappingName;
		} 
 
		[Browsable(false)]
		public bool IsValid
		{
			get
			{
				if(GetSource()!=null && GetTableStyle()!=null)
				{
					return true;
				}
				return false;
			}
		}
	}

	[DesignerAttribute(typeof(PComboBoxDesigner))]
	public class PComboBox:ComboBox, IPrintable
	{
		[Browsable(false)]
		public bool IsValid
		{
			get
			{
				if(GetSource()!=null && GetTableStyle()!=null)
				{
					return true;
				}
				return false;
			}
		}
		public DataView GetSource()
		{
			DataView source=null;
			if(this.DataSource!=null && this.BindingContext!=null)
			{				
				CurrencyManager cm = (CurrencyManager)this.BindingContext[this.DataSource];
				if(cm!=null && cm.List !=null && cm.List is DataView){source= (DataView)cm.List;}
			}
			return source;
		}
	
		public TableStyle  GetTableStyle()
		{
			CustomControls.ApplicationBlocks.TableStyle ts= new TableStyle();
			
					
			ColumnStyle cs= new ColumnStyle(ts);
	
			cs.MappingName=this.DisplayMember;
			cs.Width=this.Width;
			cs.BackColor=this.BackColor;
			cs.Font=this.Font;
			cs.ForeColor=this.ForeColor;
			//Prevent MappingName from beeing displayed
			cs.PropertyCommands.Add(new CustomControls.HelperClasses.PropertyCommand("MappingName",false,true));
		
		
			ts.ColumnStyles.Add(cs);
		
			return ts;
		}

		private string GetMappingName(object src)  
		{
			string mappingName=string.Empty;

			if(this.DataSource!=null)
			{
				CurrencyManager cm = (CurrencyManager)this.BindingContext[this.DataSource];
	
				if(cm!=null && cm.List !=null )
				{
					IList myList = cm.List;
					ITypedList tList = (ITypedList) myList;
					if(tList!=null){mappingName=tList.GetListName(null);}
				}
			}
		
			return mappingName;
		} 
	}

	public class PListBox:ListBox,IPrintable
	{
		[Browsable(false)]
		public bool IsValid
		{
			get
			{
				if(GetSource()!=null && GetTableStyle()!=null)
				{
					return true;
				}
				return false;
			}
		}
		public DataView GetSource()
		{
			DataView source=null;
			if(this.DataSource!=null)
			{				
				CurrencyManager cm = (CurrencyManager)this.BindingContext[this.DataSource];
				if(cm!=null && cm.List !=null && cm.List is DataView){source= (DataView)cm.List;}
			}
			return source;
		}
	
		public TableStyle  GetTableStyle()
		{
			CustomControls.ApplicationBlocks.TableStyle ts= new TableStyle();
			
							
			ts.BackColor=this.BackColor;
			
			ColumnStyle cs= new ColumnStyle(ts);
	
			cs.MappingName=this.DisplayMember;
			cs.Width=this.Width;
			cs.Font=this.Font;
			cs.ForeColor=this.ForeColor;
			//Prevent MappingName from beeing displayed
			cs.PropertyCommands.Add(new CustomControls.HelperClasses.PropertyCommand("MappingName",false,true));
		
		
			ts.ColumnStyles.Add(cs);
		
			return ts;
		}

		private string GetMappingName(object src)  
		{
			string mappingName=string.Empty;

			if(this.DataSource!=null)
			{
				CurrencyManager cm = (CurrencyManager)this.BindingContext[this.DataSource];
	
				if(cm!=null && cm.List !=null )
				{
					IList myList = cm.List;
					ITypedList tList = (ITypedList) myList;
					if(tList!=null){mappingName=tList.GetListName(null);}
				}
			}
		
			return mappingName;
		} 
	}

	public class PForm:Form, IMessageFilter
	{

		protected Hashtable OriginalCursors=new Hashtable();


		protected void StartTracking()
		{
				Application.AddMessageFilter(this);
		}

		
		public bool PreFilterMessage(ref Message m) 
		{
		
			if(m.Msg== (int)CustomControls.Enumerations.Msgs.WM_MOUSEMOVE)
			{
				LMouseMove();
				return true;
			}
			else if(m.Msg==(int)CustomControls.Enumerations.Msgs.WM_LBUTTONDOWN)
			{
				LMouseDown();
				return true;
			}
		
		
			return false;
		}


		protected void LMouseMove()
		{
			Control ctrl=GetControl(this,MousePosition);

			
			if(ctrl!=null && ctrl is IPrintable && ((IPrintable)ctrl).IsValid	)
			
			{
				SaveControlCursor(ctrl,ctrl.Cursor);
				ctrl.Cursor=Cursors.Hand;
			}
			else
			
			{
				if (ctrl!=null)
				{
					SaveControlCursor(ctrl,ctrl.Cursor);
					ctrl.Cursor=Cursors.No;
				}
			
			}
			
		}
		
		
		protected void LMouseDown()
		{
			ResetCursors();
			
			Control ctrl=GetControl(this,MousePosition);
			
			if(ctrl!=null && ctrl is IPrintable	&& ((IPrintable)ctrl).IsValid)
			{
				System.Data.DataView source=((IPrintable)ctrl).GetSource();
				CustomControls.ApplicationBlocks.TableStyle tableStyle=((IPrintable)ctrl).GetTableStyle();

				PrintSettingsDialog psd=new PrintSettingsDialog(source,tableStyle);
					
				Application.RemoveMessageFilter(this);

				psd.ShowDialog();
				
			}
		
			else
			{

				Application.RemoveMessageFilter(this);
			}
		}

		private Control GetControl(Control parentControl, Point position)
		{
			Point pos=parentControl.PointToClient(position);
			Control ctrl=parentControl.GetChildAtPoint(pos);
						
			if(ctrl!=null)
			{
				if(ctrl is IPrintable	&& ((IPrintable)ctrl).IsValid)
				{
					return ctrl;
				}
				else if(ctrl.Controls.Count>0)
				{
					return GetControl(ctrl,position);
				}
				else
				{
					return ctrl;
				}
			}
			else return null;


		}

		private void SetControls(Control ctrl)
		{
			if(ctrl.Controls.Count>0 && !( ctrl is IPrintable && ((IPrintable)ctrl).IsValid	))
			{
				foreach(Control c in ctrl.Controls )
				{
					SetControls(c);
				}
			}
			else
			{
				if(ctrl!=null && ctrl is IPrintable	&& ((IPrintable)ctrl).IsValid)
				{
					System.Data.DataView source=((IPrintable)ctrl).GetSource();
					CustomControls.ApplicationBlocks.TableStyle tableStyle=((IPrintable)ctrl).GetTableStyle();

					PrintSettingsDialog psd=new PrintSettingsDialog(source,tableStyle);
					
					Application.RemoveMessageFilter(this);

					psd.ShowDialog();
				
				}
				else
				{

					Application.RemoveMessageFilter(this);
				}
			}
		}

	
		protected void SaveControlCursor(Control Control, Cursor Cursor)
		{
			if(!OriginalCursors.ContainsKey(Control))
			{
				this.OriginalCursors.Add(Control,Cursor);
			}
		}

	
		protected void ResetCursors()
		{

			foreach (DictionaryEntry entry in OriginalCursors) 
			{
				((Control)entry.Key).Cursor=(Cursor)entry.Value;
			}
			OriginalCursors.Clear();
		}
	}
	public class PToolBar:ToolBar	{}	
	public class PButton:Button	{}
}

namespace ProjectLibrary.General
{
	public interface IPrintable:CustomControls.BaseClasses.IReportSource 
	{
		CustomControls.ApplicationBlocks.TableStyle GetTableStyle();
		bool IsValid{get;}
	}
	public class PComboBoxDesigner : System.Windows.Forms.Design.ControlDesigner
	{
		PComboBox pCombo=null;
	
		public PComboBoxDesigner()	
		{}
	
		public override void Initialize(IComponent component)
		{
			base.Initialize (component);
			pCombo=this.Control as PComboBox;
			if(pCombo!=null)
			{
				pCombo.ValueMemberChanged+= new System.EventHandler(PCombo_ValueMemberChanged);
			}
		
		}

		private void PCombo_ValueMemberChanged(object sender,EventArgs e)
		{
			this.Control.Refresh();		
		}

	
		protected override void OnPaintAdornments(PaintEventArgs pe)
		{		
			if (pCombo!=null  && pCombo.ValueMember==string.Empty)
			{
				pe.Graphics.DrawRectangle(new Pen(Color.Red,4), 0, 0, this.Control.Size.Width, this.Control.Size.Height);
			}
	
		}

	 


	}
}
