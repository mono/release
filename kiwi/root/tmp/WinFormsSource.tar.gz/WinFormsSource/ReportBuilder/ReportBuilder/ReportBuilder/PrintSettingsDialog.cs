using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using CustomControls.ApplicationBlocks;
using CustomControls.HelperClasses;
using System.Data;


namespace ProjectLibrary.General
{
	public class PrintSettingsDialog : System.Windows.Forms.Form
	{
		private ProjectLibrary.Controls.PButton btn_ReportHeader;
		private ProjectLibrary.Controls.PButton btn_PageHeader;
		private ProjectLibrary.Controls.PButton btn_TableStyle;
		private ProjectLibrary.Controls.PButton btn_PageFooter;
		private ProjectLibrary.Controls.PButton btn_ReportFooter;
		private ProjectLibrary.Controls.PButton btn_PrintPreviw;
		private ProjectLibrary.Controls.PButton btn_PageSettings;
		private ProjectLibrary.Controls.PButton btn_Print;
		private ProjectLibrary.Controls.PButton btn_PrintSettings;
		private System.Windows.Forms.GroupBox gb_Design;
		private System.Windows.Forms.GroupBox gb_Settings;
		public CustomControls.ApplicationBlocks.ReportBuilder rb;
		private System.ComponentModel.IContainer components;
		

		public PrintSettingsDialog(DataView source, CustomControls.ApplicationBlocks.TableStyle tableStyle)
		{
			
			InitializeComponent();
			this.rb.DataSource=source;
			this.rb.TableStyle=tableStyle;
	
		}

		public PrintSettingsDialog(CustomControls.ApplicationBlocks.ReportBuilder reportBuilder)
		{
			
			InitializeComponent();
			this.rb=reportBuilder;
			
	
		}

		
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(PrintSettingsDialog));
			CustomControls.ApplicationBlocks.TableStyle tableStyle1 = new CustomControls.ApplicationBlocks.TableStyle();
			this.rb = new CustomControls.ApplicationBlocks.ReportBuilder();
			this.gb_Design = new System.Windows.Forms.GroupBox();
			this.btn_ReportFooter = new ProjectLibrary.Controls.PButton();
			this.btn_PageFooter = new ProjectLibrary.Controls.PButton();
			this.btn_TableStyle = new ProjectLibrary.Controls.PButton();
			this.btn_PageHeader = new ProjectLibrary.Controls.PButton();
			this.btn_ReportHeader = new ProjectLibrary.Controls.PButton();
			this.gb_Settings = new System.Windows.Forms.GroupBox();
			this.btn_Print = new ProjectLibrary.Controls.PButton();
			this.btn_PrintSettings = new ProjectLibrary.Controls.PButton();
			this.btn_PageSettings = new ProjectLibrary.Controls.PButton();
			this.btn_PrintPreviw = new ProjectLibrary.Controls.PButton();
			((System.ComponentModel.ISupportInitialize)(this.rb)).BeginInit();
			this.gb_Design.SuspendLayout();
			this.gb_Settings.SuspendLayout();
			this.SuspendLayout();
			// 
			// rb
			// 
			this.rb.DataSource = null;
			this.rb.PageFooter.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																						   new CustomControls.BaseClasses.TextCommand("Page number [PgNum]  from [TotalPgs]", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.Black, System.Windows.Forms.HorizontalAlignment.Right),
																						   new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Navy, System.Drawing.Drawing2D.DashStyle.Solid),
																						   new CustomControls.BaseClasses.TextCommand("Page Column [PgCol]", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.Black, System.Windows.Forms.HorizontalAlignment.Left),
																						   new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Navy, System.Drawing.Drawing2D.DashStyle.Solid),
																						   new CustomControls.BaseClasses.TextCommand("Page Row [PgRow]", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.Black, System.Windows.Forms.HorizontalAlignment.Left),
																						   new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Navy, System.Drawing.Drawing2D.DashStyle.Solid),
																						   new CustomControls.BaseClasses.TextCommand("Current Page [PgNumArr]", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.Black, System.Windows.Forms.HorizontalAlignment.Center)});
			this.rb.PageHeader.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																						   new CustomControls.BaseClasses.ColumnsHeaderCommand(System.Drawing.Color.SteelBlue, System.Drawing.Color.GhostWhite, System.Drawing.Color.Navy, new System.Drawing.Font("Tahoma", 10.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), 20, System.Windows.Forms.DataGridLineStyle.Solid)});
			this.rb.ReportFooter.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																							 new CustomControls.BaseClasses.TextCommand("The report ends here!", new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.SteelBlue, System.Drawing.Color.White, System.Windows.Forms.HorizontalAlignment.Right)});
			this.rb.ReportHeader.AddRange(new CustomControls.BaseClasses.PrintCommand[] {
																							 new CustomControls.BaseClasses.TextCommand("Report Header", new System.Drawing.Font("Tahoma", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0))), System.Drawing.Color.White, System.Drawing.Color.SteelBlue, System.Windows.Forms.HorizontalAlignment.Center),
																							 new CustomControls.BaseClasses.BlankLineCommand(20),
																							 new CustomControls.BaseClasses.PictureCommand(((System.Drawing.Bitmap)(resources.GetObject("resource"))), System.Windows.Forms.HorizontalAlignment.Left),
																							 new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Navy, System.Drawing.Drawing2D.DashStyle.Solid),
																							 new CustomControls.BaseClasses.BlankLineCommand(4),
																							 new CustomControls.BaseClasses.HRuleCommand(1, System.Drawing.Color.Navy, System.Drawing.Drawing2D.DashStyle.Solid),
																							 new CustomControls.BaseClasses.BlankLineCommand(40)});
			tableStyle1.AlternatingBackColor = System.Drawing.Color.Silver;
			tableStyle1.BackColor = System.Drawing.Color.White;
			tableStyle1.CategoryCommands.AddRange(new CustomControls.HelperClasses.CategoryCommand[] {
																										 new CustomControls.HelperClasses.CategoryCommand("Column Styles", true),
																										 new CustomControls.HelperClasses.CategoryCommand("Grid", true)});
			tableStyle1.GridLineColor = System.Drawing.Color.Navy;
			tableStyle1.PropertyCommands.AddRange(new CustomControls.HelperClasses.PropertyCommand[] {
																										 new CustomControls.HelperClasses.PropertyCommand("AlternatingBackColor", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("BackColor", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("ColumnStyles", true, true),
																										 new CustomControls.HelperClasses.PropertyCommand("GridLineColor", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("GridLineStyle", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("HGridLine", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("RowHeight", true, false),
																										 new CustomControls.HelperClasses.PropertyCommand("VGridLine", true, false)});
			tableStyle1.Table = null;
			this.rb.TableStyle = tableStyle1;
			// 
			// gb_Design
			// 
			this.gb_Design.Controls.Add(this.btn_ReportFooter);
			this.gb_Design.Controls.Add(this.btn_PageFooter);
			this.gb_Design.Controls.Add(this.btn_TableStyle);
			this.gb_Design.Controls.Add(this.btn_PageHeader);
			this.gb_Design.Controls.Add(this.btn_ReportHeader);
			this.gb_Design.Location = new System.Drawing.Point(8, 16);
			this.gb_Design.Name = "gb_Design";
			this.gb_Design.Size = new System.Drawing.Size(208, 248);
			this.gb_Design.TabIndex = 10;
			this.gb_Design.TabStop = false;
			this.gb_Design.Text = "Report Design";
			// 
			// btn_ReportFooter
			// 
			this.btn_ReportFooter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_ReportFooter.Image = ((System.Drawing.Image)(resources.GetObject("btn_ReportFooter.Image")));
			this.btn_ReportFooter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_ReportFooter.Location = new System.Drawing.Point(24, 196);
			this.btn_ReportFooter.Name = "btn_ReportFooter";
			this.btn_ReportFooter.Size = new System.Drawing.Size(160, 34);
			this.btn_ReportFooter.TabIndex = 4;
			this.btn_ReportFooter.Text = "Report Footer";
			this.btn_ReportFooter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_ReportFooter.Click += new System.EventHandler(this.btn_ReportFooter_Click_1);
			// 
			// btn_PageFooter
			// 
			this.btn_PageFooter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_PageFooter.Image = ((System.Drawing.Image)(resources.GetObject("btn_PageFooter.Image")));
			this.btn_PageFooter.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_PageFooter.Location = new System.Drawing.Point(24, 155);
			this.btn_PageFooter.Name = "btn_PageFooter";
			this.btn_PageFooter.Size = new System.Drawing.Size(160, 34);
			this.btn_PageFooter.TabIndex = 3;
			this.btn_PageFooter.Text = "Page Footer";
			this.btn_PageFooter.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_PageFooter.Click += new System.EventHandler(this.btn_PageFooter_Click_1);
			// 
			// btn_TableStyle
			// 
			this.btn_TableStyle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_TableStyle.Image = ((System.Drawing.Image)(resources.GetObject("btn_TableStyle.Image")));
			this.btn_TableStyle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_TableStyle.Location = new System.Drawing.Point(24, 114);
			this.btn_TableStyle.Name = "btn_TableStyle";
			this.btn_TableStyle.Size = new System.Drawing.Size(160, 34);
			this.btn_TableStyle.TabIndex = 2;
			this.btn_TableStyle.Text = "Table Styles";
			this.btn_TableStyle.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_TableStyle.Click += new System.EventHandler(this.btn_TableStyle_Click_1);
			// 
			// btn_PageHeader
			// 
			this.btn_PageHeader.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_PageHeader.Image = ((System.Drawing.Image)(resources.GetObject("btn_PageHeader.Image")));
			this.btn_PageHeader.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_PageHeader.Location = new System.Drawing.Point(24, 73);
			this.btn_PageHeader.Name = "btn_PageHeader";
			this.btn_PageHeader.Size = new System.Drawing.Size(160, 34);
			this.btn_PageHeader.TabIndex = 1;
			this.btn_PageHeader.Text = "Page Header";
			this.btn_PageHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_PageHeader.Click += new System.EventHandler(this.btn_PageHeader_Click_1);
			// 
			// btn_ReportHeader
			// 
			this.btn_ReportHeader.BackColor = System.Drawing.SystemColors.Control;
			this.btn_ReportHeader.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_ReportHeader.Image = ((System.Drawing.Image)(resources.GetObject("btn_ReportHeader.Image")));
			this.btn_ReportHeader.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_ReportHeader.Location = new System.Drawing.Point(24, 32);
			this.btn_ReportHeader.Name = "btn_ReportHeader";
			this.btn_ReportHeader.Size = new System.Drawing.Size(160, 34);
			this.btn_ReportHeader.TabIndex = 0;
			this.btn_ReportHeader.Text = "Report Header";
			this.btn_ReportHeader.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_ReportHeader.Click += new System.EventHandler(this.btn_ReportHeader_Click_2);
			// 
			// gb_Settings
			// 
			this.gb_Settings.Controls.Add(this.btn_Print);
			this.gb_Settings.Controls.Add(this.btn_PrintSettings);
			this.gb_Settings.Controls.Add(this.btn_PageSettings);
			this.gb_Settings.Controls.Add(this.btn_PrintPreviw);
			this.gb_Settings.Location = new System.Drawing.Point(232, 16);
			this.gb_Settings.Name = "gb_Settings";
			this.gb_Settings.Size = new System.Drawing.Size(192, 248);
			this.gb_Settings.TabIndex = 11;
			this.gb_Settings.TabStop = false;
			this.gb_Settings.Text = "Print Settings";
			// 
			// btn_Print
			// 
			this.btn_Print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_Print.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btn_Print.Image = ((System.Drawing.Image)(resources.GetObject("btn_Print.Image")));
			this.btn_Print.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_Print.Location = new System.Drawing.Point(16, 160);
			this.btn_Print.Name = "btn_Print";
			this.btn_Print.Size = new System.Drawing.Size(160, 72);
			this.btn_Print.TabIndex = 8;
			this.btn_Print.Text = "Print";
			this.btn_Print.Click += new System.EventHandler(this.btn_Print_Click);
			// 
			// btn_PrintSettings
			// 
			this.btn_PrintSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_PrintSettings.Image = ((System.Drawing.Image)(resources.GetObject("btn_PrintSettings.Image")));
			this.btn_PrintSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_PrintSettings.Location = new System.Drawing.Point(16, 115);
			this.btn_PrintSettings.Name = "btn_PrintSettings";
			this.btn_PrintSettings.Size = new System.Drawing.Size(160, 34);
			this.btn_PrintSettings.TabIndex = 7;
			this.btn_PrintSettings.Text = "Print Settings";
			this.btn_PrintSettings.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_PrintSettings.Click += new System.EventHandler(this.btn_PrintSettings_Click);
			// 
			// btn_PageSettings
			// 
			this.btn_PageSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_PageSettings.Image = ((System.Drawing.Image)(resources.GetObject("btn_PageSettings.Image")));
			this.btn_PageSettings.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_PageSettings.Location = new System.Drawing.Point(16, 73);
			this.btn_PageSettings.Name = "btn_PageSettings";
			this.btn_PageSettings.Size = new System.Drawing.Size(160, 34);
			this.btn_PageSettings.TabIndex = 6;
			this.btn_PageSettings.Text = "Page Settings";
			this.btn_PageSettings.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_PageSettings.Click += new System.EventHandler(this.btn_PageSettings_Click);
			// 
			// btn_PrintPreviw
			// 
			this.btn_PrintPreviw.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btn_PrintPreviw.Image = ((System.Drawing.Image)(resources.GetObject("btn_PrintPreviw.Image")));
			this.btn_PrintPreviw.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.btn_PrintPreviw.Location = new System.Drawing.Point(16, 32);
			this.btn_PrintPreviw.Name = "btn_PrintPreviw";
			this.btn_PrintPreviw.Size = new System.Drawing.Size(160, 34);
			this.btn_PrintPreviw.TabIndex = 5;
			this.btn_PrintPreviw.Text = "Print Preview";
			this.btn_PrintPreviw.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			this.btn_PrintPreviw.Click += new System.EventHandler(this.btn_PrintPreviw_Click);
			// 
			// PrintSettingsDialog
			// 
			this.AcceptButton = this.btn_Print;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(432, 271);
			this.Controls.Add(this.gb_Settings);
			this.Controls.Add(this.gb_Design);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.MaximizeBox = false;
			this.Name = "PrintSettingsDialog";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Print Settings";
			((System.ComponentModel.ISupportInitialize)(this.rb)).EndInit();
			this.gb_Design.ResumeLayout(false);
			this.gb_Settings.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion


	
 

		private void btn_ReportHeader_Click_2(object sender, System.EventArgs e)
		{
			rb.ShowReportHeaderDialog();
		}

		private void btn_TableStyle_Click_1(object sender, System.EventArgs e)
		{
			this.rb.ShowTableStyleDialog();			
		}

		private void btn_PageHeader_Click_1(object sender, System.EventArgs e)
		{
			rb.ShowPageHeaderDialog();			
		}

		private void btn_PageFooter_Click_1(object sender, System.EventArgs e)
		{
			rb.ShowPageFooterDialog();
		}

		private void btn_ReportFooter_Click_1(object sender, System.EventArgs e)
		{
			rb.ShowReportFooterDialog();
		}

		private void btn_PrintPreviw_Click(object sender, System.EventArgs e)
		{
			this.rb.ShowPrintPreviewDialog();
		}

		private void btn_PageSettings_Click(object sender, System.EventArgs e)
		{
			this.rb.ShowPageSetupDialog();
		}

		private void btn_PrintSettings_Click(object sender, System.EventArgs e)
		{
			this.rb.ShowPrintDialog();
		}

		private void btn_Print_Click(object sender, System.EventArgs e)
		{
			this.rb.Print();
			
		}


		
	}

}


