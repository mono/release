using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Threading;
using CustomControls.HelperClasses;
using CustomControls.BaseClasses;
using CustomControls.Editors;
using CustomControls.Functions;
using CustomControls.Enumerations;

namespace CustomControls.ApplicationBlocks
{

	public class PrintEngine:PrintDocument
	{
		private PrintElement _ReportHeader;
		private PrintElement _ReportFooter;
		private PrintElement _PageHeader;
		private PrintElement _PageFooter;
		protected  PaginationEngine _PagEngine;
		protected internal IPrintableClient _Client=null;
		private int pgNum=0;
		private Page _CurrentPage=null;

		protected Bitmap reportHeader=null;
		protected Bitmap reportFooter=null;
		protected Bitmap pageHeader=null;
		protected Bitmap pageFooter=null;
		
		private PageSettings _pageSettings;

		public Page CurrentPage
		{
			get{return _CurrentPage;}
		}

		public PaginationEngine PagEngine
		{
			get{return _PagEngine;}
		}

		public PrintElement ReportHeader
		{
			get{return _ReportHeader;}
		}

		public PrintElement ReportFooter
		{
			get{return _ReportFooter;}
		}

		public PrintElement PageHeader
		{
			get{return _PageHeader;}
		}

		public PrintElement PageFooter
		{
			get{return _PageFooter;}
		}
		
		public IPrintableClient Client
		{
			get{return _Client;}
			set{_Client= value;}
		}

		public PrintEngine()
		{
			_ReportHeader= new PrintElement(this);
			_ReportFooter= new PrintElement(this);
			_PageHeader= new PrintElement(this);
			_PageFooter= new PrintElement(this);
			_pageSettings= DefaultPageSettings;
		}

		
		protected override void OnBeginPrint(PrintEventArgs e)
		{
			if (PrinterSettings.IsValid)
			{
	
				base.OnBeginPrint(e);
				if (PrinterSettings.PrintRange==PrintRange.SomePages){pgNum=PrinterSettings.FromPage-1;}
				else{pgNum=0;}
			
				_PagEngine=null;
				reportHeader=null;
				reportFooter=null;
				pageHeader=null;
				pageFooter=null;	
			}
		}

		protected override void  OnPrintPage(PrintPageEventArgs e)
		{
		
			if (PrinterSettings.IsValid)
			{	
				if (this.PrinterSettings.PrintRange ==PrintRange.AllPages ||(this.PrinterSettings.PrintRange ==PrintRange.SomePages && pgNum+1>=PrinterSettings.FromPage && pgNum+1<=PrinterSettings.ToPage))
				{		
	
					if(PagEngine==null)
					{
						reportHeader=ReportHeader.GetElementBitmap(e.MarginBounds.Width,400);
						reportFooter=ReportFooter.GetElementBitmap(e.MarginBounds.Width,200);
						_PagEngine= new PaginationEngine(Client,e.MarginBounds,reportHeader.Height,PageHeader.GetHeight(e.Graphics,e.MarginBounds.Width,200),PageFooter.GetHeight(e.Graphics,e.MarginBounds.Width,200),reportFooter.Height);	
					}

					if (PagEngine.Pages.Count==0 || (pgNum>PagEngine.Pages.Count-1))
					{
						e.HasMorePages=false;
						return;
					}
					_CurrentPage=PagEngine.Pages[pgNum];
					
					pageHeader=PageHeader.GetElementBitmap(e.MarginBounds.Width,200);
					pageFooter=PageFooter.GetElementBitmap(e.MarginBounds.Width,200);

					
					
					
					
					int top=e.MarginBounds.Top;
					int dataHeight=e.MarginBounds.Height;
					int bottom=e.MarginBounds.Bottom;

					//reportHeader
					switch (CurrentPage.ReportHeader)
					{
						case PrintElementState.ExistVisible:
						{
							e.Graphics.DrawImage(reportHeader,e.MarginBounds.Left,top,reportHeader.Width,reportHeader.Height);
							top+=reportHeader.Height;
							dataHeight-=reportHeader.Height;
							break;
						}
						case PrintElementState.ExistInvizible:
						{
							top+=reportHeader.Height;
							dataHeight-=reportHeader.Height;
							break;
						}
						case PrintElementState.Missing:
						default:{break;}

					}

					//pageHeader
					e.Graphics.DrawImage(pageHeader,e.MarginBounds.Left,top,pageHeader.Width,pageHeader.Height);
					top+=pageHeader.Height;
					dataHeight-=pageHeader.Height;

					//reportFooter
					switch (CurrentPage.ReportFooter )
					{
						case PrintElementState.ExistVisible:
						{
							e.Graphics.DrawImage(reportFooter,e.MarginBounds.Left,bottom-reportFooter.Height,reportFooter.Width,reportFooter.Height);
							bottom-=reportFooter.Height;
							dataHeight-=reportFooter.Height;
							break;
						}
						case PrintElementState.ExistInvizible:
						{
							bottom-=reportFooter.Height;
							dataHeight-=reportFooter.Height;
							break;
						}
						case PrintElementState.Missing:
						default:{break;}
					}
					
					//pageFooter
					e.Graphics.DrawImage(pageFooter,e.MarginBounds.Left,bottom-pageFooter.Height,pageFooter.Width,pageFooter.Height);
					dataHeight-=pageFooter.Height;	

					//data
					
					Bitmap dataBmp=Client.GetGridBitmap(CurrentPage.ClientRectangle);

					e.Graphics.DrawImage(dataBmp,e.MarginBounds.Left,top,CurrentPage.ClientRectangle.Width,CurrentPage.ClientRectangle.Height);

				}
				pgNum++;
				_CurrentPage=null;

				if (pgNum>PagEngine.Pages.Count-1 || (PrinterSettings.PrintRange==PrintRange.SomePages && pgNum+1>PrinterSettings.ToPage)){e.HasMorePages=false;}
				else{e.HasMorePages=true;}
			}
		}

	}

	
}


