using System;
using System.Windows.Forms.Design;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms;
using System.Collections;
using System.ComponentModel.Design;
using CustomControls.Editors;
using CustomControls.ApplicationBlocks;

namespace CustomControls.Editors
{

	public class TableStyleTypeEditor: System.Drawing.Design.UITypeEditor 
	{
		private ITypeDescriptorContext _context;
		private IWindowsFormsEditorService edSvc = null;

		public TableStyleTypeEditor()
		{	

		}
		
	
		public override object EditValue(ITypeDescriptorContext context, IServiceProvider provider, object value) 
		{

			if (context != null	&& context.Instance != null	&& provider != null) 
			{
			
				object originalValue=value;
				_context=context;
				edSvc = (IWindowsFormsEditorService)provider.GetService(typeof(IWindowsFormsEditorService));

				if (edSvc != null) 
				{
					TableStyleEditor te = new TableStyleEditor((TableStyle)value);
						
					context.OnComponentChanging();
					if(edSvc.ShowDialog(te)==DialogResult.OK)
					{
						context.OnComponentChanged();
					}					
				
				}
			}

			return value;
		}

		
		public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context) 
		{
			if (context != null && context.Instance != null) 
			{
				return UITypeEditorEditStyle.Modal;
			}
			return base.GetEditStyle(context);
		}

		
	}
}
