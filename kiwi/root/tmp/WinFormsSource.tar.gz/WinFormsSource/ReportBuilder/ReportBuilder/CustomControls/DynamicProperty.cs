using System;
using System.Windows.Forms;
using System.Drawing;
using System.Collections;
using System.Drawing.Design;
using System.ComponentModel.Design.Serialization;
using System.Globalization;
using System.ComponentModel;
using System.ComponentModel.Design;
using CustomControls.Editors;

namespace CustomControls.HelperClasses
{

	[TypeConverter(typeof(PropertyCommandConverter))]
	public class PropertyCommand
	{
		private bool _ReadOnly=false;
		private bool _Visible=true;
		private string _Name="Property Command";

		[Category("Property Name")]
		public string Name
		{
			get{return _Name;}
		}

		[Category("Visibility")]
		public bool ReadOnly
		{
			get{return _ReadOnly;}
			set{_ReadOnly= value;}
		}

		[Category("Visibility")]
		public bool Visible
		{
			get{return _Visible;}
			set{_Visible=value;}
		}

		public PropertyCommand()
		{}

		public PropertyCommand(string Name)
		{
			this._Name= Name;	
		}

		public PropertyCommand(string Name,bool Visible, bool ReadOnly)
		{
			this._Name= Name;
			this._Visible=Visible;
			this._ReadOnly=ReadOnly;
		}

		public override string ToString()
		{
			return Name;
		}
	}


	[TypeConverter(typeof(CategoryCommandConverter))]
	public class CategoryCommand
	{
		private string _Name="Category Command";
		private bool _Visible= true;
 

		[Category("Visibility")]
		public bool Visible
		{
			get{return _Visible;}
			set{_Visible= value;}
		}

		[Category("Category Name")]
		public string Name
		{
			get{return _Name;}
		}

		public CategoryCommand()
		{}

		public CategoryCommand(string Name)
		{
			_Name= Name;
		}
		public CategoryCommand(string Name, bool Visible)
		{
			this._Name= Name;
			this._Visible=Visible;
		}
		public override string ToString()
		{
			return Name;
		}

	}


	public class PropertyCommands:CollectionBase
	{
		private CommandComparer _ComComp;


		public CommandComparer ComComp
		{
			get
			{
				if(_ComComp==null)
				{
					_ComComp= new CommandComparer();
				}
				return _ComComp;
			}
		}

		public int Add(PropertyCommand pc)
		{
			return this.InnerList.Add(pc);
		}

		public void AddRange(PropertyCommand[] pcs)
		{
			InnerList.AddRange(pcs);
		}

		public void Remove(PropertyCommand pc)
		{
			InnerList.Remove(pc);
		}

		public new void RemoveAt(int index)
		{
			InnerList.RemoveAt(index);
		}

		public void Sort()
		{
			InnerList.Sort(ComComp);
		}

		public bool Contains(PropertyCommand pc)
		{
			return InnerList.Contains(pc);
		}

		public bool Contains(string Name)
		{
			return this[Name]!=null;
		}

		public PropertyCommand this[string Name]
		{
			get
			{
				InnerList.Sort(ComComp);
				int index= InnerList.BinarySearch(Name,ComComp);
				if(index>-1){return (PropertyCommand)this.InnerList[index]; }
				else{return null;}
			}
		}

		public int BinarySearch(PropertyCommand value)
		{
			InnerList.Sort(ComComp);
			return InnerList.BinarySearch(value,ComComp);
		}

		public PropertyCommand this[int index]
		{
			get{return (PropertyCommand)this.InnerList[index];}
			set{this.InnerList[index]= value;}
		}
	}


	public class CategoryCommands:CollectionBase
	{

		private CommandComparer _ComComp;

		public CommandComparer ComComp
		{
			get
			{
				if(_ComComp==null)
				{
					_ComComp= new CommandComparer();
				}
				return _ComComp;
			}
		}

		public int Add(CategoryCommand cc)
		{
			return this.InnerList.Add(cc);
		}

		public void AddRange(CategoryCommand[] ccs)
		{
			InnerList.AddRange(ccs);
		}

		public void Remove(CategoryCommand cc)
		{
			InnerList.Remove(cc);
		}

		public new void RemoveAt(int index)
		{
			InnerList.RemoveAt(index);
		}

		public bool Contains(CategoryCommand cc)
		{
			return InnerList.Contains(cc);
		}

		public bool Contains(string Name)
		{
			return this[Name]!=null;
		}

		public void Sort()
		{
			InnerList.Sort(ComComp);
		}

		public int BinarySearch(CategoryCommand cc)
		{
			InnerList.Sort(ComComp);
			return InnerList.BinarySearch(cc,ComComp);
		}

		public CategoryCommand this[string Name]
		{
			get
			{
				InnerList.Sort(ComComp);
				int index= InnerList.BinarySearch(Name,ComComp);
				if(index>-1){return (CategoryCommand)this.InnerList[index]; }
				else{return null;}
			}
		}

		public CategoryCommand this[int index]
		{
			get{return (CategoryCommand)this.InnerList[index];}
			set{this.InnerList[index]= value;}
		}
	}


	internal class PropertyCommandConverter:ExpandableObjectConverter
	{
	
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(PropertyCommand).GetConstructor(new Type[]{typeof(string), typeof(bool), typeof(bool)}), new object[]{((PropertyCommand)value).Name,((PropertyCommand)value).Visible,((PropertyCommand)value).ReadOnly},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}

		
	}


	internal class CategoryCommandConverter:ExpandableObjectConverter
	{
	
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(CategoryCommand).GetConstructor(new Type[]{typeof(string), typeof(bool)}), new object[]{((CategoryCommand)value).Name,((CategoryCommand)value).Visible},true);
			}
			return base.ConvertTo(context,info,value,destType);
		}

		
	}


	public class CustomCollectionEditorDialog:CustomControls.Editors.CustomCollectionEditorForm
	{

		public CustomCollectionEditorDialog()
		{
			btn_Up.Enabled=false;
			btn_Down.Enabled=false;
			this.ImageList=CustomControls.BaseClasses.ImageRes.ImageList;
		}


		protected override void SetProperties(TItem titem, object reffObject)
		{
			
			if(reffObject is PropertyCommand)
			{
				PropertyCommand pc =reffObject as PropertyCommand;
			
				titem.Text=pc.Name;
				if(pc.Visible==false)
				{
					titem.ForeColor=Color.Red;
					titem.ImageIndex=0;
					titem.SelectedImageIndex=0;
				}
				else if(pc.ReadOnly==true)
				{
					titem.ForeColor=Color.Peru;
					titem.ImageIndex=10;
					titem.SelectedImageIndex=10;
				}
				else
				{
					titem.ForeColor=Color.Black;
					titem.ImageIndex=9;
					titem.SelectedImageIndex=9;
				}

			}
			else if(reffObject is CategoryCommand)
			{
				CategoryCommand cc =reffObject as CategoryCommand;
				titem.Text=cc.Name;
			
				if(cc.Visible==false)
				{
					titem.ForeColor=Color.Red;
					titem.ImageIndex=0;
					titem.SelectedImageIndex=0;
				}
				else
				{
					titem.ForeColor=Color.Black;
					titem.ImageIndex=9;
					titem.SelectedImageIndex=9;
				}
			}
					
		}

		
		protected override CustomControls.Enumerations.EditLevel SetEditLevel(IList collection)
		{
			return CustomControls.Enumerations.EditLevel.ReadOnly;
		}


	}


	public class CustomCommandsCollectionEditor:CustomCollectionEditor
	{
		protected override CustomCollectionEditorForm CreateForm()
		{
			return new CustomCollectionEditorDialog ();
		}

	}


	public class CommandComparer:System.Collections.IComparer
	{
		
		int System.Collections.IComparer.Compare (object o1, object o2)
		{
			return string.Compare(o1.ToString(),o2.ToString(),true);
		}


	}


}