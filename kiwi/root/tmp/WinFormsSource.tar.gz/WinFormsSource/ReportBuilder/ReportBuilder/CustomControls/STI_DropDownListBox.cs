using System;
using System.Windows.Forms;
using System.ComponentModel;
using STI_Library.BaseClasses;

namespace STI_Library.Win32Controls
{
	public class STI_DropDownListBox:DropDownListBase
	{

		private ListBox _List= new ListBox();
		private int _MaxDropDawnItems=8;
		private int _MinListWidth=140;

		protected override System.Windows.Forms.Control HostedControl
		{
			get
			{
				return List;
			}
		}

		[Category("Behavior")]
		public int MinListWidth
		{
			get{return _MinListWidth;}
			set{_MinListWidth= value;}
		}

		[Browsable(false)]
		public virtual ListBox List
		{
			get{return _List;}
		}

		[Category("Behavior")]
		[DefaultValue(typeof(System.Int16),"8")]
		public int MaxDropDownItems
		{
			get{return _MaxDropDawnItems;}
			set{_MaxDropDawnItems=value;}
		}

		public STI_DropDownListBox():base()
		{
			List.BorderStyle=System.Windows.Forms.BorderStyle.None;
			List.SelectedIndexChanged+=new EventHandler(List_SelectedItemChanged);
			List.MouseUp+= new MouseEventHandler(List_MouseUp);

			
		}

		protected override void OnDropDown(System.EventArgs e)
		{
			if (Text!=string.Empty)	{List.SelectedIndex=List.FindString(Text);}
			else{List.SelectedIndex=-1;}

			int lHeight,lWidth;
			lHeight=Math.Max(List.ItemHeight,Math.Min(MaxDropDownItems, List.Items.Count)*List.ItemHeight);
			lWidth=Math.Max(this.Width+20,_MinListWidth);
			dropDownForm.Size= new System.Drawing.Size(lWidth,lHeight+4);
			
		}


		private void List_SelectedItemChanged(object sender, EventArgs e )
		{
			if(List.SelectedIndex!=-1)
			{
				Text=List.Text;
				editControl.SelectAll();

			}
		}
		
		private void List_MouseUp(object sender , MouseEventArgs e)
		{
			DroppedDown=false;
		}

		

		protected override void OnNextItem()
		{
			if(List.SelectedIndex<List.Items.Count-1)
			{
				List.SelectedIndex+=1;
			}
		}

		protected override void OnPrevItem()
		{
			if(List.SelectedIndex>0)
			{
				List.SelectedIndex-=1;
			}
		}



		
	}

}