using System;
using System.Collections;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;
using System.Threading;
using CustomControls.HelperClasses;
using CustomControls.BaseClasses;
using CustomControls.Editors;
using CustomControls.Functions;
using CustomControls.Enumerations;


namespace CustomControls.ApplicationBlocks
{
	public class PaginationEngine
	{
		private PageCollection _Pages= new PageCollection(); 
		
		

		public PageCollection Pages
		{
			get{return _Pages;}
		}

		public PaginationEngine(IPaginationClient Client, Rectangle pageBounds,int reportHeaderHeight, int pageHeaderHeight, int pageFooterHeight, int reportFooterHeight)
		{
			Client.ResetInitialization();
			Rectangle cVirtualRect=Client.ClientVirtualRectangle;
			int rowNum=0;
			int pageBottom=0;
			bool isLastRow=false;
			


			while(pageBottom<=cVirtualRect.Height)
			{

				int cHeight=pageBounds.Height- pageHeaderHeight-pageFooterHeight;
				if(rowNum==0){cHeight-=reportHeaderHeight;	}

				Rectangle clientRectangle= new Rectangle(0,pageBottom,pageBounds.Width,cHeight);
				Rectangle pageRect=Client.GetPageRectangle(clientRectangle);

				if(pageRect.Bottom==cVirtualRect.Bottom )
				{
					
					Rectangle tClientRectangle=clientRectangle;
					Rectangle tPageRect=pageRect;

					// try to put the report footer
					cHeight-=reportFooterHeight;
					clientRectangle= new Rectangle(0,pageBottom,pageBounds.Width,cHeight);
					pageRect=Client.GetPageRectangle(clientRectangle);
					
					
					if(pageRect.Bottom<cVirtualRect.Bottom )
					{
						// didn't work out. there is no room
						clientRectangle= tClientRectangle;
						pageRect=tPageRect;
					}
					else
					{
						// we just spare a paper !
						pageBottom++;
						isLastRow=true;
					}
								
				}	
			
				CreatePages(Client,pageBounds,pageRect,rowNum,isLastRow);

				rowNum++;
				pageBottom +=pageRect.Height;
			}


		

		}

		
		private void CreatePages( IPaginationClient pClient, Rectangle pageBounds,Rectangle rowClientRect,int rowNum, bool isLastRow)
		{
			Rectangle cVirtualRect=pClient.ClientVirtualRectangle;
			int colNum=0;
			int pageRight=0;
			bool isLastColumn=false;


			while(pageRight<cVirtualRect.Right)
			{
				Rectangle clientRectangle= new Rectangle(pageRight,rowClientRect.Y,pageBounds.Width,rowClientRect.Height);
				Rectangle pageRect=pClient.GetPageRectangle(clientRectangle);
	
   

				if(pageRect.Right==cVirtualRect.Right){isLastColumn=true;}
				PrintElementState reportHeader=PrintElementState.Missing;
				PrintElementState reportFooter=PrintElementState.Missing;

				if(rowNum==0 && colNum==0 ){reportHeader=PrintElementState.ExistVisible;}
				else if(rowNum==0){reportHeader=PrintElementState.ExistInvizible;}
				else{reportHeader=PrintElementState.Missing;}

				if(isLastRow && isLastColumn){reportFooter=PrintElementState.ExistVisible;}
				else if(isLastRow){reportFooter=PrintElementState.ExistInvizible;}
				else{reportFooter=PrintElementState.Missing;}


				Page newPage= new Page(rowNum,colNum,pageRect,reportHeader, reportFooter);
				this.Pages.Add(newPage);

				colNum++;
				pageRight+=pageRect.Width;
			}

		}

	}

}

namespace CustomControls.HelperClasses
{
	public class Page
	{
		private int _Row;
		private int _Column;
		private Rectangle _ClientRectangle;
		private PrintElementState _ReportHeader;
		private PrintElementState _ReportFooter;

		public Page(int Row, int Column, Rectangle clientRectangle, PrintElementState reportHeader, PrintElementState reportFooter)
		{
			this._ClientRectangle=clientRectangle;
			this._Row=Row;
			this._Column=Column;
			this._ReportHeader=reportHeader;
			this._ReportFooter= reportFooter;
		}

		public PrintElementState ReportHeader
		{
			get{return _ReportHeader;}
		}

		public PrintElementState ReportFooter
		{
			get{return _ReportFooter;}
		}

		public Rectangle ClientRectangle
		{
			get{return _ClientRectangle;}
		}

		public int Row
		{
			get{return _Row;}
		}

		public int Column
		{
			get{return _Column;}
		}
	}

	public class PageCollection:CollectionBase
	{
		public int Add(Page page)
		{
			return InnerList.Add(page);
		}

		public void Remove(Page page)
		{
			InnerList.Remove(page);
		}

		public bool Contains(Page page)
		{
			return InnerList.Contains(page);
		}
		public int IndexOf(Page page)
		{
			return this.InnerList.IndexOf(page);
		}


		public Page this[int index]
		{
			get{return (Page)this.InnerList[index];}
		}
	}

}

namespace CustomControls.BaseClasses
{
	public interface IPaginationClient
	{
		Rectangle GetPageRectangle(Rectangle virtualRegion);
		Rectangle ClientVirtualRectangle{get;}
		void ResetInitialization();
	}

	public interface IPrintableClient:IPaginationClient
	{
		Bitmap GetGridBitmap(Rectangle virtualRegion);
		Bitmap GetColumnsHeaderBitmap(Rectangle virtualRegion, Color BackColor, Color ForeColor,Color LineColor,Font Font,int Height,DataGridLineStyle LineStyle);
	}
	public interface IReportSource
	{
		System.Data.DataView GetSource();
	}
}

namespace CustomControls.Enumerations
{
	public enum PrintElementState
	{
		ExistVisible=0,
		ExistInvizible=1,
		Missing=2
	}
}