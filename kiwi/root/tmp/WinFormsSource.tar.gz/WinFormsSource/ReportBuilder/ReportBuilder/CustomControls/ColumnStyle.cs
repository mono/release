using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Globalization;
using System.ComponentModel.Design.Serialization;
using System.Collections;
using CustomControls.Editors;
using CustomControls.ApplicationBlocks;
using CustomControls.HelperClasses;

namespace CustomControls.ApplicationBlocks
{
	[TypeConverter(typeof(ColumnStyle_Converter))]
	public class ColumnStyle:DynamicTypeDescriptor,ISupportStandardValues
	{
		#region "Variables"



		private HorizontalAlignment _Alignment=HorizontalAlignment.Left;
		private string _HeaderText="Header Text";
		private string _NullText="Null";
		private int _Width=80;
		private string _Format=string.Empty;
		private Color _ForeColor=Color.Black;
		private Color _BackColor=Color.Transparent;
		private Font _Font=new System.Drawing.Font("Tahoma", 10f, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, 0);
		private bool _Visible=true;
		private string _MappingName=string.Empty;
		private TableStyle  _TableStyle=null;

		#endregion

		#region "Properties"

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public TableStyle TableStyle
		{
			get{return _TableStyle;}
			
		}

		[TypeConverter(typeof(StandardValuesConverter))]
		public string MappingName
		{
			get{return _MappingName;}
			set
			{
				_MappingName= value;
				if(HeaderText=="Header Text")
				{
					HeaderText=MappingName;
				}
			}
		}

		public bool Visible
		{
			get{return _Visible;}
			set
			{
				if(value!=_Visible)
				{
					_Visible= value;
				}
			}
		}

		public HorizontalAlignment Alignment
		{
			get{return _Alignment;}
			set
			{
				if(value!= _Alignment)
				{
					_Alignment= value;
				}
			}
		}

	
		public string HeaderText
		{
			get{return _HeaderText;}
			set
			{
				if(value!=_HeaderText)
				{
					_HeaderText= value;
				}
			}
		}


		public string NullText
		{
			get{return _NullText;}
			set
			{
				if(value!=_NullText)
				{
					_NullText= value;
				}
			}
		}

	
		public string Format
		{
			get{return _Format;}
			set
			{
				if(value!=_Format)
				{
					_Format= value;
				}
			}
		}
		
	
		public int Width
		{
			get{return _Width;}
			set
			{
				if(value!=_Width && value >0)
				{
					_Width= value;
				}
			}

		}


		public Color ForeColor
		{
			get{return _ForeColor;}
			set
			{
				if(_ForeColor!=value)
				{
					_ForeColor=value;
				}
			}
		}


		public Font Font
		{
			get{return _Font;}
			set
			{
				if(value!=_Font)
				{
					_Font= value;
				}
			}
		}


		public Color BackColor
		{
			get{return _BackColor;}
			set
			{
				if(_BackColor!=value)
				{
					_BackColor=value;
				}
			}
		}

		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public bool StandardValuesExclusive
		{
			get{return true;}
		}		
		
		
		#endregion

		#region "Constructor"

		public ColumnStyle():base()
		{
						
		}

		public ColumnStyle(TableStyle tableStyle):base()
		{
			this._TableStyle=tableStyle;		
		}
		

		#endregion

		#region "Implementation"

		public string[] GetStandardValues()
		{
			string[] values = new string[0];
			if(TableStyle!=null && TableStyle.Table!=null)
			{
				values= new string[TableStyle.Table.Columns.Count];

				for(int i=0;i < TableStyle.Table.Columns.Count;i++)
				{
					values[i]=TableStyle.Table.Columns[i].ColumnName;
				}
			}
			return values;
		}


		internal void SetTableStyle(TableStyle tableStyle )
		{
			this._TableStyle= tableStyle;
		}

		public override string GetLocalizedName(string Name)
		{			
			string name=CustomControls.Globalization.Dictionary.Translate(Name);
			if(name!=null ){return name;}
			return base.GetLocalizedName (Name);
		}

		public override string GetLocalizedDescription(string Description)
		{
			string descr=CustomControls.Globalization.Dictionary.Translate(Description + "_Descr");
			if(descr!=null ){return descr;}
			return base.GetLocalizedName (Description);
		}


		#endregion
	}

}

namespace CustomControls.HelperClasses
{
	public class ColumnStyles:CollectionBase
	{
		private TableStyle _TableStyle=null;

		public TableStyle TableStyle
		{
			get{return _TableStyle;}
		}

		public ColumnStyles(TableStyle tableStyle)
		{
			this._TableStyle= tableStyle;
		}

		public int Add(ColumnStyle cs)
		{
			cs.SetTableStyle(this.TableStyle);
			return this.InnerList.Add(cs);
		}

		public void AddRange(ColumnStyle[] css)
		{
			foreach(ColumnStyle col in css )
			{
				this.Add(col);
			}
			
		}

		public void Remove(ColumnStyle cs)
		{
			InnerList.Remove(cs);
		}

		public new void RemoveAt(int index)
		{
			InnerList.RemoveAt(index);
		}

		public bool Contains(ColumnStyle cs)
		{
			return InnerList.Contains(cs);
		}

		public ColumnStyle this[int index]
		{
			get{return (ColumnStyle)this.InnerList[index];}
			set{this.InnerList[index]= value;}
		}
	}

	internal class ColumnStyleCollEditForm:CustomControls.Editors.CustomCollectionEditorForm
	{

		public ColumnStyleCollEditForm()
		{
			this.ImageList=CustomControls.BaseClasses.ImageRes.ImageList;
		}


		protected override void SetProperties(TItem titem, object reffObject)
		{
			
			if(reffObject is ColumnStyle)
			{
				ColumnStyle cs =reffObject as ColumnStyle;
			
				titem.Text=cs.HeaderText;
				if(cs.Visible==false || cs.MappingName==string.Empty)
				{
					titem.ForeColor=Color.Red;
					titem.ImageIndex=0;
					titem.SelectedImageIndex=0;
				}			
				else
				{
					titem.ForeColor=Color.Black;
					titem.ImageIndex=7;
					titem.SelectedImageIndex=7;
				}

			}
		
					
		}

		
		protected override CustomControls.Enumerations.EditLevel SetEditLevel(IList collection)
		{	
			bool designMode=CustomControls.Functions.General.IsInDesignMode();
		 
			if(designMode) 
			{ 
				return CustomControls.Enumerations.EditLevel.FullEdit;
			}     
			else
			{
				return CustomControls.Enumerations.EditLevel.ReadOnly;
			}		 
		}

	
		protected override object CreateInstance(Type itemType)
		{

			ColumnStyles col =this.Collection as ColumnStyles;
			if(col!=null && (itemType == typeof(ColumnStyle)))
			{			
				return new ColumnStyle(col.TableStyle);
			}
			else
			{
				return base.CreateInstance (itemType);
			}
		}

		
		
	}

	internal class ColumnStyleCollEdit:CustomCollectionEditor
	{
		protected override CustomCollectionEditorForm CreateForm()
		{
			return new ColumnStyleCollEditForm ();
		}

	}
	internal class ColumnStyle_Converter:ExpandableObjectConverter
	{
	
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destType) 
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return true;
			}
			return base.CanConvertTo(context, destType);
		}	
		
		
		public override object  ConvertTo(ITypeDescriptorContext context,CultureInfo info,object value,Type destType )
		{
			if (destType == typeof(InstanceDescriptor)) 
			{
				return new InstanceDescriptor(typeof(ColumnStyle).GetConstructor(new Type[0]),null,false);
			}
			return base.ConvertTo(context,info,value,destType);
		}

		
	}
}

