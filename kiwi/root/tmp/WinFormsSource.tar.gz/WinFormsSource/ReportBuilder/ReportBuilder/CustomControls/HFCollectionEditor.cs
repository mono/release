using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using CustomControls.BaseClasses;
using CustomControls.HelperClasses;


namespace CustomControls.Editors
{
	public class HFCollectionEditor : CustomControls.Editors.CustomCollectionEditorForm
	{
		private HFViewer hfViewer;
	
		private System.ComponentModel.IContainer components = null;

		public HFCollectionEditor()
		{
			InitializeComponent();
			this.pg_PropGrid.HelpVisible=false;
			
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}


		public override IList Collection
		{
			get
			{
				return base.Collection;
			}
			set
			{
				if(value is PrintElement)
				{
					base.Collection = value;
					hfViewer.Element=(PrintElement)value;
				}
				else
				{
					throw new ApplicationException("Collection should be a PrintElement!");
				}
			}
		}


		#region Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.hfViewer = new CustomControls.HelperClasses.HFViewer();
			((System.ComponentModel.ISupportInitialize)(this.btn_Add)).BeginInit();
			this.pan_PropGridPan.SuspendLayout();
			// 
			// pg_PropGrid
			// 
			this.pg_PropGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.pg_PropGrid.HelpVisible = true;
			this.pg_PropGrid.Name = "pg_PropGrid";
			this.pg_PropGrid.Size = new System.Drawing.Size(223, 184);
			this.pg_PropGrid.Text = "";
			this.pg_PropGrid.ViewBackColor = System.Drawing.Color.Beige;
			// 
			// btn_Add
			// 
			// 
				// 
			// pan_PropGridPan
			// 
			this.pan_PropGridPan.Controls.Add(this.hfViewer);
			this.pan_PropGridPan.Location = new System.Drawing.Point(228, 0);
			this.pan_PropGridPan.Name = "pan_PropGridPan";
			this.pan_PropGridPan.Size = new System.Drawing.Size(238, 360);
			this.pan_PropGridPan.Controls.SetChildIndex(this.hfViewer, 0);
			this.pan_PropGridPan.Controls.SetChildIndex(this.pg_PropGrid, 0);
			// 
			// hfViewer
			// 
			this.hfViewer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.hfViewer.Element = null;
			this.hfViewer.Location = new System.Drawing.Point(8, 197);
			this.hfViewer.Name = "hfViewer";
			this.hfViewer.Size = new System.Drawing.Size(222, 155);
			this.hfViewer.TabIndex = 4;
			// 
			// HFCollectionEditor
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(480, 424);
			this.Name = "HFCollectionEditor";
			((System.ComponentModel.ISupportInitialize)(this.btn_Add)).EndInit();
			this.pan_PropGridPan.ResumeLayout(false);

		}
		#endregion


		protected override void OnItemAdded(object Item)
		{
			base.OnItemAdded (Item);
			hfViewer.Invalidate();
		}

		protected override void OnItemRemoved(object item)
		{
			base.OnItemRemoved (item);
			hfViewer.Invalidate();
		}

		protected override void SetProperties(TItem titem, object reffObject)
		{
			base.SetProperties (titem, reffObject);
			hfViewer.Invalidate();
		}


		protected override void OnResize(EventArgs e)
		{
			base.OnResize (e);
			this.spl_Splitter.SplitPosition=this.Width- 250;
		}
	}
}

