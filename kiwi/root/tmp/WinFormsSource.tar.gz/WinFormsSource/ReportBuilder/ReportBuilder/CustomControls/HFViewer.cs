using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using CustomControls.ApplicationBlocks;
using System.Windows.Forms;
using CustomControls.BaseClasses;

namespace CustomControls.HelperClasses
{

	public class HFViewer:Control
	{
		private PrintElement _Element=null;

		protected override Size DefaultSize
		{
			get
			{
				return new Size(240,160);
			}
		}

		public PrintElement Element
		{
			get{return _Element;}
			set{_Element= value;}
		}

		public HFViewer()
		{
			SetStyle(ControlStyles.UserPaint, true); 
			SetStyle(ControlStyles.AllPaintingInWmPaint, true); 
			SetStyle(ControlStyles.DoubleBuffer, true);
			SetStyle(ControlStyles.ResizeRedraw,true);
		}


		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint (e);
			e.Graphics.FillRectangle(Brushes.White,ClientRectangle);

			if(Element!=null)
			{
				Bitmap rhBmp= Element.GetElementBitmap(this.Width-1,this.Height-1);
				if(rhBmp!=null)
				{
					e.Graphics.DrawImage(rhBmp,1,1);
				}
			}
			e.Graphics.DrawRectangle(Pens.Black,0,0,Width-1, Height-1);
		}
	}
}
