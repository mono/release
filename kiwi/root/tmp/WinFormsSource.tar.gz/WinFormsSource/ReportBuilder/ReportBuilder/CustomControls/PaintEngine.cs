using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Data;
using CustomControls.BaseClasses;


namespace CustomControls.ApplicationBlocks
{
	
	public class PaintEngine:IPrintableClient
	{

		#region "Variables"

		private TableStyle _TableStyle ;
		private DataView _DataSource;
		private int _VirtualWidth=-1;
		private int _VirtualHeight=-1;
		private SolidBrush _SBrush=null;
		private Pen _Pen=null;
		private Rectangle _CaptionVirtualRect=Rectangle.Empty;
		private Rectangle _HeaderVirtualRect=Rectangle.Empty;
		private Rectangle _GridVirtualRect=Rectangle.Empty;
		private StringFormat strFormat= new StringFormat(StringFormatFlags.NoWrap);

		#endregion

		#region "Properties"

		public TableStyle TableStyle
		{
			get
			{
				if(_TableStyle==null)
				{
					_TableStyle= new TableStyle();
				}
				return _TableStyle;
			}
			set{_TableStyle= value;}
		}

		public DataView DataSource
		{
			get{return _DataSource;}
			set
			{_DataSource= value;}
		}


		protected int VirtualWidth
		{
			get
			{
				if (_VirtualWidth<0)
				{
					_VirtualWidth=GetVirtualWidth();
				}
				return _VirtualWidth;
			}
		}

		protected int VirtualHeight
		{
			get
			{
				if (_VirtualHeight<0)
				{
					_VirtualHeight=GetVirtualHeight();
				}
				return _VirtualHeight;
			}
		}

	
		


		protected Rectangle GridVirtualRect
		{
			get
			{
				if(_GridVirtualRect==Rectangle.Empty)
				{
					_GridVirtualRect=new Rectangle(0,0,GetVirtualWidth(),GetRowsHeight());
				}
				return _GridVirtualRect;
			}
		}

		protected SolidBrush SBrush
		{
			get
			{
				if(_SBrush==null)
				{
					_SBrush= new SolidBrush(TableStyle.BackColor);
				}
				return _SBrush;
			}
		}

		protected Pen Pen
		{
			get
			{
				if(_Pen==null)
				{
					_Pen= new Pen(TableStyle.GridLineColor);
				}
				return _Pen;
			}
		}


		public Rectangle ClientVirtualRectangle
		{
			get{return new Rectangle(0,0,this.VirtualWidth,this.VirtualHeight);}
		}
		
		#endregion
	
		#region "Constructor"

		public PaintEngine()
		{
			strFormat.Trimming=StringTrimming.EllipsisCharacter;
			strFormat.LineAlignment=StringAlignment.Center;
		}
		
		#endregion

		#region "Paint"

		public Bitmap GetGridBitmap(Rectangle virtualRegion)
		{

			Bitmap vBitmap= new Bitmap(virtualRegion.Width,virtualRegion.Height);
			
			using (Graphics g=Graphics.FromImage(vBitmap))
			{
				Rectangle GridRelativeRegion=GetRelInterRegion(GridVirtualRect,virtualRegion);


				if(GridRelativeRegion.Height>0 && GridRelativeRegion.Width>0) 
				{
					Rectangle bounds= GetRelInterRegion(virtualRegion,GridVirtualRect);
					PaintGrid(g,bounds,GridRelativeRegion);
					g.DrawRectangle(new Pen(TableStyle.GridLineColor),new Rectangle(0,0,bounds.Width-1, bounds.Height-1));
				}

			}
						
			return vBitmap;
		}


		public Bitmap GetColumnsHeaderBitmap(Rectangle virtualRegion, Color BackColor, Color ForeColor,Color LineColor,Font Font,int Height,DataGridLineStyle LineStyle)
		{

			Bitmap vBitmap= new Bitmap(virtualRegion.Width,virtualRegion.Height);
			
			using (Graphics g=Graphics.FromImage(vBitmap))
			{
				Rectangle HeaderVirtualRect= new Rectangle(0,0,GetVirtualWidth(),Height);
				Rectangle HeaderRelativeRegion= GetRelInterRegion(HeaderVirtualRect,virtualRegion);
			
				if(HeaderRelativeRegion.Height>0 && HeaderRelativeRegion.Width>0)
				{
					Rectangle bounds= GetRelInterRegion(virtualRegion,HeaderVirtualRect);
					PaintHeader(g,bounds,HeaderRelativeRegion, BackColor, ForeColor,LineColor,Font, Height, LineStyle);
					if(LineStyle==DataGridLineStyle.Solid){	g.DrawRectangle(new Pen(LineColor),new Rectangle(0,0,bounds.Width-1, bounds.Height-1));}
				
				} 					

			}
						
			return vBitmap;
		}
	

		public void PaintHeader(Graphics g,Rectangle bounds, Rectangle virtualRegion,Color BackColor, Color ForeColor,Color LineColor,Font Font,int Height,DataGridLineStyle LineStyle)
		{
			SBrush.Color=BackColor;
			Pen.Color=LineColor;
			strFormat.Alignment=StringAlignment.Near;
			

			Rectangle rect= new Rectangle(bounds.X-virtualRegion.X,bounds.Y-virtualRegion.Y, GetVirtualWidth()-1, Height);
			g.FillRectangle(SBrush,rect);

			int xOffset=bounds.X-virtualRegion.X;
			int yOffset = bounds.Y-virtualRegion.Y;

			foreach(ColumnStyle col in TableStyle.ColumnStyles )
			{
				if(col.Visible && col.MappingName!=string.Empty)
				{
					Rectangle colRect= new Rectangle(xOffset,yOffset,col.Width-1,Height);
				
					if(colRect.IntersectsWith(bounds))
					{	
						SBrush.Color=ForeColor;
						PaintHeaderCell(g,colRect,SBrush,col,strFormat, Font);
						SBrush.Color=LineColor;
						if (LineStyle==DataGridLineStyle.Solid){	g.DrawLine(Pen,colRect.Right,colRect.Top,colRect.Right,colRect.Bottom);}
					}				
					xOffset+= col.Width;
				}
			}
			
			g.DrawRectangle(Pen,rect);
		}

		private void PaintHeaderCell(Graphics g, Rectangle bounds,SolidBrush brush, ColumnStyle col, StringFormat strFormat, Font font)
		{
			Rectangle textRect=new Rectangle(bounds.X+5,bounds.Y, bounds.Width-5,bounds.Height); 
			g.DrawString(col.HeaderText,font,brush,textRect,strFormat);
			
		}

		public void PaintGrid(Graphics g,Rectangle bounds, Rectangle virtualRegion)
		{
			SBrush.Color=TableStyle.BackColor;
			Pen.Color=TableStyle.GridLineColor;
			bool alt=false;

			Rectangle rect= new Rectangle(bounds.X-virtualRegion.X,bounds.Y-virtualRegion.Y, GridVirtualRect.Width-1, GridVirtualRect.Height);



			int firstIndex=GetFirstVisibleRow(virtualRegion);
			int lastIndex=GetLastVisibleRow(virtualRegion);
			int rowYOffset=bounds.Y-virtualRegion.Y+ (firstIndex*TableStyle.RowHeight);
			

			for(int i=firstIndex; i<= lastIndex;i++ )
			{
				Rectangle rowVirtualRect= GetRowVirtualRect(i);
				Rectangle rowRelativeRegion= GetRelInterRegion(rowVirtualRect,virtualRegion);
				Rectangle rowBounds= GetRelInterRegion(virtualRegion,rowVirtualRect);
				rowBounds.Offset(bounds.X, bounds.Y);
				
				PaintRow(g,rowBounds,rowRelativeRegion,DataSource[i], alt);

				
				if(TableStyle.HGridLine)
				{
					Pen.Color=TableStyle.GridLineColor;
					g.DrawLine(Pen,bounds.Left,rowYOffset,bounds.Right-1,rowYOffset);
					rowYOffset+=TableStyle.RowHeight;
				}
				alt=!alt;
			}
			
			g.DrawRectangle(Pen,rect);
		}


		private void PaintRow(Graphics g, Rectangle bounds,Rectangle virtualRegion, DataRowView row, bool alternating)
		{

			int xOffset=bounds.X-virtualRegion.X;
			int yOffset = bounds.Y-virtualRegion.Y;

			SBrush.Color=alternating?TableStyle.AlternatingBackColor:TableStyle.BackColor;
			g.FillRectangle(SBrush,bounds);

			foreach(ColumnStyle col in TableStyle.ColumnStyles )
			{
				if(col.Visible && col.MappingName!=string.Empty)
				{
					Rectangle cellRect= new Rectangle(xOffset,yOffset,col.Width-1,TableStyle.RowHeight);
				
					if(cellRect.IntersectsWith(bounds))
					{	
						
						PaintRowCell(g,cellRect,row,col);

						if(TableStyle.VGridLine)
						{
							g.DrawLine(Pen,cellRect.Right,cellRect.Top,cellRect.Right,cellRect.Bottom);
						}
					}				
					xOffset+= col.Width;
				}
			}

		}


		private void PaintRowCell(Graphics g, Rectangle bounds,DataRowView row, ColumnStyle col)
		{
			object value=row[col.MappingName];
			string text;
			
			strFormat.Alignment=GetAlignment(col.Alignment);
			
		
			if(value!=null)
			{
				
				if(col.Format!=string.Empty)
				{
					string format="{0:" + col.Format + "}";
					text=string.Format(format,value);
				}
				else
				{
					text=value.ToString();
				}				
			}
			else
			{
				text=col.NullText;
			}

			if(col.BackColor!=Color.Transparent)
			{
				SBrush.Color=col.BackColor;
				g.FillRectangle(SBrush,bounds);
			}

			SBrush.Color=col.ForeColor;

			g.DrawString(text,col.Font,SBrush,bounds,strFormat);
		}

		#endregion

		#region "Implementation"

		private StringAlignment GetAlignment(HorizontalAlignment align)
		{
			switch(align)
			{
				case HorizontalAlignment.Center:
				{
					return StringAlignment.Center;
				}
				case HorizontalAlignment.Left:
				{
					return StringAlignment.Near;
				}
				case HorizontalAlignment.Right:
				{
					return StringAlignment.Far;
				}
				default:
				{
					return StringAlignment.Near;
				}
			}
		}

		private Rectangle GetRowVirtualRect(int row)
		{
			return new Rectangle(0,0 + row*TableStyle.RowHeight,GridVirtualRect.Width,TableStyle.RowHeight);	
		}

		private int GetFirstVisibleRow(Rectangle virtualRegion)
		{
			if(DataSource!=null && DataSource.Count>0)
			{
				double index = virtualRegion.Y/TableStyle.RowHeight;
				
				return (int)Math.Floor(index);
			}
			return 0;
		}

		private int GetLastVisibleRow(Rectangle virtualRegion)
		{
			if(DataSource!=null && DataSource.Count>0)
			{
				double Dindex = (virtualRegion.Y + virtualRegion.Height) /TableStyle.RowHeight;
				int Iindex= (int)Math.Floor(Dindex);
				int index=(Dindex-Iindex)>0?Iindex-1:Iindex;
				
				return Math.Min(DataSource.Count-1, (int)Math.Ceiling(index));
			}
			return 0;
		}

		private Rectangle GetRelInterRegion(Rectangle subject, Rectangle rectToIntersect)
		{
			Rectangle relInterRect=	 Rectangle.Intersect(subject, rectToIntersect);
			relInterRect.Offset(-subject.X,-subject.Y);
			return relInterRect;

		}

		private int GetVirtualWidth()
		{
			int width=0;

			foreach(ColumnStyle col in TableStyle.ColumnStyles )
			{
				if(col.Visible && col.MappingName!=string.Empty){ width+=col.Width;}
			}
			return width;
		}

		
		private int GetVirtualHeight()
		{
			return   GridVirtualRect.Height;
		}

		private int GetRowsHeight()
		{
			int height=0;

			if(DataSource!=null )
			{
				height=DataSource.Count * TableStyle.RowHeight;
			}
			return height;
		}

		public void Initialize()
		{
			
		}

		
		public void ResetInitialization()
		{
			_VirtualWidth=-1;
			_VirtualHeight=-1;

			if(_SBrush!=null)
			{
				_SBrush.Dispose();
				_SBrush=null;
			}
			if(_Pen!=null)
			{
				_Pen.Dispose();
				_Pen=null;
			}
			_CaptionVirtualRect=Rectangle.Empty;
			_HeaderVirtualRect=Rectangle.Empty;
			_GridVirtualRect=Rectangle.Empty;
		}


		public Rectangle GetPageRectangle(Rectangle clientRectangle)
		{
			Rectangle pageRectangle=Rectangle.Intersect(ClientVirtualRectangle,clientRectangle);
			pageRectangle.Width=GetPageWidth(pageRectangle.Left,pageRectangle.Right)-pageRectangle.Left;
			pageRectangle.Height=GetPageHeight(pageRectangle.Height);
			return pageRectangle;
		}

		private int GetPageWidth(int left,int right)
		{
			
			int pageRight=0;
			for (int i=0;(i<this.TableStyle.ColumnStyles.Count) && (right>=pageRight+TableStyle.ColumnStyles[i].Width);i++)
			{
				if(TableStyle.ColumnStyles[i].Visible)
				{
					pageRight+=TableStyle.ColumnStyles[i].Width;
				}
			}

			return (pageRight<=left )?right:pageRight;
		}


		private int GetPageHeight(int endY)
		{
			int factor=(int)Math.Ceiling(endY/this.TableStyle.RowHeight);
			return factor * this.TableStyle.RowHeight ;
		}


		#endregion
	}
}
