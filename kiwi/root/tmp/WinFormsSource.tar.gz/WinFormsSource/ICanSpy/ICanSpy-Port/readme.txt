ICanSpy - .NET Windows Forms Event Test Driver
----------------------------------------------
Version 1.0
April 2002

Requirements:
Microsoft .NET Framework version 1.0  (v1.0.3705)

Description:
ICanSpy is a .NET Windows Forms application that enables the user to listen to events fired by controls of a particular form.

Steps to spy on events:
1. Run the ICanSpy.exe tool
2. Use "File/Select Form..." to select an assembly file and a form within that assembly
3. Use "File/Select Events..." to select the events you want to listen to
4. Use "File/Logging Options..." to optionally specify a log filename and path
5. Use "File/Start Logging" to start listening to events

How it works:
Once the user selects a form type in an assembly, the tool brings up an instance of this form. Then it uses reflection to provide a list of the events exposed by the form's controls (classified by control or event type). Once the user has selected the events to listen to, the tool uses Reflection.Emit to build a dynamic assembly on the fly that hooks up the events in question.
