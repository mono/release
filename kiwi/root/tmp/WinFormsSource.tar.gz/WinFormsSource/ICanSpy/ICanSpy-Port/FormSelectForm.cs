using System;
using System.IO;
using System.Drawing;
using System.Reflection;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EventTestDriver
{
	public class FormSelectForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cbAssemblies;
		private System.Windows.Forms.ComboBox cbFormTypes;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.OpenFileDialog openFileDialog;

		private System.ComponentModel.Container components = null;

		public FormSelectForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			FillAssembliesCombo();
		}

		public Type SelectedFormType
		{
			get
			{
				if (cbFormTypes.Text.Length > 0)
				{
					return (Type) cbFormTypes.SelectedItem;
				}
				else
				{
					return null;
				}
			}
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormSelectForm));
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.cbAssemblies = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cbFormTypes = new System.Windows.Forms.ComboBox();
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(216, 16);
			this.label1.TabIndex = 0;
			this.label1.Text = "Selecting the Windows Forms form to use.";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 40);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(100, 16);
			this.label2.TabIndex = 1;
			this.label2.Text = "Form &Assembly:";
			// 
			// cbAssemblies
			// 
			this.cbAssemblies.Location = new System.Drawing.Point(8, 56);
			this.cbAssemblies.Name = "cbAssemblies";
			this.cbAssemblies.Size = new System.Drawing.Size(208, 21);
			this.cbAssemblies.TabIndex = 2;
			this.cbAssemblies.TextChanged += new System.EventHandler(this.cbAssemblies_TextChanged);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 16);
			this.label3.TabIndex = 4;
			this.label3.Text = "Form &Type:";
			// 
			// cbFormTypes
			// 
			this.cbFormTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbFormTypes.Location = new System.Drawing.Point(8, 112);
			this.cbFormTypes.Name = "cbFormTypes";
			this.cbFormTypes.Size = new System.Drawing.Size(296, 21);
			this.cbFormTypes.TabIndex = 5;
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Enabled = false;
			this.btnOK.Location = new System.Drawing.Point(144, 160);
			this.btnOK.Name = "btnOK";
			this.btnOK.TabIndex = 6;
			this.btnOK.Text = "OK";
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(232, 160);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 7;
			this.btnCancel.Text = "Cancel";
			// 
			// btnBrowse
			// 
			this.btnBrowse.Location = new System.Drawing.Point(232, 56);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.TabIndex = 3;
			this.btnBrowse.Text = "&Browse...";
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// openFileDialog
			// 
			this.openFileDialog.DefaultExt = "dll";
			this.openFileDialog.Filter = "Assemblies (*.dll; *.exe)|*.dll;*.exe|All files (*.*)|*.*";
			this.openFileDialog.Title = "ICanSpy - Assembly Selection";
			// 
			// FormSelectForm
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(314, 189);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
					this.btnBrowse,
					this.btnCancel,
					this.btnOK,
					this.cbFormTypes,
					this.label3,
					this.cbAssemblies,
					this.label2,
					this.label1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "FormSelectForm";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "ICanSpy - Select Form";
			this.ResumeLayout(false);

		}
#endregion

		protected void FillAssembliesCombo()
		{
			string exePath = Application.ExecutablePath;
			string exeDir, exeFile;

			exeDir = Path.GetDirectoryName (exePath);
			exeFile = Path.GetFileName (exePath);

			string [] fileEntries = Directory.GetFiles(exeDir);
			foreach(string fullFilePath in fileEntries)
			{
				if (fullFilePath != exePath)
				{
					try
					{
						Assembly ass = Assembly.LoadFrom(fullFilePath);
						cbAssemblies.Items.Add (Path.GetDirectoryName (fullFilePath));
					}
					catch
					{
					}
				}
			}
			if (cbAssemblies.Items.Count > 0)
			{
				cbAssemblies.SelectedIndex = 0;
			}
		}

		protected void FillFormTypesCombo()
		{
			if (cbAssemblies.Text.Length > 0)
			{
				try
				{
					Assembly assembly = Assembly.LoadFrom(cbAssemblies.Text);
					Type[] assemblyTypes = assembly.GetTypes();
					foreach (Type assemblyType in assemblyTypes)
					{
						if (assemblyType.IsSubclassOf(typeof(System.Windows.Forms.Form)))
						{
							cbFormTypes.Items.Add(assemblyType);
						}
					}
				}
				catch
				{
				}
				if (cbFormTypes.Items.Count > 0)
				{
					cbFormTypes.SelectedIndex = 0;
				}
			}
			btnOK.Enabled = cbFormTypes.Items.Count > 0;
		}

		private void cbAssemblies_TextChanged(object sender, System.EventArgs e)
		{
			cbFormTypes.Text = String.Empty;
			cbFormTypes.Items.Clear();
			FillFormTypesCombo();
		}

		private void btnBrowse_Click(object sender, System.EventArgs e)
		{
			if (openFileDialog.ShowDialog (this) == DialogResult.OK)
			{
				cbAssemblies.Text = openFileDialog.FileName;
			}
		}
	}
}
