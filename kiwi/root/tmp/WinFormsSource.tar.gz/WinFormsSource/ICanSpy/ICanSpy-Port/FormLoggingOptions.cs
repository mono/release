using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EventTestDriver
{
	public class FormLoggingOptions : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtLogFile;
        private System.Windows.Forms.TextBox txtLogHeader;
		private System.Windows.Forms.RadioButton rbAppend;
		private System.Windows.Forms.RadioButton rbErase;
        private System.Windows.Forms.CheckBox chkLog;
        private System.Windows.Forms.OpenFileDialog ofd;

        private System.ComponentModel.Container components = null;

		public FormLoggingOptions()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}

		public void SetInitialValues(bool log, string logFilename, string logHeader, bool appendLog)
		{
			chkLog.Checked = log;
			txtLogFile.Text = logFilename;
			txtLogHeader.Text = logHeader;
			rbAppend.Checked = appendLog;

			txtLogFile.Enabled = log;
			btnBrowse.Enabled = log;
			txtLogHeader.Enabled = log;
			rbAppend.Enabled = log;
			rbErase.Enabled = log;
		}

		public bool Log
		{
			get
			{
				return chkLog.Checked;
			}
		}

		public string LogFilename
		{
			get
			{
				return txtLogFile.Text;
			}
		}

		public string LogHeader
		{
			get
			{
				return txtLogHeader.Text;
			}
		}

		public bool AppendLog
		{
			get
			{
				return rbAppend.Checked;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormLoggingOptions));
            this.ofd = new System.Windows.Forms.OpenFileDialog();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtLogFile = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.chkLog = new System.Windows.Forms.CheckBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLogHeader = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbErase = new System.Windows.Forms.RadioButton();
            this.rbAppend = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // ofd
            // 
            this.ofd.CheckFileExists = false;
            this.ofd.DefaultExt = "txt";
            this.ofd.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            this.ofd.Title = "ICanSpy - Log File Selection";
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select the log file name and path.";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Log &File:";
            // 
            // txtLogFile
            // 
            this.txtLogFile.Location = new System.Drawing.Point(8, 104);
            this.txtLogFile.Name = "txtLogFile";
            this.txtLogFile.Size = new System.Drawing.Size(280, 20);
            this.txtLogFile.TabIndex = 3;
            this.txtLogFile.Text = "";
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(296, 104);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.TabIndex = 4;
            this.btnBrowse.Text = "&Browse...";
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // chkLog
            // 
            this.chkLog.Location = new System.Drawing.Point(8, 8);
            this.chkLog.Name = "chkLog";
            this.chkLog.Size = new System.Drawing.Size(360, 24);
            this.chkLog.TabIndex = 0;
            this.chkLog.Text = "&Log the fired events in a text file?";
            this.chkLog.CheckedChanged += new System.EventHandler(this.chkLog_CheckedChanged);
            // 
            // btnOK
            // 
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(216, 304);
            this.btnOK.Name = "btnOK";
            this.btnOK.TabIndex = 10;
            this.btnOK.Text = "OK";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(296, 304);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Cancel";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(8, 136);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(280, 16);
            this.label3.TabIndex = 5;
            this.label3.Text = "&Text to add at the beginning of the log file:";
            // 
            // txtLogHeader
            // 
            this.txtLogHeader.Location = new System.Drawing.Point(8, 152);
            this.txtLogHeader.Multiline = true;
            this.txtLogHeader.Name = "txtLogHeader";
            this.txtLogHeader.Size = new System.Drawing.Size(360, 72);
            this.txtLogHeader.TabIndex = 6;
            this.txtLogHeader.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                    this.rbErase,
                                                                                    this.rbAppend});
            this.groupBox1.Location = new System.Drawing.Point(8, 240);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 48);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "In case the log file already exists";
            // 
            // rbErase
            // 
            this.rbErase.Location = new System.Drawing.Point(208, 16);
            this.rbErase.Name = "rbErase";
            this.rbErase.Size = new System.Drawing.Size(128, 24);
            this.rbErase.TabIndex = 9;
            this.rbErase.Text = "&Erase existing file";
            // 
            // rbAppend
            // 
            this.rbAppend.Checked = true;
            this.rbAppend.Location = new System.Drawing.Point(8, 16);
            this.rbAppend.Name = "rbAppend";
            this.rbAppend.Size = new System.Drawing.Size(152, 24);
            this.rbAppend.TabIndex = 8;
            this.rbAppend.TabStop = true;
            this.rbAppend.Text = "&Append to existing file";
            // 
            // FormLoggingOptions
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(376, 334);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.groupBox1,
                                                                          this.txtLogHeader,
                                                                          this.label3,
                                                                          this.btnCancel,
                                                                          this.btnOK,
                                                                          this.chkLog,
                                                                          this.btnBrowse,
                                                                          this.txtLogFile,
                                                                          this.label2,
                                                                          this.label1});
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormLoggingOptions";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ICanSpy - Logging Options";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

		private void chkLog_CheckedChanged(object sender, System.EventArgs e)
		{
			bool bLog = chkLog.Checked;

			txtLogFile.Enabled = bLog;
			btnBrowse.Enabled = bLog;
			txtLogHeader.Enabled = bLog;
			rbAppend.Enabled = bLog;
			rbErase.Enabled = bLog;
		}

		private void btnBrowse_Click(object sender, System.EventArgs e)
		{
			ofd.FileName = txtLogFile.Text;
			if (ofd.ShowDialog(this) == DialogResult.OK)
			{
				txtLogFile.Text = ofd.FileName;
			}
		}
	}
}
