using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace EventTestDriver
{
    public class FormSelectEvents : System.Windows.Forms.Form
    {
		private int countAfterCheck = 0;
		private int levelAfterCheck;

		private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TreeView tvEvents;
        private System.Windows.Forms.RadioButton rbOrderByEvent;
        private System.Windows.Forms.RadioButton rbOrderByControl;

        private System.ComponentModel.Container components = null;

        public FormSelectEvents()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
        }

        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

		#region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(FormSelectEvents));
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbOrderByEvent = new System.Windows.Forms.RadioButton();
            this.rbOrderByControl = new System.Windows.Forms.RadioButton();
            this.tvEvents = new System.Windows.Forms.TreeView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(240, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Select the events to listen to.";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                                    this.rbOrderByEvent,
                                                                                    this.rbOrderByControl});
            this.groupBox1.Location = new System.Drawing.Point(8, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(168, 72);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Event View";
            // 
            // rbOrderByEvent
            // 
            this.rbOrderByEvent.Location = new System.Drawing.Point(16, 48);
            this.rbOrderByEvent.Name = "rbOrderByEvent";
            this.rbOrderByEvent.Size = new System.Drawing.Size(144, 16);
            this.rbOrderByEvent.TabIndex = 3;
            this.rbOrderByEvent.Text = "Classified by &event type";
            this.rbOrderByEvent.CheckedChanged += new System.EventHandler(this.rbOrderByEvent_CheckedChanged);
            // 
            // rbOrderByControl
            // 
            this.rbOrderByControl.Checked = true;
            this.rbOrderByControl.Location = new System.Drawing.Point(16, 24);
            this.rbOrderByControl.Name = "rbOrderByControl";
            this.rbOrderByControl.Size = new System.Drawing.Size(136, 16);
            this.rbOrderByControl.TabIndex = 2;
            this.rbOrderByControl.TabStop = true;
            this.rbOrderByControl.Text = "Classified by &control";
            // 
            // tvEvents
            // 
            this.tvEvents.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
                | System.Windows.Forms.AnchorStyles.Left) 
                | System.Windows.Forms.AnchorStyles.Right);
            this.tvEvents.CheckBoxes = true;
            this.tvEvents.HideSelection = false;
            this.tvEvents.ImageIndex = -1;
            this.tvEvents.Location = new System.Drawing.Point(8, 136);
            this.tvEvents.Name = "tvEvents";
            this.tvEvents.SelectedImageIndex = -1;
            this.tvEvents.Size = new System.Drawing.Size(328, 240);
            this.tvEvents.Sorted = true;
            this.tvEvents.TabIndex = 5;
            this.tvEvents.AfterCheck += new System.Windows.Forms.TreeViewEventHandler(this.tvEvents_AfterCheck);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "E&vents:";
            // 
            // btnOK
            // 
            this.btnOK.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
            this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnOK.Location = new System.Drawing.Point(264, 8);
            this.btnOK.Name = "btnOK";
            this.btnOK.TabIndex = 6;
            this.btnOK.Text = "OK";
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(264, 40);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            // 
            // FormSelectEvents
            // 
            this.AcceptButton = this.btnOK;
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(344, 381);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.btnCancel,
                                                                          this.btnOK,
                                                                          this.label2,
                                                                          this.tvEvents,
                                                                          this.groupBox1,
                                                                          this.label1});
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(272, 200);
            this.Name = "FormSelectEvents";
            this.ShowInTaskbar = false;
            this.Text = "ICanSpy - Select Events";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
		#endregion

        public void FillEventsTreeView(bool orderByControl, TreeView tvEvents)
        {
            this.tvEvents.Nodes.Clear ();
            if (orderByControl)
            {
                foreach (ControlTreeNode ctn in tvEvents.Nodes)
                {
                    this.tvEvents.Nodes.Add((TreeNode) ctn.Clone());
                }
            }
            else
            {
                rbOrderByEvent.Checked = true;
                foreach (EventCategoryTreeNode ectn in tvEvents.Nodes)
                {
                    this.tvEvents.Nodes.Add((TreeNode) ectn.Clone());
                }
            }
        }

        public void ReadEventsTreeView(out bool orderByControl, TreeView tvEvents)
        {
            orderByControl = rbOrderByControl.Checked;
            tvEvents.Nodes.Clear ();
            if (orderByControl)
            {
                foreach (ControlTreeNode ctn in this.tvEvents.Nodes)
                {
                    tvEvents.Nodes.Add((TreeNode) ctn.Clone());
                }
            }
            else
            {
                foreach (EventCategoryTreeNode ectn in this.tvEvents.Nodes)
                {
                    tvEvents.Nodes.Add((TreeNode) ectn.Clone());
                }
            }
        }

		private void rbOrderByEvent_CheckedChanged(object sender, System.EventArgs e)
		{
			if (rbOrderByEvent.Checked)
			{
				Utils.OrderEventsTreeViewByEvent(tvEvents);
			}
			else
			{
				Utils.OrderEventsTreeViewByControl(tvEvents);
			}
		}

		private void tvEvents_AfterCheck(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			int tempLevelAfterCheck = 0;
			TreeNode tnTmp = e.Node;
			while (tnTmp.Parent != null)
			{
				tnTmp = tnTmp.Parent;
				tempLevelAfterCheck++;
			}

			if (countAfterCheck == 0)
			{
				levelAfterCheck = tempLevelAfterCheck;
			}

			countAfterCheck++;
			bool nodeChecked = e.Node.Checked;

			if (e.Node.Nodes.Count > 0)
			{
				if (nodeChecked)
				{
					foreach (TreeNode tn in e.Node.Nodes)
					{
						if (!tn.Checked)
						{
							tn.Checked = true;
						}
					}
				}
				else
				{
					if (tempLevelAfterCheck >= levelAfterCheck)
					{
						foreach (TreeNode tn in e.Node.Nodes)
						{
							if (tn.Checked)
							{
								tn.Checked = false;
							}
						}
					}
				}
			}
			if (e.Node.Parent != null)
			{
				if (nodeChecked)
				{
					if (e.Node.Parent.Checked == false)
					{
						bool allChildrenChecked = true;
						foreach (TreeNode tn in e.Node.Parent.Nodes)
						{
							if (tn.Checked == false)
							{
								allChildrenChecked = false;
								break;
							}
						}
						if (allChildrenChecked)
						{
							e.Node.Parent.Checked = true;
						}
					}
				}
				else
				{
					if (e.Node.Parent.Checked)
					{
						e.Node.Parent.Checked = false;
					}
				}
			}
			countAfterCheck--;
		}
	}
}
