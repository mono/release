// 05.06.07.19 completed comment work
#define USE_REGISTRY  // use registry for app data persistance, else use local Xml file

using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;              // IOExceptions
using System.Reflection;      // for Assembly
using System.Configuration;   // for AppSettingsReader
using System.Runtime.InteropServices;

namespace AlbumSurfer
{
	///<summary>Root form for the Album Surfer Application.</summary>
	///<remarks>This is the main form which permits selection of options as well as a view port for the images.</remarks>
	public class MainForm : System.Windows.Forms.Form
	{
		///<summary>A object reference to our one and only main form.</summary>
		///<remarks>A reference to the instantiated object is placed here.</remarks>
		static public MainForm          frmMain;
#if USE_REGISTRY
			///<summary>An object reference to the instantiated registry persistent storage class.</summary>
			///<remarks>By choosing "USE_REGISTRY" the registry flavor of persistent storage is instantiated.</remarks>
			static public RegistryClass     g_reg;
#else
			static public RegXmlClass       g_reg;
#endif
			///<summary>Global string variable for the select path file (persisted).</summary>
			///<remarks>The path and filename of the last/first view file of a directory.</remarks>
			static public string            g_strSelectedPathFile;
			///<summary>Global string variable for the select path file (persisted).</summary>
			///<remarks>This is the time interval in milliseconds for the slide show display.</remarks>
			static public Int32             g_s32TimerInterval = 500;
			
			///<summary>String variable keep in persistent storage as to the placement and size of the main form.</summary>
			///<remarks>This string is the "Top,Left,Width,Height" of the main form.</remarks>
			private static string           ms_strWinPlacement;
			///<summary>String variable which is the path and name of the help file.</summary>
			///<remarks>This string is created by concatenating the help file name "AlbumSurfer.chm" to the application path.</remarks>
			public static string            ms_strHelpPathFile;
			///<summary>Long parameter value used when saving jpegs.</summary>
			///<remarks>When saving jpegs this value is used to determine the compression quality factor.</remarks>
			public static Int32             ms_s32JpegSaveQuality = 75;
			
			///<summary>Delegate used in asynchronous call (see Form1_DragDrop).</summary>
			///<remarks>Delegate type definition used to asynchronously process the dropped file.</remarks>
			private delegate void DelegateDragDropOpen( string strPathFile );
			///<summary>Delegate linkage for file Drag and Drop operations.</summary>
			///<remarks>Object instantiation of a delegate to allow an immediate return from the Drag and Drop event.</remarks>
			private DelegateDragDropOpen m_DelegateDragDropOpen;
			
			//  ///<summary>Boolean object.</summary>
			//  ///<remarks>This object provides a mechanism for ignore layout changes during init.</remarks>
			//private bool        m_ynSuspendLayout = true;  // our private version of SuspendLayout
			///<summary>ArrayList collection for the storage of all the files in the directory that have image extensions.</summary>
			///<remarks>This is a list of path filenames sorted in the order of their root filename( no extension ).</remarks>
			private ArrayList               m_alstFiles;
			///<summary>ArrayList collection for the storage of all known image extensions we can handle.</summary>
			///<remarks>This is a list of image extensions. If the file is one of these we can display it.</remarks>
			private ArrayList               m_alstImageExts;
			///<summary>Storage variable for the index in the m_alstFiles of the presently displayed file.</summary>
			///<remarks>If this value is -1 nothing is being displayed.</remarks>
			private int                     m_s32FileIXShowing    = -1;    // nothing is showing
		///<summary>Storage variable for the index in the m_alstFiles of the next request file to be displayed.</summary>
		///<remarks>If this value is -1 nothing is being requested.</remarks>
		private int                     m_s32FileIXNext       = -1;    // and nothing is asked for
		///<summary>The "Fit to Window" and "Actual Size" items interact with each other. This boolean is essentially a lock
		///when one is being modified not to modify the other except as needed.</summary>
		///<remarks>Essanetially this boolean is acting like a data mutex.</remarks>
		private bool                    m_ynBusy              = false;  //lock mechanism
		///<summary>Storage variable for off screen bitmaps.</summary>
		///<remarks>Used when selected data need to be stored off screen.</remarks>
		public System.Drawing.Bitmap    m_bmap                = null;
			///<summary>Storage variable for displayed bitmap magnification factor.</summary>
			///<remarks>Floating point value used to scale the bitmap for display.</remarks>
			private float                   m_sfpScale            = 1.00F;
			///<summary>Variable that indicates when what is being displayed has been scaled to fit.</summary>
			///<remarks>.</remarks>
			private bool                    m_ynSizeToFit         = true;
			///<summary>Variable that indicates the left mouse button is being depressed.</summary>
			///<remarks>This variable helps us figure out when we are in the area select process.</remarks>
			private bool                    m_ynPicMouseDown      = false;
			///<summary>Variable that stores the point of origin of the select process.</summary>
			///<remarks>This variable stores the point on the screen where the user started the selection process.</remarks>
			private Point                   m_ptStart             = new Point(0,0);
			///<summary>Variable that stores the screen coordinate X,Y for start point of selection.</summary>
			///<remarks>This value is used as the start info in the rectReversable rectangle.</remarks>
			private Point                   m_ptScreen            = new Point(0,0);
			///<summary>Variable that stores the Width of the selection rectangle.</summary>
			///<remarks>.</remarks>
			private Int32                   m_s32SelectW;
			///<summary>Variable that stores the Height of the selection rectangle.</summary>
			///<remarks>.</remarks>
			private Int32                   m_s32SelectH;
			///<summary>The rectangle object used to call the selection draw routines.</summary>
			///<remarks>This object has its X,Y and W,H appropriately initialized for calling the appear/disappear routines.</remarks>
			private Rectangle               m_rectReversable  = new Rectangle(0,0,1,1);
			
			///<summary>The main menu object.</summary>
			///<remarks>This is the container object for menu item objects of the form.</remarks>
			private System.Windows.Forms.MainMenu mnuMain;
			///<summary>The "File" menu column header.</summary>
			///<remarks>This is the parent menu item that owns all the items in the "File" column.</remarks>
			private System.Windows.Forms.MenuItem mnuFile;
			///<summary>The "File" menu "Open File" item.</summary>
			///<remarks>Clicking this menu item causes the Open File dialog to appear.</remarks>
			private System.Windows.Forms.MenuItem mnuFileOpenFile;
			///<summary>The "File" menu "Images Show" item.</summary>
			///<remarks>Clicking this menu item causes the automatic slide show feature to get toggled on and off.</remarks>
			private System.Windows.Forms.MenuItem mnuFileImagesShow;
			///<summary>The "File" menu separator #0.</summary>
			///<remarks>This provides a way of separating unlike operations in a menu list.</remarks>
			private System.Windows.Forms.MenuItem mnuFileSep0;
			///<summary>The "File" menu "Exit" item.</summary>
			///<remarks>Clicking this menu item causes the application to exit.</remarks>
			private System.Windows.Forms.MenuItem mnuFileExit;
			///<summary>The "Edit" menu column header.</summary>
			///<remarks>This is the parent menu item that owns all the items in the "Edit" column.</remarks>
			private System.Windows.Forms.MenuItem mnuEdit;
			///<summary>The "Edit" menu "Cut" item.</summary>
			///<remarks>Provides standard edit functionality(Inactive).</remarks>
			private System.Windows.Forms.MenuItem mnuEditCut;
			///<summary>The "Edit" menu "Copy" item.</summary>
			///<remarks>Provides standard edit functionality(Inactive).</remarks>
			private System.Windows.Forms.MenuItem mnuEditCopy;
			///<summary>The "Edit" menu "Paste" item.</summary>
			///<remarks>Provides standard edit functionality(Inactive).</remarks>
			private System.Windows.Forms.MenuItem mnuEditPaste;
			///<summary>The "View" menu column header.</summary>
			///<remarks>Provides a header for the View menu item collection.</remarks>
			private System.Windows.Forms.MenuItem mnuView;
			///<summary>The "View" menu "Previous Image" item.</summary>
			///<remarks>Clicking this menu item causes the previous image in the view list to be displayed.</remarks>
			private System.Windows.Forms.MenuItem mnuViewPreviousImage;
			///<summary>The "View" menu "Next Image" item.</summary>
			///<remarks>Clicking this menu item causes the next image in the view list to be displayed.</remarks>
			private System.Windows.Forms.MenuItem mnuViewNextImage;
			///<summary>The "View" menu separator #0.</summary>
			///<remarks>This provides a way of separating unlike operations in a menu list.</remarks>
			private System.Windows.Forms.MenuItem mnuViewSep0;
			///<summary>The "View" menu "Fit To Window" item.</summary>
			///<remarks>Clicking this menu item causes the image to be sized to completely fit in the displayed window.</remarks>
			private System.Windows.Forms.MenuItem mnuViewFitToWindow;
			///<summary>The "View" menu "Zoom In" item.</summary>
			///<remarks>Clicking this menu item causes the image to be increased in size by 25%.</remarks>
			private System.Windows.Forms.MenuItem mnuViewZoomIn;
			///<summary>The "View" menu "Zoom Out" item.</summary>
			///<remarks>Clicking this menu item causes the image to be decreased in size by 25%.</remarks>
			private System.Windows.Forms.MenuItem mnuViewZoomOut;
			///<summary>The "View" menu "Actual Size" item.</summary>
			///<remarks>Clicking this menu item causes the image to be sized to its natural pixel resolution.</remarks>
			private System.Windows.Forms.MenuItem mnuViewActualSize;
			///<summary>The "View" menu "Full Screen" item.</summary>
			///<remarks>Clicking this menu item causes the main form to loose it borders and display the image full screen.</remarks>
			private System.Windows.Forms.MenuItem mnuViewFullScreen;
			///<summary>The "View" menu separator #1.</summary>
			///<remarks>This provides a way of separating unlike operations in a menu list.</remarks>
			private System.Windows.Forms.MenuItem mnuViewSep1;
			///<summary>The "View" menu "Properties" item.</summary>
			///<remarks>Clicking this menu item causes the image properties form to appear.</remarks>
			private System.Windows.Forms.MenuItem mnuViewProperties;
			///<summary>The "View" menu separator #2.</summary>
			///<remarks>This provides a way of separating unlike operations in a menu list.</remarks>
			private System.Windows.Forms.MenuItem mnuViewSep2;
			///<summary>The "Tools" menu column header.</summary>
			///<remarks>This is the parent menu item that owns all the items in the "Tools" column.</remarks>
			private System.Windows.Forms.MenuItem mnuTools;
			///<summary>The "Tools" menu "Options" item.</summary>
			///<remarks>Clicking this menu item causes the "Options" dialog to appear.</remarks>
			private System.Windows.Forms.MenuItem mnuToolsOptions;
			///<summary>The "Help" menu column header.</summary>
			///<remarks>This is the parent menu item that owns all the items in the "Help" column.</remarks>
			private System.Windows.Forms.MenuItem mnuHelp;
			///<summary>The "Help" menu "About" item.</summary>
			///<remarks>Clicking this menu item causes the "About" dialog to appear.</remarks>
			private System.Windows.Forms.MenuItem mnuHelpAbout;
			///<summary>The "Help" menu "Help" item.</summary>
			///<remarks>Clicking this menu item causes the compiled Help file to appear.</remarks>
			private System.Windows.Forms.MenuItem mnuHelpHelp;
			
			///<summary>Screen context menu column header.</summary>
			///<remarks>Right clicking screen picture area causes this menu to appear.</remarks>
			private System.Windows.Forms.ContextMenu cmnuPic1;
			///<summary>The Picture context menu "Previous" item.</summary>
			///<remarks>Selecting this menu item causes the previous image to be displayed.</remarks>
			private System.Windows.Forms.MenuItem cmnuPic1Previous;
			///<summary>The Picture context menu "Next" item.</summary>
			///<remarks>Selecting this menu item causes the next image to be displayed.</remarks>
			private System.Windows.Forms.MenuItem cmnuPic1Next;
			///<summary>The separator #0 in the picture context menu.</summary>
			///<remarks>This provides a way of separating unlike operations in a menu list.</remarks>
			private System.Windows.Forms.MenuItem cmnuPic1Sep0;
			///<summary>The Picture context menu "Save" item.</summary>
			///<remarks>Selecting this menu item cause Save File dialog to appear. 
			///This is only enabled if there is a selected area so its enabled status can be used to determine active selection.</remarks>
			private System.Windows.Forms.MenuItem cmnuPic1Save;
			///<summary>The Picture context menu "Properties" item.</summary>
			///<remarks>Clicking this menu item causes the image properties form to appear..</remarks>
			private System.Windows.Forms.MenuItem cmnuPic1Properties;
			///<summary>File Open dialog used to obtain the location of a new file (directory) to be displayed.</summary>
			///<remarks>When the user selects the File->Open menu option this dialog is invoked.</remarks>
			private System.Windows.Forms.OpenFileDialog m_dlgFileOpen;
			///<summary>File Save dialog used to save the selected image area.</summary>
			///<remarks>When the user selects the "Save" option from the display context menu this dialog is invoked.</remarks>
			private System.Windows.Forms.SaveFileDialog m_dlgFileSave;
			///<summary>The form timer used for automatic sequential image display.</summary>
			///<remarks>This interval on this time determines the delay between the display of each image.</remarks>
			private System.Windows.Forms.Timer m_tmr1;
			
			///<summary>The form status bar container object that contains the status panels.</summary>
			///<remarks>Status panels provide feedback to the user about the image object properties.</remarks>
			private System.Windows.Forms.StatusBar m_sbr1;
			///<summary>The form status bar panel for general user information.</summary>
			///<remarks>Status bar panel where the user is given feedback on general operation success and failures.</remarks>
			private System.Windows.Forms.StatusBarPanel m_spanInfo;
			///<summary>The form status bar panel for cursor X,Y inside the picture area.</summary>
			///<remarks>Status bar panel in which we show the X,Y of the cursor in the picture image.</remarks>
			private System.Windows.Forms.StatusBarPanel m_spanPicXY;
			///<summary>Status bar panel to show the natural image width and height.</summary>
			///<remarks>In this panel we show the user natural width and height of the source bitmap.</remarks>
			private System.Windows.Forms.StatusBarPanel m_spanBmapWH;
			///<summary>Status bar panel to show the user which image of the collection is being display.</summary>
			///<remarks>In this panel the user is given ID of the presently display image and how many are in the collection.</remarks>
			private System.Windows.Forms.StatusBarPanel m_spanIdOfTot;
			///<summary>Status bar panel which show the user the natural format of the source image.</summary>
			///<remarks>In this panel the user is given the type of image the source is.</remarks>
			private System.Windows.Forms.StatusBarPanel m_spanFormat;
			
			///<summary>The form panel container object that contains the bitmap picture box.</summary>
			///<remarks>This picture box is appropriated placed in this panel depending on it scale.</remarks>
			private System.Windows.Forms.Panel m_panPic;
			///<summary>The form picture box that the bitmap gets rendered in.</summary>
			///<remarks>This object is a child of the picture panel and renders the bitmap to the appropriate scale.</remarks>
			private System.Windows.Forms.PictureBox m_pic1;
			
			///<summary>Status bar panel to show the user the percentage of scaling of the image being displayed.</summary>
			///<remarks>In this panel the user is given the displayed scaling factor.</remarks>
			private System.Windows.Forms.StatusBarPanel m_spanPercentage;
			
			///<summary>Required designer variable.</summary>
			///<remarks>This container object is where the forms wizard places all the objects that belong to the form.</remarks>
			private System.ComponentModel.IContainer components;

			// ------------------------ M a i n F o r m -------------------------
			//
			///<summary>The constructor for the class</summary>
			///<remarks>Instantiate and initialize all objects owned by the form and
			///initalize other variables as needed</remarks>
			//
			// ------------------------------------------------------------------
			public MainForm()
			{
				InitializeComponent();
					
					m_panPic.MouseWheel += new MouseEventHandler( m_panPic_MouseWheel );
					m_pic1.MouseWheel   += new MouseEventHandler( m_panPic_MouseWheel );
			}
		
			///<summary>Destructor for class, clean up any resources being used.</summary>
			///<remarks>Thus is where the class resources are freed.</remarks>
			protected override void Dispose( bool disposing )
			{
				if( disposing )
				{
					if (components != null) 
					{
						components.Dispose();
					}
				}
				base.Dispose( disposing );
			}
		
#region Windows Form Designer generated code
			///<summary>Required method for Designer support - do not modify
			/// the contents of this method with the code editor.</summary>
			private void InitializeComponent()
			{
				this.components = new System.ComponentModel.Container();
					System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
					this.mnuMain = new System.Windows.Forms.MainMenu();
					this.mnuFile = new System.Windows.Forms.MenuItem();
					this.mnuFileOpenFile = new System.Windows.Forms.MenuItem();
					this.mnuFileImagesShow = new System.Windows.Forms.MenuItem();
					this.mnuFileSep0 = new System.Windows.Forms.MenuItem();
					this.mnuFileExit = new System.Windows.Forms.MenuItem();
					this.mnuEdit = new System.Windows.Forms.MenuItem();
					this.mnuEditCut = new System.Windows.Forms.MenuItem();
					this.mnuEditCopy = new System.Windows.Forms.MenuItem();
					this.mnuEditPaste = new System.Windows.Forms.MenuItem();
					this.mnuView = new System.Windows.Forms.MenuItem();
					this.mnuViewPreviousImage = new System.Windows.Forms.MenuItem();
					this.mnuViewNextImage = new System.Windows.Forms.MenuItem();
					this.mnuViewSep0 = new System.Windows.Forms.MenuItem();
					this.mnuViewFitToWindow = new System.Windows.Forms.MenuItem();
					this.mnuViewZoomIn = new System.Windows.Forms.MenuItem();
					this.mnuViewZoomOut = new System.Windows.Forms.MenuItem();
					this.mnuViewActualSize = new System.Windows.Forms.MenuItem();
					this.mnuViewSep1 = new System.Windows.Forms.MenuItem();
					this.mnuViewFullScreen = new System.Windows.Forms.MenuItem();
					this.mnuViewSep2 = new System.Windows.Forms.MenuItem();
					this.mnuViewProperties = new System.Windows.Forms.MenuItem();
					this.mnuTools = new System.Windows.Forms.MenuItem();
					this.mnuToolsOptions = new System.Windows.Forms.MenuItem();
					this.mnuHelp = new System.Windows.Forms.MenuItem();
					this.mnuHelpHelp = new System.Windows.Forms.MenuItem();
					this.mnuHelpAbout = new System.Windows.Forms.MenuItem();
					this.m_sbr1 = new System.Windows.Forms.StatusBar();
					this.m_spanInfo = new System.Windows.Forms.StatusBarPanel();
					this.m_spanPicXY = new System.Windows.Forms.StatusBarPanel();
					this.m_spanBmapWH = new System.Windows.Forms.StatusBarPanel();
					this.m_spanIdOfTot = new System.Windows.Forms.StatusBarPanel();
					this.m_spanFormat = new System.Windows.Forms.StatusBarPanel();
					this.m_spanPercentage = new System.Windows.Forms.StatusBarPanel();
					this.m_dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
					this.m_panPic = new System.Windows.Forms.Panel();
					this.m_pic1 = new System.Windows.Forms.PictureBox();
					this.cmnuPic1 = new System.Windows.Forms.ContextMenu();
					this.cmnuPic1Previous = new System.Windows.Forms.MenuItem();
					this.cmnuPic1Next = new System.Windows.Forms.MenuItem();
					this.cmnuPic1Sep0 = new System.Windows.Forms.MenuItem();
					this.cmnuPic1Save = new System.Windows.Forms.MenuItem();
					this.cmnuPic1Properties = new System.Windows.Forms.MenuItem();
					this.m_dlgFileSave = new System.Windows.Forms.SaveFileDialog();
					this.m_tmr1 = new System.Windows.Forms.Timer(this.components);
					((System.ComponentModel.ISupportInitialize)(this.m_spanInfo)).BeginInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanPicXY)).BeginInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanBmapWH)).BeginInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanIdOfTot)).BeginInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanFormat)).BeginInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanPercentage)).BeginInit();
					this.m_panPic.SuspendLayout();
					this.SuspendLayout();
					// 
					// mnuMain
					// 
					this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.mnuFile,
							this.mnuEdit,
							this.mnuView,
							this.mnuTools,
							this.mnuHelp});
					// 
					// mnuFile
					// 
					this.mnuFile.Index = 0;
					this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.mnuFileOpenFile,
							this.mnuFileImagesShow,
							this.mnuFileSep0,
							this.mnuFileExit});
					this.mnuFile.Text = "&File";
					// 
					// mnuFileOpenFile
					// 
					this.mnuFileOpenFile.Index = 0;
					this.mnuFileOpenFile.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
					this.mnuFileOpenFile.Text = "&Open File";
					this.mnuFileOpenFile.Click += new System.EventHandler(this.mnuFileOpenFile_Click);
					// 
					// mnuFileImagesShow
					// 
					this.mnuFileImagesShow.Index = 1;
					this.mnuFileImagesShow.Shortcut = System.Windows.Forms.Shortcut.CtrlI;
					this.mnuFileImagesShow.Text = "&Image Show";
					this.mnuFileImagesShow.Click += new System.EventHandler(this.mnuFileImagesShow_Click);
					// 
					// mnuFileSep0
					// 
					this.mnuFileSep0.Index = 2;
					this.mnuFileSep0.Text = "-";
					// 
					// mnuFileExit
					// 
					this.mnuFileExit.Index = 3;
					this.mnuFileExit.Text = "E&xit";
					this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
					// 
					// mnuEdit
					// 
					this.mnuEdit.Index = 1;
					this.mnuEdit.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.mnuEditCut,
							this.mnuEditCopy,
							this.mnuEditPaste});
					this.mnuEdit.Text = "&Edit";
					// 
					// mnuEditCut
					// 
					this.mnuEditCut.Enabled = false;
					this.mnuEditCut.Index = 0;
					this.mnuEditCut.Text = "Cu&t";
					// 
					// mnuEditCopy
					// 
					this.mnuEditCopy.Enabled = false;
					this.mnuEditCopy.Index = 1;
					this.mnuEditCopy.Text = "&Copy";
					// 
					// mnuEditPaste
					// 
					this.mnuEditPaste.Enabled = false;
					this.mnuEditPaste.Index = 2;
					this.mnuEditPaste.Text = "&Paste";
					// 
					// mnuView
					// 
					this.mnuView.Index = 2;
					this.mnuView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.mnuViewPreviousImage,
							this.mnuViewNextImage,
							this.mnuViewSep0,
							this.mnuViewFitToWindow,
							this.mnuViewZoomIn,
							this.mnuViewZoomOut,
							this.mnuViewActualSize,
							this.mnuViewSep1,
							this.mnuViewFullScreen,
							this.mnuViewSep2,
							this.mnuViewProperties});
					this.mnuView.Text = "&View";
					// 
					// mnuViewPreviousImage
					// 
					this.mnuViewPreviousImage.Index = 0;
					this.mnuViewPreviousImage.Shortcut = System.Windows.Forms.Shortcut.F11;
					this.mnuViewPreviousImage.Text = "Previous Image";
					this.mnuViewPreviousImage.Click += new System.EventHandler(this.mnuViewPreviousImage_Click);
					// 
					// mnuViewNextImage
					// 
					this.mnuViewNextImage.Index = 1;
					this.mnuViewNextImage.Shortcut = System.Windows.Forms.Shortcut.F12;
					this.mnuViewNextImage.Text = "Next Image";
					this.mnuViewNextImage.Click += new System.EventHandler(this.mnuViewNextImage_Click);
					// 
					// mnuViewSep0
					// 
					this.mnuViewSep0.Index = 2;
					this.mnuViewSep0.Text = "-";
					// 
					// mnuViewFitToWindow
					// 
					this.mnuViewFitToWindow.Index = 3;
					this.mnuViewFitToWindow.Text = "Fit to Window";
					this.mnuViewFitToWindow.Click += new System.EventHandler(this.mnuViewFitToWindow_Click);
					// 
					// mnuViewZoomIn
					// 
					this.mnuViewZoomIn.Index = 4;
					this.mnuViewZoomIn.Text = "Zoom In";
					this.mnuViewZoomIn.Click += new System.EventHandler(this.mnuViewZoomIn_Click);
					// 
					// mnuViewZoomOut
					// 
					this.mnuViewZoomOut.Index = 5;
					this.mnuViewZoomOut.Text = "Zoom Out";
					this.mnuViewZoomOut.Click += new System.EventHandler(this.mnuViewZoomOut_Click);
					// 
					// mnuViewActualSize
					// 
					this.mnuViewActualSize.Index = 6;
					this.mnuViewActualSize.Text = "100%";
					this.mnuViewActualSize.Click += new System.EventHandler(this.mnuViewActualSize_Click);
					// 
					// mnuViewSep1
					// 
					this.mnuViewSep1.Index = 7;
					this.mnuViewSep1.Text = "-";
					// 
					// mnuViewFullScreen
					// 
					this.mnuViewFullScreen.Index = 8;
					this.mnuViewFullScreen.Shortcut = System.Windows.Forms.Shortcut.F2;
					this.mnuViewFullScreen.Text = "Full Screen";
					this.mnuViewFullScreen.Click += new System.EventHandler(this.mnuViewFullScreen_Click);
					// 
					// mnuViewSep2
					// 
					this.mnuViewSep2.Index = 9;
					this.mnuViewSep2.Text = "-";
					// 
					// mnuViewProperties
					// 
					this.mnuViewProperties.Index = 10;
					this.mnuViewProperties.Text = "Properties";
					this.mnuViewProperties.Click += new System.EventHandler(this.mnuVireProperties_Click);
					// 
					// mnuTools
					// 
					this.mnuTools.Index = 3;
					this.mnuTools.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.mnuToolsOptions});
					this.mnuTools.Text = "&Tools";
					// 
					// mnuToolsOptions
					// 
					this.mnuToolsOptions.Index = 0;
					this.mnuToolsOptions.Text = "&Options";
					this.mnuToolsOptions.Click += new System.EventHandler(this.mnuToolsOptions_Click);
					// 
					// mnuHelp
					// 
					this.mnuHelp.Index = 4;
					this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.mnuHelpHelp,
							this.mnuHelpAbout});
					this.mnuHelp.Text = "&Help";
					// 
					// mnuHelpHelp
					// 
					this.mnuHelpHelp.Index = 0;
					this.mnuHelpHelp.Text = "Help";
					this.mnuHelpHelp.Click += new System.EventHandler(this.mnuHelpHelp_Click);
					// 
					// mnuHelpAbout
					// 
					this.mnuHelpAbout.Index = 1;
					this.mnuHelpAbout.Text = "&About";
					this.mnuHelpAbout.Click += new System.EventHandler(this.mnuHelpAbout_Click);
					// 
					// m_sbr1
					// 
					this.m_sbr1.Location = new System.Drawing.Point(0, 131);
					this.m_sbr1.Name = "m_sbr1";
					this.m_sbr1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
							this.m_spanInfo,
							this.m_spanPicXY,
							this.m_spanBmapWH,
							this.m_spanIdOfTot,
							this.m_spanFormat,
							this.m_spanPercentage});
					this.m_sbr1.ShowPanels = true;
					this.m_sbr1.Size = new System.Drawing.Size(320, 22);
					this.m_sbr1.TabIndex = 6;
					this.m_sbr1.Text = "m_sbr1";
					// 
					// m_spanInfo
					// 
					this.m_spanInfo.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
					this.m_spanInfo.Width = 254;
					// 
					// m_spanPicXY
					// 
					this.m_spanPicXY.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
					this.m_spanPicXY.Width = 10;
					// 
					// m_spanBmapWH
					// 
					this.m_spanBmapWH.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
					this.m_spanBmapWH.Width = 10;
					// 
					// m_spanIdOfTot
					// 
					this.m_spanIdOfTot.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
					this.m_spanIdOfTot.Width = 10;
					// 
					// m_spanFormat
					// 
					this.m_spanFormat.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
					this.m_spanFormat.Width = 10;
					// 
					// m_spanPercentage
					// 
					this.m_spanPercentage.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
					this.m_spanPercentage.Width = 10;
					// 
					// m_panPic
					// 
					this.m_panPic.AllowDrop = true;
					this.m_panPic.Controls.Add(this.m_pic1);
					this.m_panPic.Dock = System.Windows.Forms.DockStyle.Fill;
					this.m_panPic.Location = new System.Drawing.Point(0, 0);
					this.m_panPic.Name = "m_panPic";
					this.m_panPic.Size = new System.Drawing.Size(320, 131);
					this.m_panPic.TabIndex = 7;
					this.m_panPic.Resize += new System.EventHandler(this.m_panPic_Resize);
					this.m_panPic.DragEnter += new System.Windows.Forms.DragEventHandler(this.m_panPic_DragEnter);
					this.m_panPic.Paint += new System.Windows.Forms.PaintEventHandler(this.m_panPic_Paint);
					this.m_panPic.MouseEnter += new System.EventHandler(this.m_panPic_MouseEnter);
					this.m_panPic.DragDrop += new System.Windows.Forms.DragEventHandler(this.m_panPic_DragDrop);
					// 
					// m_pic1
					// 
					this.m_pic1.ContextMenu = this.cmnuPic1;
					this.m_pic1.Location = new System.Drawing.Point(64, 32);
					this.m_pic1.Name = "m_pic1";
					this.m_pic1.Size = new System.Drawing.Size(536, 208);
					this.m_pic1.TabIndex = 0;
					this.m_pic1.TabStop = false;
					this.m_pic1.Paint += new System.Windows.Forms.PaintEventHandler(this.m_pic1_Paint);
					this.m_pic1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.m_pic1_MouseUp);
					this.m_pic1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.m_pic1_MouseMove);
					this.m_pic1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.m_pic1_MouseDown);
					// 
					// cmnuPic1
					// 
					this.cmnuPic1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
							this.cmnuPic1Previous,
							this.cmnuPic1Next,
							this.cmnuPic1Sep0,
							this.cmnuPic1Save,
							this.cmnuPic1Properties});
					// 
					// cmnuPic1Previous
					// 
					this.cmnuPic1Previous.Index = 0;
					this.cmnuPic1Previous.Text = "Previous Image";
					this.cmnuPic1Previous.Click += new System.EventHandler(this.cmnuPic1Previous_Click);
					// 
					// cmnuPic1Next
					// 
					this.cmnuPic1Next.Index = 1;
					this.cmnuPic1Next.Text = "Next Image";
					this.cmnuPic1Next.Click += new System.EventHandler(this.cmnuPic1Next_Click);
					// 
					// cmnuPic1Sep0
					// 
					this.cmnuPic1Sep0.Index = 2;
					this.cmnuPic1Sep0.Text = "-";
					// 
					// cmnuPic1Save
					// 
					this.cmnuPic1Save.Enabled = false;
					this.cmnuPic1Save.Index = 3;
					this.cmnuPic1Save.Text = "Save Selection";
					this.cmnuPic1Save.Click += new System.EventHandler(this.cmnuPic1Save_Click);
					// 
					// cmnuPic1Properties
					// 
					this.cmnuPic1Properties.Index = 4;
					this.cmnuPic1Properties.Text = "Properties";
					this.cmnuPic1Properties.Click += new System.EventHandler(this.cmnuPic1Properties_Click);
					// 
					// m_tmr1
					// 
					this.m_tmr1.Interval = 3000;
					this.m_tmr1.Tick += new System.EventHandler(this.m_tmr1_Tick);
					// 
					// MainForm
					// 
					this.AllowDrop = true;
					this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
					this.ClientSize = new System.Drawing.Size(320, 153);
					this.Controls.Add(this.m_panPic);
					this.Controls.Add(this.m_sbr1);
					this.HelpButton = true;
					this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
					this.KeyPreview = true;
					this.Menu = this.mnuMain;
					this.MinimumSize = new System.Drawing.Size(328, 208);
					this.Name = "MainForm";
					this.Text = "Album Surfer";
					this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
					this.Load += new System.EventHandler(this.MainForm_Load);
					this.DragDrop += new System.Windows.Forms.DragEventHandler(this.MainForm_DragDrop);
					this.Closed += new System.EventHandler(this.MainForm_Closed);
					this.Activated += new System.EventHandler(this.MainForm_Activated);
					this.DragEnter += new System.Windows.Forms.DragEventHandler(this.MainForm_DragEnter);
					((System.ComponentModel.ISupportInitialize)(this.m_spanInfo)).EndInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanPicXY)).EndInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanBmapWH)).EndInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanIdOfTot)).EndInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanFormat)).EndInit();
					((System.ComponentModel.ISupportInitialize)(this.m_spanPercentage)).EndInit();
					this.m_panPic.ResumeLayout(false);
					this.ResumeLayout(false);
					
			}
#endregion
		
			//---------------------------- M a i n -----------------------------
			//
			///<summary>The entry point of the application for windows.</summary>
			///<param name='astrArgs'>Array of invocation command line arguments, if any.</param>
			///<returns>void.</returns>
			///<remarks>This is the main entry point for windows and kicks off the application
			/// functionality by instantiating the MainForm and spawning it.
			///Additionally we instantiate our application persistent store mechanism and
			///show the splash screen letting the user know we have started.</remarks>
			//
			//------------------------------------------------------------------
			[STAThread]
			static void Main(
					string[]              astrArgs )
			{
				Int32                 s32IX;
					
#if USE_REGISTRY
					g_reg     = new RegistryClass(  );
#else
					g_reg     = new RegXmlClass(  );
#endif
					ms_strWinPlacement = g_reg.StringGet_str( "MainWinDetails", "10,10,331,262");
					
					SplashForm.ShowIt( false,  E_SPLASH_MODE.GOAWAY, ms_strWinPlacement );
					SplashForm.SetStatus( "Click to make disappear" );
					Application.DoEvents();
					
					ms_strHelpPathFile = Application.StartupPath;
					// we want to make the root up from "\bin\debug" or "\bin\Release"
					s32IX = ms_strHelpPathFile.IndexOf( "\\bin\\" );
					if( s32IX > 0 ) 
					{   // "bin\" is in the string
						ms_strHelpPathFile = ms_strHelpPathFile.Substring( 0, s32IX );
					}   // it has no '\' at the end
				ms_strHelpPathFile += "//AlbumSurfer.chm";
					
					if( astrArgs.Length > 0 )
					{ // Command Line Arguments take precedence over stored values
						g_strSelectedPathFile = astrArgs[ 0 ];
					}
					else
					{
						g_strSelectedPathFile = g_reg.StringGet_str( CONST.REG_START_IMAGE, "");
					}
				
					frmMain   = new MainForm( );
					frmMain.Text = Application.ProductName + "  V" + Application.ProductVersion;
					Application.Run( frmMain );
			}
		
#region Main Form Events
			// ------------------- M a i n F o r m _ L o a d --------------------
			//
			///<summary>Handles the Form Load event.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Sets up window position and size and initializes some data values.</remarks>
			//
			// ------------------------------------------------------------------
			private void MainForm_Load(
					object                sender,
					System.EventArgs      e )
			{
				string[]              astrValues          = null;
					Int32                 s32Default;
					string                strFileTypeList;
					
					astrValues = ms_strWinPlacement.Split( ',' );
					
					frmMain.Left    = Convert.ToInt32( astrValues[0] );
					frmMain.Top     = Convert.ToInt32( astrValues[1] );
					frmMain.Width   = Convert.ToInt32( astrValues[2] );
					//m_ynSuspendLayout  = false; // this will permit a resize to continue
					frmMain.Height  = Convert.ToInt32( astrValues[3] );
					
					s32Default = 75;
					ms_s32JpegSaveQuality = g_reg.LongGet_lng( "Jpeg Quality", s32Default );
					// lets make sure the user didn't stuff some weird number in the registry
					if(   ( ms_s32JpegSaveQuality > 100 )
							|| ( ms_s32JpegSaveQuality < 15  ) )
					{
						ms_s32JpegSaveQuality = 75;
					}
				
					s32Default = 500;
					g_s32TimerInterval = g_reg.LongGet_lng( "Time Interval", s32Default );
					
					try
					{
						// initialize the Image File Extensions array list
						m_alstImageExts = new ArrayList();
							m_alstImageExts.Add("*.JPG");
							m_alstImageExts.Add("*.JPEG");
							m_alstImageExts.Add("*.GIF");
							m_alstImageExts.Add("*.BMP");
							m_alstImageExts.Add("*.PNG");
							m_alstImageExts.Add("*.TIF");
							m_alstImageExts.Add("*.TIFF");

							m_alstImageExts.Add("*.jpg");
							m_alstImageExts.Add("*.jpeg");
							m_alstImageExts.Add("*.gif");
							m_alstImageExts.Add("*.bmp");
							m_alstImageExts.Add("*.png");
							m_alstImageExts.Add("*.tif");
							m_alstImageExts.Add("*.tiff");

							m_alstImageExts.Add("*.Jpg");
							m_alstImageExts.Add("*.Jpeg");
							m_alstImageExts.Add("*.Gif");
							m_alstImageExts.Add("*.Bmp");
							m_alstImageExts.Add("*.Png");
							m_alstImageExts.Add("*.Tif");
							m_alstImageExts.Add("*.Tiff");

							
							m_alstFiles = new ArrayList();  // instantiate our file list container
						
							FileListInit( true );
							ImageSelectedShow( );
							
					}
				catch( Exception excp )
				{
					m_spanInfo.Text = "ERROR: " + excp.Message;
				}
				
					strFileTypeList = "JPEG files (*.jpg;*.jpeg)|*.jpg;*.jpeg" +
					"|GIF Files (*.gif)|*.gif" +
					"|BMP Files (*.bmp)|*.bmp" +
					"|TIFF Files (*.tif;*.tiff)|*.tif;*.tiff" +
					"|PNG Files (*.png)|*.png\"";
					
					m_dlgFileOpen.Filter = "\"All Image Files (JPEG, GIF, BMP, etc.)|*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff;*.png|" +
					strFileTypeList;
					m_dlgFileOpen.FilterIndex = 1;
					m_dlgFileOpen.Title = "Select Image File";
					
					m_dlgFileSave.Filter = strFileTypeList;
					
					// create delegate used for asynchronous call (see Form1_DragDrop)
					m_DelegateDragDropOpen = new DelegateDragDropOpen(this.DragDropOpen);
					
					//m_ynSuspendLayout = false;
					this.Activate();  // make mouse wheel scrolling work immediately
			}// End of MainForm_Load
		
			
			// ----------------- M a i n F o r m _ C l o s e d ------------------
			//
			///<summary>Handle the Form Closed event.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Store user values in persistence object data for next execution.</remarks>
			//
			// ------------------------------------------------------------------
			private void MainForm_Closed(
					object                sender,
					System.EventArgs      e )
			{
				if( frmMain.WindowState == FormWindowState.Normal ) 
				{
					string              strWinDetails;
						
						strWinDetails = string.Format( "{0},{1},{2},{3}", 
								frmMain.Left, frmMain.Top, frmMain.Width, frmMain.Height );
						g_reg.StringSet( "MainWinDetails", strWinDetails );
				}
				
					g_reg.StringSet( "Start Image", g_strSelectedPathFile );
					g_reg.LongSet("Jpeg Quality", ms_s32JpegSaveQuality );
					g_reg.LongSet( "Time Interval", g_s32TimerInterval );
			}
		
			//-------------- M a i n F o r m _ A c t i v a t e d ---------------
			//
			///<summary>Handles the Main Form Activate event.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>This event ensures that mouse wheel input will be seen by the control that changes images.</remarks>
			//
			//------------------------------------------------------------------
			void MainForm_Activated(
					object                sender,
					System.EventArgs      e )
			{
				m_panPic.Focus();  // this little kludge ensures mouse wheel input will be seen
			}
		
			//--------------- M a i n F o r m _ D r a g D r o p ----------------
			//
			///<summary>Handles the Drag Drop event for the Main Form.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If the user drops it in a form owned area, we will receive it.</remarks>
			//
			//------------------------------------------------------------------
			void MainForm_DragDrop(
					object                sender,
					System.Windows.Forms.DragEventArgs e )
			{
				DragDropExecute( e );
			}

		// --------------- M a i n F o r m _ K e y D o w n -----------------
		//
		///<summary>Handles the form KeyDown event.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>Narrative.</remarks>
		//
		// ------------------------------------------------------------------
		private void MainForm_KeyDown(
				object                sender,
				System.Windows.Forms.KeyEventArgs e )
		{
			switch( e.KeyCode )
			{
				case Keys.Escape:     this.Close();       Application.Exit();   break;
				case Keys.Back:       ImagePrevious();    e.Handled = true;     break;
				case Keys.Home:       ImageZoomIn();           e.Handled = true;     break;
				case Keys.End:        ImageZoomOut();          e.Handled = true;     break;
						      
				case Keys.Oemtilde:   ImageFitToWindow(true);  e.Handled = true;     break;
				case Keys.D1:         ImageSizeSet( 1.0F );    e.Handled = true;     break;
				case Keys.D2:         ImageSizeSet( 2.0F );    e.Handled = true;     break;
				case Keys.D3:         ImageSizeSet( 3.0F );    e.Handled = true;     break;
				case Keys.D4:         ImageSizeSet( 4.0F );    e.Handled = true;     break;
				case Keys.D5:         ImageSizeSet( 5.0F );    e.Handled = true;     break;
				case Keys.D6:         ImageSizeSet( 6.0F );    e.Handled = true;     break;
						      
				case Keys.F11:            // catches the instance when full screen
				case Keys.Enter:
				case Keys.PageDown:   ImageNext();        e.Handled = true;     break;
						      
				case Keys.F12:            // catches the instance when full screen
				case Keys.Space: 
				case Keys.PageUp:     ImagePrevious();    e.Handled = true;     break;
						      
				case Keys.Add: 
				case Keys.Oemplus:    ImageZoomIn();           e.Handled = true;     break;
				case Keys.Subtract:
				case Keys.OemMinus:   ImageZoomOut();          e.Handled = true;     break;
						      
				case Keys.Up:         Pic1Scroll( Keys.Up, e.Shift );     e.Handled = true;  break;
				case Keys.Down:       Pic1Scroll( Keys.Down, e.Shift );   e.Handled = true;  break;
				case Keys.Right:      Pic1Scroll( Keys.Right, e.Shift );  e.Handled = true;  break;
				case Keys.Left:       Pic1Scroll( Keys.Left, e.Shift );   e.Handled = true;  break;
				case Keys.F2:         ScreenFullToggle();                 e.Handled = true;  break;
						      
				case Keys.F3:         WindowState = FormWindowState.Minimized;  e.Handled = true;   break;
						      
				case Keys.F1:
					     Help.ShowHelp( this, ms_strHelpPathFile );
						     e.Handled = true;   
						     break;
						     
			}
			//e.Handled = true;    
		}
		
			//-------------- M a i n F o r m _ D r a g E n t e r ---------------
			//
			///<summary>Handles the Drag Enter event for the Main Form.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If the user is dragging a "FileDrop" to the form response by
			///turning on the Copy indicator giving feedback to the user indicating
			///the drop will be accepted.</remarks>
			//
			//------------------------------------------------------------------
			void MainForm_DragEnter(
					object                sender,
					System.Windows.Forms.DragEventArgs e )
			{
				// If file is dragged, show cursor "Drop allowed"
				if (e.Data.GetDataPresent(DataFormats.FileDrop)) 
					e.Effect = DragDropEffects.Copy;
				else
					e.Effect = DragDropEffects.None;
			}
		
#endregion
#region MainForm Menu Events
			// ----------- m n u F i l e O p e n F i l e _ C l i c k ------------
			//
			///<summary>Handles the File Open menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Present to the user a File Open Dialog and set up files.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuFileOpenFile_Click(
					object                sender,
					System.EventArgs      e )
			{
				
					if( m_dlgFileOpen.ShowDialog() == DialogResult.OK )
					{
						g_strSelectedPathFile = m_dlgFileOpen.FileName;
							
							FileListInit( false );
							m_sfpScale = 1.00F;
							if( m_s32FileIXNext != -1 )
							{
								ImageSelectedShow( );
							}
					}
			}
		
			// --------- m n u F i l e I m a g e s S h o w _ C l i c k ----------
			//
			///<summary>Handles the File menu Images Show menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Toggle the auto show feature on and off.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuFileImagesShow_Click(
					object                sender,
					System.EventArgs      e )
			{
				if( mnuFileImagesShow.Checked == true )
				{
					m_tmr1.Stop();
						mnuFileImagesShow.Checked = false;
				}
				else
				{
					m_tmr1.Start();
						mnuFileImagesShow.Checked = true;
				}
			}   
		
			// --------------- m n u F i l e E x i t _ C l i c k ----------------
			//
			///<summary>Handles the File menu Exit menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Abort the application and exit.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuFileExit_Click(
					object                sender,
					System.EventArgs      e )
			{
				this.Close();
			}
		
			// ------ m n u V i e w P r e v i o u s I m a g e _ C l i c k -------
			//
			///<summary>Handles the View menu Previous Image menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Display the sequentially previous image to the user.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuViewPreviousImage_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImagePrevious();
			}
		
			// ---------- m n u V i e w N e x t I m a g e _ C l i c k -----------
			//
			///<summary>Handles the View menu Next Image menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Display the sequentially next image to the user.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuViewNextImage_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImageNext();
			}

		//-------- m n u V i e w F i t T o W i n d o w _ C l i c k ---------
		//
		///<summary>Handles the View menu Fit To Window menu item click.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>Set the image to fit the window, at least one aspect.</remarks>
		//
		//------------------------------------------------------------------
		private void mnuViewFitToWindow_Click(
				object                sender,
				System.EventArgs      e )
		{
			ImageFitToWindow( !mnuViewFitToWindow.Checked );
		}
		
			// ------------- m n u V i e w Z o o m I n _ C l i c k --------------
			//
			///<summary>Handles the View menu ImageZoomIn menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			/// <returns>void.</returns>
			/// <remarks>Zoom in the image for the user.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuViewZoomIn_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImageZoomIn();
			}
		
			//------------ m n u V i e w Z o o m O u t _ C l i c k -------------
			//
			///<summary>Handles the View menu ImageZoomOut menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Zoom out for the user.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuViewZoomOut_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImageZoomOut();
			}
		
			// --------- m n u V i e w A c t u a l S i z e _ C l i c k ----------
			//
			///<summary>Handles the View menu Actual Size menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			/// <returns>void.</returns>
			/// <remarks>Set the image being displayed to it nature resolution factor.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuViewActualSize_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImageActualSize( !mnuViewActualSize.Checked );
			}
		
			//--------- m n u V i e w F u l l S c r e e n _ C l i c k ----------
			//
			///<summary>Handles the View menu Full Screen item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>When the user click this menu item the image goes to full screen with
			///no borders, menu or status bar.</remarks>
			//
			//------------------------------------------------------------------
			void mnuViewFullScreen_Click(
					object                sender,
					System.EventArgs      e )
			{
				ScreenFullToggle();
			}
		
			
			// ----------- m n u T o o l s O p t i o n s _ C l i c k ------------
			// 
			///<summary>Handles the Tools menu Option item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Show the user the Options Form.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuToolsOptions_Click(
					object                sender,
					System.EventArgs      e )
			{
				OptionsForm           frmOptions = new OptionsForm();
					
					frmOptions.ShowDialog();
					m_tmr1.Interval = g_s32TimerInterval;
					
			}

		//--------------- m n u H e l p H e l p _ C l i c k ----------------
		//
		///<summary>Handles the Help menu Help item click event.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>When the user clicks this menu item the compiled help file appears on the screen.</remarks>
		//
		//------------------------------------------------------------------
		void mnuHelpHelp_Click(
				object                sender,
				System.EventArgs      e )
		{
			Help.ShowHelp( this, ms_strHelpPathFile );
		}
		
			// -------------- m n u H e l p A b o u t _ C l i c k ---------------
			//
			///<summary>Handles the Help menu About menu item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Show the user the application About form.</remarks>
			//
			// ------------------------------------------------------------------
			private void mnuHelpAbout_Click(
					object                sender,
					System.EventArgs      e )
			{
				AboutForm             frmAbout   = new AboutForm();;
					
					frmAbout.ShowDialog( this );
			}
#endregion
#region Pic1 Context Menu Events
		
			//---------- c m n u P i c 1 P r e v i o u s _ C l i c k -----------
			//
			///<summary>Handles the m_pic1 context menu Previous item click event.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If the user calls up the context menu in the picture box and clicks
			///the "Previous Image" item, show the previous image.</remarks>
			//
			//------------------------------------------------------------------
			void cmnuPic1Previous_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImagePrevious();
			}
		
			//-------------- c m n u P i c 1 N e x t _ C l i c k ---------------
			//
			///<summary>Handles the m_pic1 context menu Next item click event.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If the user calls up the context menu in the picture box and clicks
			///the "Next Image" item, show the next image..</remarks>
			//
			//------------------------------------------------------------------
			void cmnuPic1Next_Click(
					object                sender,
					System.EventArgs      e )
			{
				ImageNext();
			}
		
			// -------------- c m n u P i c 1 S a v e _ C l i c k ---------------
			//
			///<summary>Handles the m_pic1 context menu "Save" item click.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If a selection rectangle has been defined open the file save dialog
			///and give the user the option of the format that the selected area is saved in.</remarks>
			//
			// ------------------------------------------------------------------
			private void cmnuPic1Save_Click(
					object                sender,
					System.EventArgs      e )
			{
				Bitmap                bmapSelection = null;
					string                strExtension;
					ImageFormat           ifmtSave = ImageFormat.Bmp;
					ImageCodecInfo        icdi;
					Encoder               ecdr;
					EncoderParameter      ecdrParm;
					EncoderParameters     ecdrParms;
					Boolean               ynSaved = false;
					
					
					if( cmnuPic1Save.Enabled == true )
					{ // first lets remove the selection rectangle because those pixels are included
						ControlPaint.DrawReversibleFrame( m_rectReversable, Color.Empty, System.Windows.Forms.FrameStyle.Dashed );
							cmnuPic1Save.Enabled = false;
					}
				
					if(   ( m_s32SelectW == 0 )
							|| ( m_s32SelectH == 0 ) )
					{
						return;  // actually have to select something
					}
				
					// if the user picked any thing backwards, normalize it to Left,Top,Width,Height
					if( m_s32SelectW < 0 )
					{
						m_ptStart.X += m_s32SelectW;   // this moves the selected X origin
						m_s32SelectW = Math.Abs( m_s32SelectW );
					}
				
					if( m_s32SelectH < 0 )
					{
						m_ptStart.Y += m_s32SelectH;   // this moves the selected X origin
						m_s32SelectH = Math.Abs( m_s32SelectH );
					}
				
					bmapSelection = Pic1SelectionGet_bmap( );
					
					if( m_dlgFileSave.ShowDialog() == DialogResult.OK )
					{
						strExtension = Path.GetExtension(m_dlgFileSave.FileName );
							strExtension = strExtension.ToLower();
							switch( strExtension )
							{
								case ".bmp":     ifmtSave = ImageFormat.Bmp;     break;
									case ".gif":     ifmtSave = ImageFormat.Gif;     break;
									case ".png":     ifmtSave = ImageFormat.Png;     break;
									case ".wmf":     ifmtSave = ImageFormat.Wmf;     break;
									case ".tiff":
									case ".tif":     ifmtSave = ImageFormat.Tiff;    break;
									
									case ".jpg":
									case ".jpeg":
									// http://support.microsoft.com/?id=324790   EncoderValue Enumeration
									ecdr = Encoder.Quality;
									ecdrParm = new EncoderParameter( ecdr, (Int64)ms_s32JpegSaveQuality );
									ecdrParms = new EncoderParameters(1);
									ecdrParms.Param[ 0 ] = ecdrParm;
									icdi = ImageCodecInfoGet_icdi( "image/jpeg" );
									if( icdi != null )
									{
										bmapSelection.Save( m_dlgFileSave.FileName, icdi, ecdrParms  );
											ynSaved = true;
									}
									else // let the generic save below do it
									{
										ifmtSave = ImageFormat.Jpeg;
									}
								
									break;
							}
						
							if( ynSaved == false )
							{
								bmapSelection.Save( m_dlgFileSave.FileName, ifmtSave );
							}
					}
				
					m_s32SelectW = 0;
					m_s32SelectH = 0;
					bmapSelection.Dispose();
			}


		private ImageCodecInfo ImageCodecInfoGet_icdi( String strMimeType )
		{
			int                   s32IX;
				ImageCodecInfo[]      aicdi;
				
				aicdi = ImageCodecInfo.GetImageEncoders();
				for( s32IX = 0; s32IX < aicdi.Length; ++s32IX )
				{
					if( aicdi[ s32IX ].MimeType == strMimeType )
						return aicdi[ s32IX ];
				}
			return null;
		}

#endregion
#region m_panPic Events
		//------------------ m _ p a n P i c _ P a i n t -------------------
		//
		///<summary>Paint the bitmap according to the scaling factor. Usually initiated
		///by an Invalidate.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>This procedures main job is to figure out the positioning of the picture
		///box control in its container panel. This is all a function of the scaling factor
		///the user has chosen for the image.</remarks>
		//
		// ------------------------------------------------------------------
		private void m_panPic_Paint(
				object                sender,
				System.Windows.Forms.PaintEventArgs e )
		{
			Single                sfpWRatio;
				Single                sfpHRatio;
				
				if( m_bmap == null )
				{
					m_spanInfo.Text = "No image selected...";
						return;
				}
			
				try
				{  
					m_spanInfo.Text = "Working .....";
						if( m_ynSizeToFit == false )
						{   // First lets find the size W,H of the scaled image
							m_pic1.Width  = (Int32)( m_bmap.Width  * m_sfpScale );
								m_pic1.Height = (Int32)( m_bmap.Height * m_sfpScale );
								
								if(   ( m_panPic.Width  >= m_pic1.Width  ) 
										&& ( m_panPic.Height >= m_pic1.Height ) )
								{  // the scaled image is smaller or equal than the m_panPic container
									m_panPic.AutoScroll = false;
										// CEnter it in the panel
										m_pic1.Left = ( m_panPic.Width  - m_pic1.Width ) / 2;
										m_pic1.Top  = ( m_panPic.Height - m_pic1.Height) / 2;
								}
							
								else  // one or both dimensions are larger than container
								{
									m_panPic.AutoScroll = true;
										if( m_panPic.Width >= m_pic1.Width ) 
										{
											m_pic1.Left = ( m_panPic.Width - m_pic1.Width ) / 2;
										}
										else // m_panPic.Width < m_pic1.Width
										{
											m_pic1.Left = m_panPic.AutoScrollPosition.X;
										}
									
										if( m_panPic.Height >= m_pic1.Height )
										{
											m_pic1.Top  = ( m_panPic.Height - m_pic1.Height) / 2;
										}
										else
										{
											m_pic1.Top = m_panPic.AutoScrollPosition.Y;
										}
								}
						}
						else // m_ynSizeToFit == true
						{
							m_panPic.AutoScroll = false;
								m_pic1.SizeMode = PictureBoxSizeMode.CenterImage;
								
								sfpWRatio = (Single)m_panPic.Width  / (Single)m_bmap.Width;
								sfpHRatio = (Single)m_panPic.Height / (Single)m_bmap.Height;
								if( sfpWRatio < sfpHRatio )
								{
									m_sfpScale = sfpWRatio;
								}
								else
								{
									m_sfpScale =  sfpHRatio;
								}
							m_pic1.Width  = (Int32)( m_bmap.Width  * m_sfpScale );
								m_pic1.Height = (Int32)( m_bmap.Height * m_sfpScale );
								m_pic1.Left   = ( m_panPic.Width  - m_pic1.Width ) / 2;
								m_pic1.Top    = ( m_panPic.Height - m_pic1.Height) / 2;
						}
					
						// Fill in the status bar panels with our data
						
						m_spanBmapWH.Text      = m_bmap.Width.ToString() + "x" + m_bmap.Height.ToString();
						m_spanFormat.Text      = m_bmap.PixelFormat.ToString();
						m_spanPercentage.Text  = m_sfpScale.ToString( "P" );  // Format as a percent
				}
			catch( Exception excp )
			{
				m_spanInfo.Text = "ERROR: " + excp.Message;
			}
			
				m_spanInfo.Text = "Ready";   
				m_pic1.Invalidate();  // this needed in case to of the exact size images, m_pic1 does not repaint
		} 

		//-------------- m _ p a n P i c _ D r a g E n t e r ---------------
		//
		///<summary>Handles the Drag Enter event for the picture box panel control.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>If the user is dragging a "FileDrop" to the form response by
		///turning on the Copy indicator giving feedback to the user indicating
		///the drop will be accepted..</remarks>
		//
		//------------------------------------------------------------------
		void m_panPic_DragEnter(
				object                sender,
				System.Windows.Forms.DragEventArgs e )
		{
			// If file is dragged, show cursor "Drop allowed"
			if( e.Data.GetDataPresent( DataFormats.FileDrop ) )
			{
				e.Effect = DragDropEffects.Copy;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}
		
			//--------------- m _ p a n P i c _ D r a g D r o p ----------------
			//
			///<summary>Handles the Drag Drop event for the picture box panel control.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If the user drops it in a picture box panel control area, 
			///we will receive it.</remarks>
			//
			//------------------------------------------------------------------
			void m_panPic_DragDrop(
					object                sender,
					System.Windows.Forms.DragEventArgs e )
			{
				DragDropExecute( e );
			}
		

			//------------- m _ p a n P i c _ M o u s e W h e e l --------------
			//
			///<summary>Handles the mouse wheel event in the picture box panel control.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>If the mouse wheel is rotated up show the next image, if down show the 
			///previous image.</remarks>
			//
			//------------------------------------------------------------------
			void m_panPic_MouseWheel(
					object                sender,
					MouseEventArgs        e )
			{
				if ( e.Delta < 0 )
				{
					ImageNext();
				}
				else
				{
					ImagePrevious();
				}
			}
		
			//------------- m _ p a n P i c _ M o u s e E n t e r --------------
			//
			///<summary>Handles the Mouse Enter event in the picture box panel control.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>To receive mouse wheel events the control has to have focus.
			///If the user moves the mouse into the panel control that contains the picture
			///box this procedure will make sure the panel has focus.</remarks>
			//
			//------------------------------------------------------------------
			void m_panPic_MouseEnter(
					object                sender,
					System.EventArgs      e )
			{
				if( m_panPic.Focused == false )
				{
					m_panPic.Focus();
				}
			}
		
			//----------------- m _ p a n P i c _ R e s i z e ------------------
			//
			///<summary>Handles the m_panPic Resize event.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>This event occurs whenever the user resizes the main form. The invalidate forces
			///a m_panPic Repaint which forces a m_pic1 repaint with the new size.</remarks>
			//
			//------------------------------------------------------------------
			void m_panPic_Resize(
					object                sender,
					System.EventArgs      e )
			{
				m_panPic.Invalidate();  // this will force a pan paint which will force a pic paint
			}
#endregion
#region m_pic1 Events
		//-------------------- m _ p i c 1 _ P a i n t ---------------------
		//
		///<summary>Paints the bitmap into the m_pic1 picture box object.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>Paints the image into the form picture box control.</remarks>
		//
		// ------------------------------------------------------------------
		private void m_pic1_Paint(
				object                sender,
				System.Windows.Forms.PaintEventArgs e )
		{
			if( m_bmap == null )  // happens if never selected
				return;
					
					Graphics              gc = e.Graphics;   // e refers to destination object, i.e. m_pic1
			
				gc.DrawImage( m_bmap, new RectangleF( 0, 0, m_pic1.Width, m_pic1.Height ) );
		}
		
			//---------------- m _ p i c 1 _ M o u s e D o w n -----------------
			//
			///<summary>Handles the Mouse Down in the m_pic1 picture box control.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>This is typically the start of an area selection action so we need
			///to store our starting coordinates.</remarks>
			//
			// ------------------------------------------------------------------
			private void m_pic1_MouseDown(
					object                sender,
					System.Windows.Forms.MouseEventArgs e )
			{
				if( e.Button != MouseButtons.Left )
				{
					return;
				}
				
					if( cmnuPic1Save.Enabled == true )
					{  // we need to make it go away to draw another
						ControlPaint.DrawReversibleFrame( m_rectReversable, Color.Empty, System.Windows.Forms.FrameStyle.Dashed );
							cmnuPic1Save.Enabled = false;
					}
				
					m_ynPicMouseDown  = true;
					m_ptStart.X       = e.X;
					m_ptStart.Y       = e.Y;
					m_s32SelectW      = 0;
					m_s32SelectH      = 0;
					
					// Convert from local to screen coordinates
					m_ptScreen    = m_ptStart;
					m_ptScreen.X += m_pic1.Left;
					m_ptScreen.Y += m_pic1.Top;
					
					m_ptScreen    = PointToScreen( m_ptScreen );
					m_rectReversable.Y  = m_ptScreen.Y;
					m_rectReversable.X  = m_ptScreen.X;
			}

		//---------------- m _ p i c 1 _ M o u s e M o v e -----------------
		//
		///<summary>Handles the Mouse Move Event in the m_pic1 control</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>Translate the mouse position in the m_pic1 control and display to the user
		///If we are in a select region activity undraw and redraw the selection rectangle.</remarks>
		//
		// ------------------------------------------------------------------
		private void m_pic1_MouseMove(
				object                sender,
				System.Windows.Forms.MouseEventArgs e )
		{
			Int32                 s32X        = e.X;
				Int32                 s32Y        = e.Y;
				
				if( s32X > m_pic1.Width)   // we want to confine our selection pointer to the Pic window
				{
					s32X = m_pic1.Width;
				}
			if( s32X < 0 )
			{
				s32X = 0;
			}
			if( s32Y > m_pic1.Height)
			{
				s32Y = m_pic1.Height;
			}
			if( s32Y < 0 )
			{
				s32Y = 0;
			}
			
				if( m_ynPicMouseDown == false )
				{
					m_spanPicXY.Text = s32X.ToString() + "x" + s32Y.ToString();
				}
				else // show the size of our selection
				{
					if( cmnuPic1Save.Enabled == true )
					{  // we need to make it go away to draw another
						ControlPaint.DrawReversibleFrame( m_rectReversable, Color.Empty, System.Windows.Forms.FrameStyle.Dashed );
					}
					
						m_s32SelectW =  s32X - m_ptStart.X;
						m_s32SelectH =  s32Y - m_ptStart.Y;
						m_spanPicXY.Text = m_s32SelectW.ToString() + "x" + m_s32SelectH.ToString();
						
						m_rectReversable.Width  = m_s32SelectW;
						m_rectReversable.Height = m_s32SelectH;
						//m_rectXOR.DrawXORRectangle( g, m_ptStart.X, m_ptStart.Y, m_ptStart.X +m_s32SelectW, m_ptStart.Y + m_s32SelectH );
						ControlPaint.DrawReversibleFrame( m_rectReversable, Color.Empty, System.Windows.Forms.FrameStyle.Dashed );
						cmnuPic1Save.Enabled = true;
				}
		}
		
			// ------------------ m _ p i c 1 _ M o u s e U p -------------------
			//
			///<summary>Handles the Mouse Up event in the m_pic1 picture box control.</summary>
			///<param name='sender'>Object sending the event.</param>
			///<param name='e'>Event arguments.</param>
			///<returns>void.</returns>
			///<remarks>Typically the end of a select area action.</remarks>
			//
			// ------------------------------------------------------------------
			private void m_pic1_MouseUp(
					object                sender,
					System.Windows.Forms.MouseEventArgs e )
			{
				m_ynPicMouseDown = false;
			}
#endregion

		// --------------------- m _ t m r 1 _ T i c k ----------------------
		//
		///<summary>Handles the timer tick event.</summary>
		///<param name='sender'>Object sending the event.</param>
		///<param name='e'>Event arguments.</param>
		///<returns>void.</returns>
		///<remarks>If the timer is running we are sequentially showing images, 
		/// get the next one.</remarks>
		//
		// ------------------------------------------------------------------
		private void m_tmr1_Tick(
				object                sender,
				System.EventArgs      e )
		{
			ImageNext();
		}


		//-------------------- F i l e L i s t I n i t ---------------------
		//
		///<summary>Procedure to initialize the file access mechanism.</summary>
		///<param name='ynStartUp'>Arg1Purpose.</param>
		///<returns>void.</returns>
		///<remarks>Using the selected file path we will search the entire directory for
		///all graphic files we know anything about, sort them by their root name, and
		///display the one the user started with.</remarks>
		//
		//------------------------------------------------------------------
		void FileListInit(
				bool                  ynStartUp )
		{
			string[]              astrFiles;
				string                strPath;
				IComparer             icmpFileName;
				string                strNewSelection;
				
				m_alstFiles.Clear();
				strNewSelection = g_strSelectedPathFile;  // we preserve the old reference
			
				if( strNewSelection.Length < 1 )
				{
					strNewSelection = "c:\\Whatever.jpg";  // see if any images on the C root
				}
			try
			{
				strPath = Path.GetDirectoryName( strNewSelection );
			}
			catch( Exception excp )
			{
				m_spanInfo.Text = "Bad start file/path = " + excp.Message;
					strNewSelection = "c:\\Whatever.jpg";
					strPath = "c:\\";
			}
			
				// search for all the image files in this directory
				foreach( string strType in m_alstImageExts )
				{
					astrFiles = Directory.GetFiles( strPath, strType);
						if( astrFiles.Length > 0 )
							m_alstFiles.AddRange( astrFiles );
				}
			
				if( m_alstFiles.Count < 1 )   // we have no graphics files in this directory
				{  // now we need to figure out if we ever had a good graphic file or if this is startup
					if( ynStartUp == true )
					{
						return;
					}
				}
			icmpFileName = new ImageNameSortClass();
				m_alstFiles.Sort( icmpFileName );
				
				m_s32FileIXShowing = -1;
				g_strSelectedPathFile = strNewSelection;
				if( m_alstFiles.Count > 0 )
				{
					m_s32FileIXNext = m_alstFiles.IndexOf( g_strSelectedPathFile );
						if( m_s32FileIXNext == -1  )  // we have files but there was no match
						{
							m_s32FileIXNext = 0;
								g_strSelectedPathFile = m_alstFiles[m_s32FileIXNext].ToString();
						}
				}
		}
		
			//--------------- I m a g e S e l e c t e d S h o w ----------------
			//
			///<summary>Displays the image represented by the index the user has chosen.</summary>
			///<returns>void.</returns>
			///<remarks>The mechanism for selecting an image is to set the m_s32FileIXNext variable
			/// to the index of the image you want to display.</remarks>
			//
			//------------------------------------------------------------------
			private void ImageSelectedShow( )
			{
				if(   ( m_s32FileIXNext    == -1  )
						&& ( m_s32FileIXShowing == -1 ) )  // never where able to select something
				{
					return;  // nothing to show
				}
				
					if( m_s32FileIXNext == m_s32FileIXShowing )
					{
						return;  // already up
					}
				
					if( m_alstFiles.Count < 1 )
					{
						return;  // no files in list of possible images
					}
				if( cmnuPic1Save.Enabled == true )
				{ // we need to make it go away 
					ControlPaint.DrawReversibleFrame( m_rectReversable, Color.Empty, System.Windows.Forms.FrameStyle.Dashed );
						cmnuPic1Save.Enabled = false;
				}
				
					try
					{
						if(   ( m_s32FileIXNext > m_alstFiles.Count )
								|| ( m_s32FileIXNext < 0 ) )
						{
							m_s32FileIXNext = 0;
						}
						
							g_strSelectedPathFile  = m_alstFiles[ m_s32FileIXNext ].ToString();
							if( m_bmap != null )  // free up the old bitmap
							{
								m_bmap.Dispose();
							}
						
							m_bmap = new Bitmap( g_strSelectedPathFile );   // this will throw an excp if too large
						m_panPic.Invalidate();
							
							this.Text =  Application.ProductName + " - " + g_strSelectedPathFile;
							m_spanIdOfTot.Text = ( m_s32FileIXNext + 1 ).ToString() + "/" + m_alstFiles.Count.ToString();
					}
				
					catch( Exception excp )
					{
						m_spanInfo.Text = "ERROR: " + excp.Message;
							
							// put back the old one that worked
							if( m_s32FileIXShowing != -1 )
							{
								g_strSelectedPathFile  = m_alstFiles[ m_s32FileIXShowing ].ToString();
									m_bmap = new Bitmap( g_strSelectedPathFile );
							}
					}
			}
		
			//----------------------- I m a g e N e x t ------------------------
			//
			///<summary>Displays the sequentially next image in the list.</summary>
			///<returns>void.</returns>
			///<remarks>Selects and displays the next image in the list and wraps if necessary.</remarks>
			//
			//------------------------------------------------------------------
			private void ImageNext()
			{
				if( m_s32FileIXNext != -1 )
				{
					m_s32FileIXNext++;
						if( m_s32FileIXNext >= m_alstFiles.Count )
						{
							m_s32FileIXNext = 0;  // wrap at the beginning
						}
					
						ImageSelectedShow( );
				}
			}
		
			//------------------- I m a g e P r e v i o u s --------------------
			//
			///<summary>Displays the sequentially previous image in the list.</summary>
			///<returns>void.</returns>
			///<remarks>Selects and displays the previous image in the list and wraps if necessary.</remarks>
			//
			//------------------------------------------------------------------
			private void ImagePrevious()
			{
				if( m_s32FileIXNext != -1 )
				{
					m_s32FileIXNext--;
						if( m_s32FileIXNext < 0 )
						{
							m_s32FileIXNext = m_alstFiles.Count - 1;  // Wrap at the end
						}
					
						ImageSelectedShow( );
				}
			}
		
			//--------------------- I m a g e Z o o m I n ----------------------
			// 
			///<summary>Zooms in the image being displayed.</summary>
			///<returns>void.</returns>
			///<remarks>Changes the scale factor by 25% zooming in.</remarks>
			//
			//------------------------------------------------------------------
			private void ImageZoomIn()
			{
				Single                sfpMultiple;
					Int32                 s32Multiple;
					
					m_ynBusy = true;       // prevent any change of ImageFitToWindow from interacting
				if( m_ynSizeToFit == true )  // we could have had a weird percentage go to next quad
				{
					sfpMultiple = m_sfpScale / .25F;
						s32Multiple = (int)sfpMultiple;
						if( s32Multiple < 2 )
						{
							s32Multiple = 1;
						}
						else
						{
							s32Multiple++;
						}
					m_sfpScale = (Single)s32Multiple * .25F;
						
						mnuViewFitToWindow.Checked = false;
						m_ynSizeToFit = false;
				}
				else  // already a nice 25% multiplier
				{
					if( m_sfpScale < 7.00F ) 
						m_sfpScale += 0.25F;
				}
				mnuViewActualSize.Checked = false;
					m_panPic.Invalidate();
					m_ynBusy = false;
			}
		
			//-------------------- I m a g e Z o o m O u t ---------------------
			//
			///<summary>Zooms out the image being displayed.</summary>
			///<returns>void.</returns>
			///<remarks>Changes the scale factor by 25% zooming out.</remarks>
			//
			//------------------------------------------------------------------
			private void ImageZoomOut()
			{
				Single                sfpMultiple;
					Int32                 s32Multiple;
					
					m_ynBusy = true; 
					if( m_ynSizeToFit == true )  // we could have had a weird percentage go to next quad
					{
						sfpMultiple = m_sfpScale / .25F;
							s32Multiple = (int)sfpMultiple;
							if( s32Multiple < 2 )
							{
								s32Multiple = 1;
							}
						//else
						//{
						//  s32Multiple--;
						//}
						m_sfpScale = (Single)s32Multiple * .25F;
							mnuViewFitToWindow.Checked = false;
							m_ynSizeToFit = false;
					}
					else  // already a nice 25% multiplier
					{
						if( m_sfpScale > 0.25F )
							m_sfpScale -= 0.25F;
					}
				mnuViewActualSize.Checked = false;
					m_panPic.Invalidate();
					m_ynBusy = false;
			}
		
			//-------------------- I m a g e S i z e S e t ---------------------
			//
			///<summary>Makes an attempt to make sure the images about to be used is not too large.</summary>
			///<param name='sfpScale'>The magnification factor.</param>
			///<returns>void.</returns>
			///<remarks>High resolution images can get very very large when you zoom in on them
			///and this procedure tries to prevent the app from blowing up.</remarks>
			//
			//------------------------------------------------------------------
			void ImageSizeSet(
					Single                sfpScale )
			{
				Int32                 s32SizeOverall;
					Single                sfpSizeOverall;
					
					s32SizeOverall = m_bmap.Width * m_bmap.Height;
					sfpSizeOverall = s32SizeOverall * sfpScale;
					if( sfpSizeOverall > 8632400.0F )  // it can blow up big > (1280 x 1024 x 6 )
					{
						m_spanInfo.Text = "Image too large to be scaled ";
							return;   // at some max limit we shut the user off;
					}
				
					m_ynBusy = true; 
					m_sfpScale = sfpScale;
					if( m_ynSizeToFit == true )  // we could have had a weird percentage go to next quad
					{
						mnuViewFitToWindow.Checked = false;
							m_ynSizeToFit = false;
					}
				
					if( sfpScale == 1.0F )
					{
						mnuViewActualSize.Checked = true;
					}
					else
					{
						mnuViewActualSize.Checked = false;
					}
				
					m_panPic.Invalidate();
					m_ynBusy = false;
			}
		
			//----------------- I m a g e A c t u a l S i z e ------------------
			//
			///<summary>Sets the displayed image to its natural resolution.</summary>
			///<param name='ynSet'>Boolean that indicates whether to turn on or off actual size.</param>
			///<returns>void.</returns>
			///<remarks>Narrative.</remarks>
			//
			// ------------------------------------------------------------------
			private void ImageActualSize(
					bool                  ynSet )
			{
				if( m_ynBusy == true )
					return;
						
						m_ynBusy = true;       // prevent any change of ImageFitToWindow from interacting
				m_ynSizeToFit = false;
					if( ynSet == false )
					{
						m_sfpScale = 2.00F;
							mnuViewActualSize.Checked = false;
					}
					else
					{
						mnuViewActualSize.Checked = true;
							if( mnuViewFitToWindow.Checked == true )
							{
								mnuViewFitToWindow.Checked = false;
							}
						
							m_sfpScale = 1.00F;
					}
				m_panPic.Invalidate();
					m_ynBusy = false;
			}
		
			//---------------- I m a g e F i t T o W i n d o w -----------------
			//
			///<summary>Sets the displayed image to a size that makes at least one of its dimensions
			/// fill the display area.</summary>
			///<param name='ynSet'>Boolean that indicates whether to turn on the fit to window, or
			///turn it off.</param>
			///<returns>void.</returns>
			///<remarks>"ImageFitToWindow" and "ImageActualSize" are two parts of the image size logic that
			///tell the drawing routine what size to render the picture. If "ImageFitToWindow" is true it
			///implies that "ImageActualSize" is false and vice versa. If both are false then we are
			///scaling the bitmap rendering at some other resolution.</remarks>
			//
			// ------------------------------------------------------------------
			private void ImageFitToWindow(
					bool                  ynSet )
			{
				if( m_ynBusy == true )
					return;
						
						m_ynBusy = true;
						
						if( ynSet == false )
						{
							mnuViewFitToWindow.Checked = false;
								m_ynSizeToFit = false;
						}
						else
						{
							mnuViewFitToWindow.Checked = true;
								if( mnuViewActualSize.Checked == true )
								{
									mnuViewActualSize.Checked = false;
								}
							m_ynSizeToFit = true;
								m_panPic.Invalidate();  // force it to fit
						}
				m_ynBusy = false;
			}
		
			
			//---------------------- P i c 1 S c r o l l -----------------------
			//
			///<summary>Scrolls the image in the picture panel the direction and amount request by the user.</summary>
			///<param name='keyID'>Whether Up, Down, or Left, Right key was pressed.</param>
			///<param name='ynBig'>Whether we should scroll the pic image a big or small increment.</param>
			///<returns>void.</returns>
			///<remarks>This procedures job is first to figure out the direction and size the
			///user want to scroll the pic image, and then do it. .</remarks>
			//
			//------------------------------------------------------------------
			void Pic1Scroll(
					Keys                  keyID,
					bool                  ynBig )
			{
				
					SCROLLINFO    stuSI = new SCROLLINFO();;  // our scroll info structure
				Int32         s32NewPos;    
					Int32         s32Status;
					Point         ptScroll;     // for updating AutoScrollPosition
				
					if( m_ynSizeToFit == true )
					{
						return;  // there is nothing to scroll
					}
				
					// The below routines permit the keyboard scrolling of the bitmap in what I believe is
					// reasonable amount. The small increment is 1/6 of show window, and the large scroll
					// is 1/3 of the page range(PAGE)(Shift)
					stuSI.u32CbSize =  (uint)Marshal.SizeOf(stuSI);
					stuSI.u32FMask  = User32dll.SIF_ALL;
					if( keyID == Keys.Up  || keyID == Keys.Down )
					{
						s32Status =  User32dll.GetScrollInfo( m_panPic.Handle, (int)User32dll.SB_VERT, out stuSI );
							//Console.WriteLine( "{0} = GetScrollInfo V {1} < {2} < {3}, Page={4}, TrackPos={5}", 
							//              s32Status, stuSI.s32Min.ToString(), stuSI.s32Pos.ToString(), 
							//              stuSI.s32Max.ToString(), stuSI.u32Page.ToString(),
							//              stuSI.s32TrackPos.ToString() );
							if( s32Status == 0 )
							{
								return;  // no returned structure
							}
						
							if( ynBig == true )
							{
								s32NewPos = (Int32)( stuSI.u32Page / 3 );
							}
							else
							{
								s32NewPos = (Int32)( stuSI.u32Page / 6 );
							}
						if( s32NewPos < 1 )
							s32NewPos = 1;
								
								if( keyID == Keys.Up )
									s32NewPos = -s32NewPos;
										
										s32NewPos += stuSI.s32Pos;
										stuSI.s32Pos = s32NewPos;
										stuSI.u32FMask = User32dll.SIF_POS;
										s32Status   = User32dll.SetScrollInfo( m_panPic.Handle, (int)User32dll.SB_VERT, ref stuSI, true );
										//Console.WriteLine( "{0}=SetScrollInfo V[{1}]", s32Status, s32NewPos );
										ptScroll    = m_panPic.AutoScrollPosition;
										ptScroll.Y  = s32NewPos;
										ptScroll.X  = -ptScroll.X;  // maintain the X which is not changing
						m_panPic.AutoScrollPosition = ptScroll;
					}
					else  // keyID == Keys.Left  || keyID == Keys.Right )
					{
						s32Status =  User32dll.GetScrollInfo( m_panPic.Handle, (int)User32dll.SB_HORZ, out stuSI );
							//Console.WriteLine( "{0} =GetScrollInfo H {1} < {2} < {3}, Page={4}, TrackPos={5}", 
							//              s32Status, stuSI.s32Min.ToString(), stuSI.s32Pos.ToString(), 
							//              stuSI.s32Max.ToString(), stuSI.u32Page.ToString(),
							//              stuSI.s32TrackPos.ToString() );
							if( s32Status == 0 )
							{
								return;  // no returned structure
							}
						if( ynBig == true )
						{
							s32NewPos =  (Int32)( stuSI.u32Page / 3 );
						}
						else
						{
							s32NewPos =  (Int32)( stuSI.u32Page / 6 );
						}
						if( s32NewPos < 1 )
							s32NewPos = 1;
								
								if( keyID == Keys.Left )
									s32NewPos = -s32NewPos;
										
										s32NewPos += stuSI.s32Pos;
										stuSI.s32Pos = s32NewPos;
										stuSI.u32FMask = User32dll.SIF_POS;
										s32Status = User32dll.SetScrollInfo( m_panPic.Handle, (int)User32dll.SB_HORZ, ref stuSI, true );
										//Console.WriteLine( "{0} =SetScrollInfo H[{1}]", s32Status,  s32NewPos );
										ptScroll    = m_panPic.AutoScrollPosition; //.X = -s32NewPos;
						ptScroll.X  = s32NewPos;
							ptScroll.Y  = -ptScroll.Y;
							m_panPic.AutoScrollPosition = ptScroll;
					}
				
					//    // below is an alternative method for scrolling the bitmap in the panel, the problem
					//    // is it was designed for text files and as a consequence the small scroll (LINE) is too small
					//    // and the large scroll (PAGE) is too large, hence I employ the alternative method above
					//      switch( keyID )
					//      {
					//        case Keys.Up:
					//          u32HorOrVert = User32dll.WM_VSCROLL;
					//          if( ynBig == true )
					//            u32ScrollAction = User32dll.SB_PAGEUP;
					//          else
					//            u32ScrollAction = User32dll.SB_LINEUP;
					//          break;
					//        case Keys.Down:
					//          u32HorOrVert = User32dll.WM_VSCROLL;
					//          if( ynBig == true )
					//            u32ScrollAction = User32dll.SB_PAGEDOWN;
					//          else
					//            u32ScrollAction = User32dll.SB_LINEDOWN;
					//          break;
					//        case Keys.Left:
					//          u32HorOrVert = User32dll.WM_HSCROLL;
					//          if( ynBig == true )
					//            u32ScrollAction = User32dll.SB_PAGELEFT;
					//          else
					//            u32ScrollAction = User32dll.SB_LINELEFT;
					//          break;
					//        case Keys.Right:
					//          u32HorOrVert = User32dll.WM_HSCROLL;
					//          if( ynBig == true )
					//            u32ScrollAction = User32dll.SB_PAGERIGHT;
					//          else
					//            u32ScrollAction = User32dll.SB_LINERIGHT;
					//          break;
					//      }
					//
					//      User32dll.SendMessage( 
					//                              m_panPic.Handle,              // iptrHWND
					//                              u32HorOrVert,               // u32MsgID
					//                              (UIntPtr)u32ScrollAction,   // wParam     large or small increments
					//                              IntPtr.Zero );              // lParam
			}
		
			
			
			// ----------- P i c 1 S e l e c t i o n G e t _ b m a p ------------
			//
			///<summary>Procedure to return a bitmap object from the selected area in the m_pic1 control area.</summary>
			///<returns>void.</returns>
			///<remarks>Return a bitmap from the selected area in the picture box control. Uses the Win32 Gdi32.dll
			///to perform this function.</remarks>
			//
			// ------------------------------------------------------------------
			public Bitmap Pic1SelectionGet_bmap()
			{
				Graphics              gcPic1;      // a Graphics context object for our Pic1 control
				Graphics              gcBmap;
					IntPtr                iptrHdcPic1;
					IntPtr                iptrHdcBmap;
					Bitmap                bmapSelection;
					
					gcPic1 = m_pic1.CreateGraphics();
					// create a bitmap from the Width and Height of our selected area
					bmapSelection = new Bitmap( m_s32SelectW, m_s32SelectH, gcPic1 );
					
					// create a graphics object from the bitmap
					gcBmap = Graphics.FromImage( bmapSelection );
					
					// get a device contexts for the two objects
					iptrHdcPic1 = gcPic1.GetHdc();
					iptrHdcBmap = gcBmap.GetHdc();
					
					// bitblt the window to the bitmap
					Gdi32dll.BitBlt( iptrHdcBmap, 0, 0, m_s32SelectW, m_s32SelectH, iptrHdcPic1, m_ptStart.X, m_ptStart.Y, Gdi32dll.SRCCOPY );
					
					// release the device contexts
					gcBmap.ReleaseHdc( iptrHdcBmap );
					gcPic1.ReleaseHdc( iptrHdcPic1 );
					
					// dispose of the instantiated graphics objects
					gcBmap.Dispose();
					gcPic1.Dispose();
					
					// return the bitmap of the window
					return bmapSelection;			
			}
		
			
			//----------------- D e s k t o p G e t _ b m a p ------------------
			//
			///<summary>Procedure to return a bitmap object from the selected screen area.</summary>
			///<returns>Bitmap</returns>
			///<remarks>When the user selects an area of the screen and clicks save, this procedure
			///gets the area selected as a bitmap. Uses Win32 Gdi32.dll to do this.</remarks>
			//
			//------------------------------------------------------------------
			public static Bitmap DesktopGet_bmap()
			{
				Rectangle             rectScreen  = Rectangle.Empty;
					Screen[]              aScreens    = Screen.AllScreens;
					int                   s32XDst;
					int                   s32YDst;
					Graphics              gc;
					Bitmap                bmapScreens;
					IntPtr                iptrHdcDst;
					IntPtr                iptrHdcSrc;
					bool                  ynSuccess;
					System.ComponentModel.Win32Exception excpWin32;
					
					// Create a rectangle encompassing all screens...
					foreach( Screen scrnDesktop in aScreens )
					{
						rectScreen = Rectangle.Union( rectScreen, scrnDesktop.Bounds );
					}
				
					// Create a composite bitmap of the size of all screens...
					bmapScreens = new Bitmap( rectScreen.Width, rectScreen.Height );
					
					// Get a graphics object for the composite bitmap and initialize it...
					gc = Graphics.FromImage( bmapScreens );
					gc.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighSpeed;
					gc.FillRectangle(
							SystemBrushes.Desktop,
							0,
							0, 
							rectScreen.Width - rectScreen.X, 
							rectScreen.Height - rectScreen.Y);
					
					// Get an HDC for the composite area...
					iptrHdcDst = gc.GetHdc();
					
					// Now, loop through screens, 
					// Blting each to the composite HDC created above...
					foreach( Screen screen in aScreens )
					{
						// Create DC for each source monitor...
						iptrHdcSrc = Gdi32dll.CreateDC(
								IntPtr.Zero,
								screen.DeviceName,
								IntPtr.Zero,
								IntPtr.Zero);
							
							// Blt the source directly to the composite destination...
							s32XDst = screen.Bounds.X - rectScreen.X;
							s32YDst = screen.Bounds.Y - rectScreen.Y;
							
							ynSuccess = Gdi32dll.StretchBlt(
									iptrHdcDst,
									s32XDst,
									s32YDst, 
									screen.Bounds.Width, 
									screen.Bounds.Height, 
									iptrHdcSrc, 
									0, 
									0, 
									screen.Bounds.Width, 
									screen.Bounds.Height, 
									Gdi32dll.SRCCOPY );
							
							if( ynSuccess == false )
							{
								excpWin32 = new System.ComponentModel.Win32Exception();     
									Console.WriteLine( excpWin32 );
							}
						
							Gdi32dll.DeleteDC( iptrHdcSrc );    
					}
				
					// Cleanup destination HDC and Graphics...
					gc.ReleaseHdc( iptrHdcDst );
					gc.Dispose();
					
					// Return composite bitmap which will become our Form's PictureBox's image...
					return bmapScreens;
			}
		
			
			// ---------------- D r a w X O R R e c t a n g l e -----------------
			// 
			///<summary>Procedure to demonstrate the classic XOR box draw technique.</summary>
			///<param name='gcDst'>Graphics context of the area to be drawn to.</param>
			///<param name='s32Left'>Coordinate of the left of the drawn to area(X).</param>
			///<param name='s32Top'>Coordinate of the top of the drawn to area(Y).</param>
			///<param name='s32Right'>Coordinate of the right of the drawn to area(X + Width).</param>
			///<param name='s32Bottom'>Coordinate of the bottom of the drawn to area(Y + Height).</param>
			///<returns>void.</returns>
			///<remarks>This procedure employees the Win32 Gdi32.dll and draws an XOR rectangle
			/// employing the classic technique.</remarks>
			//
			//------------------------------------------------------------------
			public void DrawXORRectangle(
					Graphics              gcDst,
					int                   s32Left,
					int                   s32Top,
					int                   s32Right,
					int                   s32Bottom )
			{
				IntPtr                iptrHdcDst;
					IntPtr                iptrPenNew;
					IntPtr                iptrPenOld;
					IntPtr                iptrBrushOld;
					
					// Extract the Win32 HDC from the Graphics object supplied.
					iptrHdcDst = gcDst.GetHdc();
					
					// Create a pen with a dotted style to draw the border of the rectangle.
					iptrPenNew = Gdi32dll.CreatePen( Gdi32dll.PS_DOT, 1, 0 );  //0 = BLACK_PEN
				
					// Set the ROP to XOR.
					Gdi32dll.SetROP2( iptrHdcDst, Gdi32dll.R2_XORPEN );
					
					// Select the pen into the device context.
					iptrPenOld = Gdi32dll.SelectObject( iptrHdcDst, iptrPenNew );
					
					// Create a stock NULL_BRUSH brush and select it into the device
					// context so that the rectangle isn't filled.
					iptrBrushOld = Gdi32dll.SelectObject( iptrHdcDst,
							Gdi32dll.GetStockObject( Gdi32dll.NULL_BRUSH ) );
					
					// Now XOR the hollow rectangle on the Graphics object with a dotted outline.
					Gdi32dll.Rectangle( iptrHdcDst, s32Left, s32Top, s32Right, s32Bottom );
					
					// Put the old stuff back where it was.
					Gdi32dll.SelectObject( iptrHdcDst, iptrBrushOld ); // no need to delete a stock object
				Gdi32dll.SelectObject( iptrHdcDst, iptrPenOld );
					Gdi32dll.DeleteObject( iptrPenNew );    // but we do need to delete the pen
				
					// Return the device context to Windows.
					gcDst.ReleaseHdc( iptrHdcDst );
			}
		
			
			//-------------------- D r a g D r o p O p e n ---------------------
			//
			///<summary>Procedure to use the path and file from a drag and drop as the album reference.</summary>
			///<param name='strFile'>This is the path and file string of the newly selected image.</param>
			///<returns>void.</returns>
			///<remarks>There are Drag and drop routines for both the form and the image panel, so where ever
			///the user drops will work. This procedure is employed by both to switch the image reference.</remarks>
			//
			//------------------------------------------------------------------
			void DragDropOpen(
					string                strFile )
			{
				g_strSelectedPathFile = strFile;
					
					FileListInit( false );
					m_sfpScale = 1.00F;
					if( m_s32FileIXNext != -1 )
					{
						ImageSelectedShow( );
					}
				
			}
		
			//----------------- D r a g D r o p E x e c u t e ------------------
			//
			///<summary>Procedure to do the Drag Drop event.</summary>
			///<param name='e'>DragEventArgs event data.</param>
			///<returns>void.</returns>
			///<remarks>Since our drag drops are from the explorer, and the explorer
			///is effectively paused while we are responding to the drop event, we
			///will receive the data and call the processing procedure asynchronously
			///so the operation of the explorer will not be paused because of us.</remarks>
			//
			//------------------------------------------------------------------
			void DragDropExecute(
					System.Windows.Forms.DragEventArgs e )
			{
				Array           astrFileName;
					string          strPathFile;
					
					try
					{ // When file(s) are dragged from Explorer to the form,
						// IDataObject contains an array of file names.
						astrFileName = (Array)e.Data.GetData( DataFormats.FileDrop );
							
							if( astrFileName != null )
							{ // Extract string from first array element, ignore all the rest
								strPathFile = astrFileName.GetValue(0).ToString();
									
									// Explorer instance from which file is dropped is not responding
									// all the time when DragDrop handler is active, so we need to return
									// quickly in case our processing takes a long time. We will call 
									// DragDropOpen asynchronously.
									this.BeginInvoke( m_DelegateDragDropOpen, new Object[] {strPathFile} );
									// Now we immediately return to the Explorer
							}
						this.Activate();
					}
				catch( Exception excp )
				{
					m_spanInfo.Text = "Error in DragDrop function: " + excp.Message;
				}
			}
		
			//---------------- S c r e e n F u l l T o g g l e -----------------
			//
			///<summary>Procedure to toggle back and forth between full screen and normal window style.</summary>
			///<returns>void.</returns>
			///<remarks>This procedure toggles between a full screen display with no borders and what ever
			///size and position the display was before it was toggled to full screen.</remarks>
			//
			//------------------------------------------------------------------
			void ScreenFullToggle()
			{
				string[]          astrValues          = null;
					
					if( m_sbr1.Visible == true )
					{ // gonna go full screen
						m_sbr1.Visible = false;
							this.Menu = null;
							this.FormBorderStyle = FormBorderStyle.None;
							// save where we are now so we can return to it.
							ms_strWinPlacement = string.Format( "{0},{1},{2},{3}", 
									frmMain.Left, frmMain.Top, frmMain.Width, frmMain.Height ); 
							this.WindowState = FormWindowState.Maximized;
							m_panPic.Focus();
					}
					else
					{ // gonna go back to normal
						m_sbr1.Visible = true;
							this.Menu = this.mnuMain;
							this.FormBorderStyle = FormBorderStyle.Sizable;
							this.WindowState = FormWindowState.Normal;
							
							// recover where we were
							astrValues = ms_strWinPlacement.Split( ',' );
							frmMain.Left    = Convert.ToInt32( astrValues[0] );
							frmMain.Top     = Convert.ToInt32( astrValues[1] );
							frmMain.Width   = Convert.ToInt32( astrValues[2] );
							frmMain.Height  = Convert.ToInt32( astrValues[3] );
					}
			}
		
			private void mnuVireProperties_Click(object sender, System.EventArgs e)
			{
				PropertiesForm      frmProps;
					
					if( m_bmap == null )
					{
						return;
					}
				
					frmProps = new PropertiesForm( );
					frmProps.ShowDialog( this );
			}
		
			private void cmnuPic1Properties_Click(object sender, System.EventArgs e)
			{
				PropertiesForm      frmProps;
					
					if( m_bmap == null )
					{
						return;
					}
				frmProps = new PropertiesForm(  );
					
					frmProps.ShowDialog( this );
			}
		
	}  // End of MainForm Class
	
		///<summary>Comparitor class for sorting image file roots</summary>
		public class ImageNameSortClass : IComparer  
	{
		
			int IComparer.Compare( Object obj1, Object obj2 )  
			{
				string                strName1    = (string)obj1;
					string                strName2    = (string)obj2;
					
					strName1 = Path.GetFileNameWithoutExtension( strName1 );
					strName2 = Path.GetFileNameWithoutExtension( strName2 );
					
					return( (new CaseInsensitiveComparer()).Compare(  strName1, strName2 ) );
			}
		
	}
	
		///<summary>Publicly accessible constant values are defined in this class.</summary>
		///<remarks>Publicly accessible class of constants. These are defined for consistency between classes.</remarks>
		public class CONST
		{
			///<summary>Registry key ID string for image file to start with, last one viewed also.</summary>
			///<remarks>Set to a value of "Start Image".</remarks>
			public const string   REG_START_IMAGE  = "Start Image";
		}
}
