using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using AlbumSurfer;

namespace AlbumSurfer
{
	/// <summary>Definition of the Page0Uctrl Class.</summary>
  ///<remarks>This class definition defines the objects, methods and properties of the Page0Uctrl object.</remarks>
	public class Page0Uctrl : System.Windows.Forms.UserControl
	{
    ///<summary>Boolean object.</summary>
    ///<remarks>This object provides a mechanism for ignore layout changes during init.</remarks>
    public bool        m_ynSuspendLayout = true;  // our private version of SuspendLayout
    ///<summary>A form label for the storage of the page title.</summary>
    ///<remarks>Label for displaying user control title.</remarks>
    private System.Windows.Forms.Label m_lblPageTitle;
    ///<summary>Forms numeric up and down object.</summary>
    ///<remarks>This NumericUpDown provides a selection mechanism for the auto show time interval selection.</remarks>
    private System.Windows.Forms.NumericUpDown m_updwImageInterval;
    ///<summary>Forms label object providing a title to or interval adjustment control.</summary>
    ///<remarks>This object .</remarks>
    private System.Windows.Forms.Label m_lblUpDownTitle;
    ///<summary>Forms label object.</summary>
    ///<remarks>This object permits selection of multiple user control option pages.</remarks>
    private System.Windows.Forms.Label m_lblUpDownTag;

    ///<summary>Required designer variable.</summary>
    ///<remarks>Forms designer container for all our user control objects.</remarks>
    private System.ComponentModel.Container components = null;

    /// <summary>Class Constructor for Page1Uctr0.</summary>
    ///<remarks>This method calls the Windows Form InitializeComponent function to instantiate and
    ///initialize all of this class's objects.</remarks>
		public Page0Uctrl()
		{
			InitializeComponent();  // Windows instantiates and initializes all our wizard objects

		}

    /// <summary>Clean up any resources being used.</summary>
    ///<remarks>This method functions like a destructor except we must wait for garbage collection 
    ///before all objects are actually freed.</remarks>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		    #region Component Designer generated code
		    /// <summary> 
		    /// Required method for Designer support - do not modify 
		    /// the contents of this method with the code editor.
		    /// </summary>
		    private void InitializeComponent()
		    {
          this.m_lblPageTitle = new System.Windows.Forms.Label();
          this.m_updwImageInterval = new System.Windows.Forms.NumericUpDown();
          this.m_lblUpDownTitle = new System.Windows.Forms.Label();
          this.m_lblUpDownTag = new System.Windows.Forms.Label();
          ((System.ComponentModel.ISupportInitialize)(this.m_updwImageInterval)).BeginInit();
          this.SuspendLayout();
          // 
          // m_lblPageTitle
          // 
          this.m_lblPageTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
          this.m_lblPageTitle.Location = new System.Drawing.Point(8, 8);
          this.m_lblPageTitle.Name = "m_lblPageTitle";
          this.m_lblPageTitle.Size = new System.Drawing.Size(240, 23);
          this.m_lblPageTitle.TabIndex = 0;
          this.m_lblPageTitle.Text = "Page 0 User Control";
          // 
          // m_updwImageInterval
          // 
          this.m_updwImageInterval.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
          this.m_updwImageInterval.Increment = new System.Decimal(new int[] {
                                                                              100,
                                                                              0,
                                                                              0,
                                                                              0});
          this.m_updwImageInterval.Location = new System.Drawing.Point(32, 80);
          this.m_updwImageInterval.Maximum = new System.Decimal(new int[] {
                                                                            10000,
                                                                            0,
                                                                            0,
                                                                            0});
          this.m_updwImageInterval.Minimum = new System.Decimal(new int[] {
                                                                            100,
                                                                            0,
                                                                            0,
                                                                            0});
          this.m_updwImageInterval.Name = "m_updwImageInterval";
          this.m_updwImageInterval.Size = new System.Drawing.Size(72, 26);
          this.m_updwImageInterval.TabIndex = 1;
          this.m_updwImageInterval.Value = new System.Decimal(new int[] {
                                                                          100,
                                                                          0,
                                                                          0,
                                                                          0});
          // 
          // m_lblUpDownTitle
          // 
          this.m_lblUpDownTitle.Location = new System.Drawing.Point(8, 56);
          this.m_lblUpDownTitle.Name = "m_lblUpDownTitle";
          this.m_lblUpDownTitle.Size = new System.Drawing.Size(152, 16);
          this.m_lblUpDownTitle.TabIndex = 2;
          this.m_lblUpDownTitle.Text = "Interval between images:";
          // 
          // m_lblUpDownTag
          // 
          this.m_lblUpDownTag.Location = new System.Drawing.Point(104, 88);
          this.m_lblUpDownTag.Name = "m_lblUpDownTag";
          this.m_lblUpDownTag.TabIndex = 3;
          this.m_lblUpDownTag.Text = "milla seconds";
          // 
          // Page0Uctrl
          // 
          this.Controls.Add(this.m_lblUpDownTag);
          this.Controls.Add(this.m_lblUpDownTitle);
          this.Controls.Add(this.m_updwImageInterval);
          this.Controls.Add(this.m_lblPageTitle);
          this.Name = "Page0Uctrl";
          this.Size = new System.Drawing.Size(664, 408);
          this.VisibleChanged += new System.EventHandler(this.Page0Uctrl_VisibleChanged);
          ((System.ComponentModel.ISupportInitialize)(this.m_updwImageInterval)).EndInit();
          this.ResumeLayout(false);

        }
		    #endregion

    //------- P a g e 0 U c t r l _ V i s i b l e C h a n g e d --------
    //
    ///<summary>Handles the Visibility Changed event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>When the parent form tree view is clicked it make invisible the presently
    ///active user control and then visible the newly chosen one. These events indicate to
    ///to user control its status so that it can either save or refresh data that it controls.</remarks>
    //
    //------------------------------------------------------------------
    void Page0Uctrl_VisibleChanged(
      object                sender,
      System.EventArgs      e )
    {
      if( m_ynSuspendLayout == true )
      {
        return;
      }

      if( this.Visible == false )
      {
        MainForm.g_s32TimerInterval = (int)m_updwImageInterval.Value;
      }
      else // we have become visible, make sure our screen reflects the value of the data
      {
        m_updwImageInterval.Value = MainForm.g_s32TimerInterval;
      }
    }
	}
}
