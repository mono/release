using System;
using System.Runtime.InteropServices;

using HANDLE = System.IntPtr;
using HWND = System.IntPtr;
using HDC = System.IntPtr;

[StructLayout(LayoutKind.Sequential)]
struct SCROLLINFO
{
    public UInt32     u32CbSize;    // 7 * 4 = 28
    public UInt32     u32FMask;     // bit field of valid values in structure
    public Int32      s32Min;       // scroll bars minimum value
    public Int32      s32Max; 
    public UInt32     u32Page;      // how much of the total scroll area is visible 
    public Int32      s32Pos;       // the current scroll position
    public Int32      s32TrackPos;  // current thumb position 
}

sealed class User32dll
{
  public const int  SB_HORZ             =  0;
  public const int  SB_VERT             =  1;
  public const int  SB_CTL              =  2;
  public const int  SB_BOTH             =  3;

  // SCROLLINFO mask field value data bits
  public const int  SIF_RANGE           =  0x01;
  public const int  SIF_PAGE            =  0x02;
  public const int  SIF_POS             =  0x04;
  public const int  SIF_TRACKPOS        =  0x10;
  public const int  SIF_ALL             = SIF_RANGE | SIF_PAGE | SIF_POS | SIF_TRACKPOS;

  public const int WM_HSCROLL           = 0x0114;
  public const int WM_VSCROLL           = 0x0115;
  // SendMsgs WM_HSCROLL and WM_VSCROLL argument values
  public const int  SB_LINEUP           =  0;
  public const int  SB_LINELEFT         =  0;
  public const int  SB_LINEDOWN         =  1;
  public const int  SB_LINERIGHT        =  1;
  public const int  SB_PAGEUP           =  2;
  public const int  SB_PAGELEFT         =  2;
  public const int  SB_PAGEDOWN         =  3;
  public const int  SB_PAGERIGHT        =  3;
  public const int  SB_THUMBPOSITION    =  4;
  public const int  SB_THUMBTRACK       =  5;
  public const int  SB_TOP              =  6;
  public const int  SB_LEFT             =  6;
  public const int  SB_BOTTOM           =  7;
  public const int  SB_RIGHT            =  7;
  public const int  SB_ENDSCROLL        =  8;


  public const int WM_MOUSEWHEEL        = 0x020A;
  public const int WM_NCCALCSIZE        = 0x0083;
  public const int WM_PAINT             = 0x000F;
  public const int WM_SIZE              = 0x0005;

  private const uint  ESB_DISABLE_BOTH  = 0x3;
  private const uint  ESB_ENABLE_BOTH   = 0x0;

  private const int  MK_LBUTTON         = 0x01;
  private const int  MK_RBUTTON         = 0x02;
  private const int  MK_SHIFT           = 0x04;
  private const int  MK_CONTROL         = 0x08;
  private const int  MK_MBUTTON         = 0x10; 
  private const int  MK_XBUTTON1        = 0x0020;
  private const int  MK_XBUTTON2        = 0x0040;

  [DllImport("user32.dll")]
  public static extern IntPtr SendMessage(
    IntPtr        iptrHWnd, 
    uint          u32MsgID, 
    UIntPtr       wParam, 
    IntPtr        lParam );

  [DllImport("user32.dll")]
  static public extern bool EnableScrollBar(System.IntPtr hWnd, uint wSBflags, uint wArrows);

  [DllImport("user32.dll")]
  static public extern int GetScrollPos(System.IntPtr hWnd, int nBar);

  [DllImport("user32.dll", CharSet=CharSet.Auto)]
  static public extern int GetSystemMetrics(int code);

  [DllImport("user32.dll")]
  static public extern int SetScrollPos(System.IntPtr hWnd, int nBar, int nPos, bool bRedraw);

  [DllImport("user32.dll")]
  static public extern int SetScrollRange(System.IntPtr hWnd, int nBar, int nMinPos, int nMaxPos, bool bRedraw);

  [DllImport("user32.dll")]
  static public extern bool ShowScrollBar(System.IntPtr hWnd, int wBar, bool bShow);

  [DllImport("user32.dll")] 
  public static extern int GetScrollInfo( HWND hwnd, int s32BarID, out SCROLLINFO lpScrollInfo);

  [DllImport("user32.dll")] 
  public static extern int SetScrollInfo( HWND hwnd, int s32BarID, ref SCROLLINFO lpScrollInfo, bool bRedraw);
}

[StructLayout(LayoutKind.Sequential)]
struct TEXTMETRIC
{
  public Int32    tmHeight;
  public Int32    tmAscent;
  public Int32    tmDescent;
  public Int32    tmInternalLeading;
  public Int32    tmExternalLeading;
  public Int32    tmAveCharWidth;
  public Int32    tmMaxCharWidth;
  public Int32    tmWeight;
  public Int32    tmOverhang;
  public Int32    tmDigitizedAspectX;
  public Int32    tmDigitizedAspectY;
  public Char     tmFirstChar;
  public Char     tmLastChar;
  public Char     tmDefaultChar;
  public Char     tmBreakChar;
  public Byte     tmItalic;
  public Byte     tmUnderlined;
  public Byte     tmStruckOut;
  public Byte     tmPitchAndFamily;
  public Byte     tmCharSet;
}

[StructLayout(LayoutKind.Sequential)]
struct RECT
{
  public Int32    left;
  public Int32    top;
  public Int32    right;
  public Int32    bottom;
}

sealed class Gdi32dll
{
  public const Int32 TRANSPARENT        =   1;

  public const Int32 FW_DONTCARE        =   0;
  public const Int32 FW_THIN            = 100;
  public const Int32 FW_EXTRALIGHT      = 200;
  public const Int32 FW_ULTRALIGHT      = 200;
  public const Int32 FW_LIGHT           = 300;
  public const Int32 FW_NORMAL          = 400;
  public const Int32 FW_REGULAR         = 400;
  public const Int32 FW_MEDIUM          = 500;
  public const Int32 FW_SEMIBOLD        = 600;
  public const Int32 FW_DEMIBOLD        = 600;
  public const Int32 FW_BOLD            = 700;
  public const Int32 FW_EXTRABOLD       = 800;
  public const Int32 FW_ULTRABOLD       = 800;
  public const Int32 FW_HEAVY           = 900;
  public const Int32 FW_BLACK           = 900;

  public const Int32 ANSI_CHARSET       = 0;
  public const Int32 DEFAULT_CHARSET    = 1;
  public const Int32 SYMBOL_CHARSET     = 2;

  public const Int32 OUT_DEFAULT_PRECIS = 0;

  public const Int32 CLIP_DEFAULT_PRECIS  = 0;

  public const Int32 DEFAULT_QUALITY    = 0;
  public const Int32 FF_DONTCARE        = (0<<4);

  // Pen Styles
  public const Int32 PS_SOLID           = 0;
  public const Int32 PS_DASH            = 1;
  public const Int32 PS_DOT             = 2;
  public const Int32 PS_DASHDOT         = 3;
  public const Int32 PS_DASHDOTDOT      = 4;

  // BinaryRasterOperations
  public const Int32 R2_BLACK           =  1;    // 0
  public const Int32 R2_NOTMERGEPEN     =  2;    // DPon
  public const Int32 R2_MASKNOTPEN      =  3;    // DPna
  public const Int32 R2_NOTCOPYPEN      =  4;    // PN
  public const Int32 R2_MASKPENNOT      =  5;    // PDna
  public const Int32 R2_NOT             =  6;    // Dn
  public const Int32 R2_XORPEN          =  7;    // DPx
  public const Int32 R2_NOTMASKPEN      =  8;    // DPan
  public const Int32 R2_MASKPEN         =  9;    // DPa
  public const Int32 R2_NOTXORPEN       = 10;    // DPxn
  public const Int32 R2_NOP             = 11;    // D
  public const Int32 R2_MERGENOTPEN     = 12;    // DPno
  public const Int32 R2_COPYPEN         = 13;    // P
  public const Int32 R2_MERGEPENNOT     = 14;    // PDno
  public const Int32 R2_MERGEPEN        = 15;    // DPo
  public const Int32 R2_WHITE           = 16;    //  1
  public const Int32 R2_LAST            = 16;

  //TernaryRasterOperations
  public const UInt32 SRCCOPY           = 0x00CC0020;   // dst = src
  public const UInt32 SRCPAINT          = 0x00EE0086;   // dst = src OR dst
  public const UInt32 SRCAND            = 0x008800C6;   // dst = src AND dst
  public const UInt32 SRCINVERT         = 0x00660046;   // dst = src XOR dst
  public const UInt32 SRCERASE          = 0x00440328;   // dst = src AND (NOT dst )
  public const UInt32 NOTSRCCOPY        = 0x00330008;   // dst = (NOT src)
  public const UInt32 NOTSRCERASE       = 0x001100A6;   // dst = (NOT src) AND (NOT dst)
  public const UInt32 MERGECOPY         = 0x00C000CA;   // dst = (src AND pattern)
  public const UInt32 MERGEPAINT        = 0x00BB0226;   // dst = (NOT src) OR dst
  public const UInt32 PATCOPY           = 0x00F00021;   // dst = pattern
  public const UInt32 PATPAINT          = 0x00FB0A09;   // dst = DPSnoo
  public const UInt32 PATINVERT         = 0x005A0049;   // dst = pattern XOR dst
  public const UInt32 DSTINVERT         = 0x00550009;   // dst = (NOT dst)
  public const UInt32 BLACKNESS         = 0x00000042;   // dst = BLACK
  public const UInt32 WHITENESS         = 0x00FF0062;   // dst = WHITE
                                                   
  public const Int32 WHITE_BRUSH          = 0;
  public const Int32 LTGRAY_BRUSH         = 1;
  public const Int32 GRAY_BRUSH           = 2;
  public const Int32 DKGRAY_BRUSH         = 3;
  public const Int32 BLACK_BRUSH          = 4;
  public const Int32 NULL_BRUSH           = 5;
  public const Int32 HOLLOW_BRUSH         = NULL_BRUSH;
  public const Int32 WHITE_PEN            = 6;
  public const Int32 BLACK_PEN            = 7;
  public const Int32 NULL_PEN             = 8;
  public const Int32 OEM_FIXED_FONT       = 10;
  public const Int32 ANSI_FIXED_FONT      = 11;
  public const Int32 ANSI_VAR_FONT        = 12;
  public const Int32 SYSTEM_FONT          = 13;
  public const Int32 DEVICE_DEFAULT_FONT  = 14;
  public const Int32 DEFAULT_PALETTE      = 15;
  public const Int32 SYSTEM_FIXED_FONT    = 16;

  public static UInt32 RGB( Byte u8Red, Byte u8Green, Byte u8Blue )
  {
    UInt32            u32Color;

    u32Color =  (UInt32)u8Red;
    u32Color |= (UInt32)((Int32)u8Green << 8);
    u32Color |= (UInt32)((Int32)u8Blue << 16);
    return u32Color;
  }
    
  [DllImport("GDI32.DLL")]
  public static extern Boolean BitBlt(
    IntPtr          iptrHdcDst,
    int             s32LeftDst, 
    int             s32TopDst,
    int             s32WidthDst,
    int             s32HeighDst,
    IntPtr          iptrHdcSrc,
    int             s32LeftSrc, 
    int             s32TopSrc,
    uint            u32Rop );

  [DllImport("GDI32.DLL")]
  public static extern IntPtr CreateCompatibleBitmap(
    IntPtr          iptrHdc, 
    Int32           s32Width,
    Int32           s32Height );
  
  [DllImport("GDI32.DLL")]
  public static extern IntPtr CreateCompatibleDC(
    IntPtr          iptrHdc );
  
  [DllImport("GDI32.DLL")]
  public static extern IntPtr CreateDC(
    IntPtr          iptrLpszDriver,
    string          strLpszDevice,
    IntPtr          ipreLpszOutput,
    IntPtr          iptrLpInitData );

  [DllImport("GDI32.DLL")]
  public static extern IntPtr CreateFont(
    Int32           s32Height, 
    Int32           s32Width,
    Int32           s32Escapement,
    Int32           s32Orientation,
    Int32           s32Weight,
    UInt32          u32Italic,
    UInt32          u32Underline,
    UInt32          u32Strikeout,
    UInt32          u32Charset,
    UInt32          u32OutputPrecision,
    UInt32          u32ClipPrecision,
    UInt32          u32Quality,
    UInt32          u32PitchAndFamily,
    String          strFace );

  [DllImport("GDI32.DLL")]
  public static extern IntPtr CreatePen(
    int             s32PenStyle,     // Pen style PS_SOLID, ...
    int             s32Width,        // Width of pen
    int             s32Color );      // Color of pen

  [DllImport("GDI32.DLL")]
  public static extern Boolean DeleteDC(
    IntPtr          iptrHdc );

  [DllImport("GDI32.DLL")]
  public static extern bool DeleteObject(
    IntPtr          hObject );     // Win32 GDI handle to object to delete

  [DllImport("GDI32.DLL")]
  public static extern Boolean Ellipse(
    IntPtr          iptrHdc,
    Int32           s32Left,
    Int32           s32Top,
    Int32           s32Right,
    Int32           s32Bottom );

  [DllImport("GDI32.DLL")]
  public static extern Int32 FillRect(
    IntPtr          iptrHdc,
    ref RECT        rect,
    IntPtr          iptrHbr );

  [DllImport("GDI32.DLL")]
  public static extern Boolean GetCharWidth(
    IntPtr          iptrHdc,
    Int32           s32FirstChar,
    Int32           s32LastChar,
    Int32[]         as32Widths );

  [DllImport("GDI32.DLL")]
  public static extern Int32 GetROP2(
    IntPtr          iptrHdc );

  [DllImport("GDI32.DLL")]
  public static extern IntPtr GetStockObject(
    int             s32BrushStyle );     // Selected from the WinGDI.h BrushStyles enum


  [DllImport("GDI32.DLL")]
  public static extern Boolean GetTextMetrics(
    IntPtr          iptrHdc,
    ref TEXTMETRIC  tm );

  [DllImport("GDI32.DLL")]
  public static extern Boolean LineTo(
    IntPtr          iptrHdc,
    Int32           s32XEnd,
    Int32           s32YEnd );

  [DllImport("GDI32.DLL")]
  public static extern Boolean MoveToEx(
    IntPtr          iptrHdc,
    Int32           s32Left,
    Int32           s32Top,
    ref System.Drawing.Point oldPos );

  [DllImport("GDI32.DLL")]
  public static extern Boolean PatBlt(
    IntPtr          iptrHdc,
    Int32           s32Left,
    Int32           s32Top,
    Int32           s32Width,
    Int32           s32Height,
    UInt32          u32rop );

  [DllImport("GDI32.DLL")]
  public static extern void Rectangle(
    IntPtr          iptrHdc,
    int             s32Top,
    int             s32Left,
    int             s32Right,
    int             s32Bottom );

  [DllImport("GDI32.DLL")]
  public static extern Int32 RestoreDC(
    IntPtr          iptrHdc,
    Int32           s32SavedDC );

  [DllImport("GDI32.DLL")]
  public static extern Int32 SaveDC(
    IntPtr          iptrHdc );

  [DllImport("GDI32.DLL")]
  public static extern IntPtr SelectObject(
    IntPtr          iptrHdc,        // Win32 GDI device context
    IntPtr          iptrHObject );  // Win32 GDI handle to object to select

  [DllImport("GDI32.DLL")]
  public static extern Int32 SetBkMode(
    IntPtr          iptrHdc,
    Int32           s32Mode );

  [DllImport("GDI32.DLL")]
  public static extern UInt32 SetPixel(
    IntPtr          iptrHdc,
    Int32           s32Left,
    Int32           s32Top,
    UInt32          u32Color );

  [DllImport("GDI32.DLL")]
  public static extern int SetROP2(
    IntPtr          iptrHdc,        // Handle to a Win32 device context
    int             s32DrawMode );   // Drawing mode

  [DllImport("GDI32.DLL")]
  public static extern bool StretchBlt(
    IntPtr          iptrHdcDst,
    int             s32LeftDst,
    int             s32TopDst,
    int             s32WidthDst,
    int             s32HeightDst,
    IntPtr          iptrGdcSrc,
    int             s32LeftSrc,
    int             s32TopSrc,
    int             s32WidthSrc,
    int             s32HeightSrc,
    uint            u32Rop );

  [DllImport("GDI32.DLL")]
  public static extern Boolean TextOut(
    IntPtr          iptrHdc,
    Int32           s32Left,
    Int32           s32Top,
    String          strText,
    Int32           s32Count );
}

