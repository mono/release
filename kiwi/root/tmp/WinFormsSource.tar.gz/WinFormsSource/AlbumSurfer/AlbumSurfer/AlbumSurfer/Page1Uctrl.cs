using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace AlbumSurfer
{
	/// <summary>Definition of the Page1Uctrl Class.</summary>
	///<remarks>This class definition defines the objects, methods and properties of the Page1Uctrl object.</remarks>
	public class Page1Uctrl : System.Windows.Forms.UserControl
	{
    ///<summary>Boolean to ignore layout during initialization.</summary>
    ///<remarks>This object provides a mechanism for ignore layout changes during init. Its public so the 
    ///parent container can tell indicate when it has stop setting initial values</remarks>
    public bool        m_ynSuspendLayout = true;  // our private version of SuspendLayout
    ///<summary>A form label for the storage of the page title.</summary>
    ///<remarks>Label for displaying user control title.</remarks>
    private System.Windows.Forms.Label m_lblPageTitle;
    ///<summary>A group box container for the Jpeg quality controls.</summary>
    ///<remarks>This group box contain all the control object which permit adjustment of Jpeg save quality.</remarks>
    private System.Windows.Forms.GroupBox m_gbxJpgSaveQuality;
    ///<summary>A track bar for fine adjustment of Jpeg save quality.</summary>
    ///<remarks>This track bar permits adjustment of the Jpeg save quality factor on a fine level.</remarks>
    private System.Windows.Forms.TrackBar m_tbar;
    ///<summary>A form label for the storage of the Jpeg save quality percentage.</summary>
    ///<remarks>Label for displaying the Jpeg save quality percentage..</remarks>
    private System.Windows.Forms.Label m_lblTbarValue;
    ///<summary>A form button for the quick selection of a Jpeg save quality percentage of 100%.</summary>
    ///<remarks>Button for selecting a Jpeg save quality of 100%.</remarks>
    private System.Windows.Forms.Button m_btn100;
    ///<summary>A form button for the quick selection of a Jpeg save quality percentage of 76%.</summary>
    ///<remarks>Button for selecting a Jpeg save quality of 75%.</remarks>
    private System.Windows.Forms.Button m_btn75;
    ///<summary>A form button for the quick selection of a Jpeg save quality percentage of 50%.</summary>
    ///<remarks>Button for selecting a Jpeg save quality of 50%.</remarks>
    private System.Windows.Forms.Button m_btn50;
    ///<summary>A form button for the quick selection of a Jpeg save quality percentage of 25%.</summary>
    ///<remarks>Button for selecting a Jpeg save quality of 25%.</remarks>
    private System.Windows.Forms.Button m_btn25;
    /// <summary> Required designer variable.</summary>
    ///<remarks>Forms designer container for all our user control objects.</remarks>
    private System.ComponentModel.Container components = null;

    /// <summary>Class Constructor for Page1Uctrl.</summary>
    ///<remarks>This method calls the Windows Form InitializeComponent function to instantiate and
    ///initialize all of this class's objects.</remarks>
		public Page1Uctrl()
		{
			InitializeComponent();   // Windows instantiates and initializes all our objects

			// TODO: Add any initialization after the InitializeComponent call
		}

		/// <summary>Clean up any resources being used.</summary>
		///<remarks>This method functions like a destructor except we must wait for garbage collection 
		///before all objects are actually freed.</remarks>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		    #region Component Designer generated code
		    /// <summary> 
		    /// Required method for Designer support - do not modify 
		    /// the contents of this method with the code editor.
		    /// </summary>
		    private void InitializeComponent()
		    {
          this.m_lblPageTitle = new System.Windows.Forms.Label();
          this.m_gbxJpgSaveQuality = new System.Windows.Forms.GroupBox();
          this.m_btn25 = new System.Windows.Forms.Button();
          this.m_btn50 = new System.Windows.Forms.Button();
          this.m_btn75 = new System.Windows.Forms.Button();
          this.m_btn100 = new System.Windows.Forms.Button();
          this.m_lblTbarValue = new System.Windows.Forms.Label();
          this.m_tbar = new System.Windows.Forms.TrackBar();
          this.m_gbxJpgSaveQuality.SuspendLayout();
          ((System.ComponentModel.ISupportInitialize)(this.m_tbar)).BeginInit();
          this.SuspendLayout();
          // 
          // m_lblPageTitle
          // 
          this.m_lblPageTitle.AccessibleName = "";
          this.m_lblPageTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
          this.m_lblPageTitle.Location = new System.Drawing.Point(8, 8);
          this.m_lblPageTitle.Name = "m_lblPageTitle";
          this.m_lblPageTitle.Size = new System.Drawing.Size(240, 23);
          this.m_lblPageTitle.TabIndex = 0;
          this.m_lblPageTitle.Text = "Page 1 User Control";
          // 
          // m_gbxJpgSaveQuality
          // 
          this.m_gbxJpgSaveQuality.Controls.Add(this.m_btn25);
          this.m_gbxJpgSaveQuality.Controls.Add(this.m_btn50);
          this.m_gbxJpgSaveQuality.Controls.Add(this.m_btn75);
          this.m_gbxJpgSaveQuality.Controls.Add(this.m_btn100);
          this.m_gbxJpgSaveQuality.Controls.Add(this.m_lblTbarValue);
          this.m_gbxJpgSaveQuality.Controls.Add(this.m_tbar);
          this.m_gbxJpgSaveQuality.Location = new System.Drawing.Point(16, 48);
          this.m_gbxJpgSaveQuality.Name = "m_gbxJpgSaveQuality";
          this.m_gbxJpgSaveQuality.Size = new System.Drawing.Size(128, 232);
          this.m_gbxJpgSaveQuality.TabIndex = 1;
          this.m_gbxJpgSaveQuality.TabStop = false;
          this.m_gbxJpgSaveQuality.Text = "Jpeg Save Quality";
          // 
          // m_btn25
          // 
          this.m_btn25.Location = new System.Drawing.Point(8, 160);
          this.m_btn25.Name = "m_btn25";
          this.m_btn25.Size = new System.Drawing.Size(48, 23);
          this.m_btn25.TabIndex = 10;
          this.m_btn25.Text = "25%";
          this.m_btn25.Click += new System.EventHandler(this.m_btn25_Click);
          // 
          // m_btn50
          // 
          this.m_btn50.Location = new System.Drawing.Point(8, 112);
          this.m_btn50.Name = "m_btn50";
          this.m_btn50.Size = new System.Drawing.Size(48, 23);
          this.m_btn50.TabIndex = 9;
          this.m_btn50.Text = "50%";
          this.m_btn50.Click += new System.EventHandler(this.m_btn50_Click);
          // 
          // m_btn75
          // 
          this.m_btn75.Location = new System.Drawing.Point(8, 64);
          this.m_btn75.Name = "m_btn75";
          this.m_btn75.Size = new System.Drawing.Size(48, 23);
          this.m_btn75.TabIndex = 8;
          this.m_btn75.Text = "75%";
          this.m_btn75.Click += new System.EventHandler(this.m_btn75_Click);
          // 
          // m_btn100
          // 
          this.m_btn100.Location = new System.Drawing.Point(8, 24);
          this.m_btn100.Name = "m_btn100";
          this.m_btn100.Size = new System.Drawing.Size(48, 23);
          this.m_btn100.TabIndex = 7;
          this.m_btn100.Text = "100%";
          this.m_btn100.Click += new System.EventHandler(this.m_btn100_Click);
          // 
          // m_lblTbarValue
          // 
          this.m_lblTbarValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
          this.m_lblTbarValue.Location = new System.Drawing.Point(64, 200);
          this.m_lblTbarValue.Name = "m_lblTbarValue";
          this.m_lblTbarValue.Size = new System.Drawing.Size(40, 23);
          this.m_lblTbarValue.TabIndex = 6;
          this.m_lblTbarValue.Text = "75";
          this.m_lblTbarValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
          // 
          // m_tbar
          // 
          this.m_tbar.LargeChange = 10;
          this.m_tbar.Location = new System.Drawing.Point(64, 16);
          this.m_tbar.Maximum = 100;
          this.m_tbar.Minimum = 15;
          this.m_tbar.Name = "m_tbar";
          this.m_tbar.Orientation = System.Windows.Forms.Orientation.Vertical;
          this.m_tbar.Size = new System.Drawing.Size(45, 184);
          this.m_tbar.SmallChange = 5;
          this.m_tbar.TabIndex = 2;
          this.m_tbar.TickFrequency = 5;
          this.m_tbar.Value = 75;
          this.m_tbar.ValueChanged += new System.EventHandler(this.m_tbar_ValueChanged);
          // 
          // Page1Uctrl
          // 
          this.Controls.Add(this.m_gbxJpgSaveQuality);
          this.Controls.Add(this.m_lblPageTitle);
          this.Name = "Page1Uctrl";
          this.Size = new System.Drawing.Size(608, 320);
          this.VisibleChanged += new System.EventHandler(this.Page1Uctrl_VisibleChanged);
          this.m_gbxJpgSaveQuality.ResumeLayout(false);
          ((System.ComponentModel.ISupportInitialize)(this.m_tbar)).EndInit();
          this.ResumeLayout(false);

        }
		    #endregion

    //------- P a g e 1 U c t r l _ V i s i b l e C h a n g e d --------
    //
    ///<summary>Handles the Visibility Changed event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>When the parent form tree view is clicked it make invisible the presently
    ///active user control and then visible the newly chosen one. These events indicate to
    ///to user control its status so that it can either save or refresh data that it controls.</remarks>
    //
    //------------------------------------------------------------------
    void Page1Uctrl_VisibleChanged(
      object                sender,
      System.EventArgs      e )
    {
      if( m_ynSuspendLayout == true )
      {
        return;
      }

      if( this.Visible == false )  // We are going away, we might have to save something we manage
      {
        MainForm.ms_s32JpegSaveQuality = m_tbar.Value;
      }
      else // we have become visible, make sure our screen reflects the value of the data
      {
         m_tbar.Value = MainForm.ms_s32JpegSaveQuality ;
      }
    }

    //------------- m _ t b a r _ V a l u e C h a n g e d --------------
    //
    ///<summary>Handles the tbar Value changed event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>The user is sliding the tbar handle and we will display the value
    ///in numbers that reflects their change.</remarks>
    //
    //------------------------------------------------------------------
    void m_tbar_ValueChanged(
      object                sender,
      System.EventArgs      e )
    {
      m_lblTbarValue.Text = m_tbar.Value.ToString();
    }

    //------------------ m _ b t n 1 0 0 _ C l i c k -------------------
    //
    ///<summary>Handles the tbar group 100% button click event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>This button permits quick selection of a Jpeg quality of 100%.</remarks>
    //
    //------------------------------------------------------------------
    void m_btn100_Click(
      object                sender,
      System.EventArgs      e )
    {
        m_tbar.Value = 100;
    }

    //------------------- m _ b t n 7 5 _ C l i c k --------------------
    //
    ///<summary>Handles the tbar group 75% button click event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>This button permits quick selection of a Jpeg quality of 75%.</remarks>
    //
    //------------------------------------------------------------------
    void m_btn75_Click(
      object                sender,
      System.EventArgs      e )
    {
          m_tbar.Value = 75;
    }

    //------------------- m _ b t n 5 0 _ C l i c k --------------------
    //
    ///<summary>Handles the tbar group 50% button click event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>This button permits quick selection of a Jpeg quality of 50%.</remarks>
    //
    //------------------------------------------------------------------
    void m_btn50_Click(
      object                sender,
      System.EventArgs      e )
    {
     m_tbar.Value = 50;
    }

    //------------------- m _ b t n 2 5 _ C l i c k --------------------
    //
    ///<summary>Handles the tbar group 25% button click event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>This button permits quick selection of a Jpeg quality of 25%.</remarks>
    //
    //------------------------------------------------------------------
    void m_btn25_Click(
      object                sender,
      System.EventArgs      e )
    {
      m_tbar.Value = 25;
    }
	}
}
