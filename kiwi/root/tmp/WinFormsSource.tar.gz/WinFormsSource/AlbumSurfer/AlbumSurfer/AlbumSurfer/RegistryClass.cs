// 05.05.19.19 completed comment work
using System;
using Microsoft.Win32;  // for registry stuff;
using System.Text;
using System.Windows.Forms;  // for MessageBox

namespace AlbumSurfer
{
  // What follows is a dot net adaptation of a VS6 interface that was created
  // a long time ago in a galaxy far away. The structure below is representative
  // of that compatibility and may not reflect general best practices.
  // It does how ever get the job done nicely!

  ///<summary>Enum group for Registry Hives.</summary>
  ///<remarks>CLASSES_ROOT and USERS are not included in the Hive options of this class.</remarks>
  public enum E_REGISTRY_HIVES
  {
    //CLASSES_ROOT       // 0x80000000
    /// <summary>Current User Registry Hive.</summary>
    CURRENT_USER,      // 0x80000001
    /// <summary>Local Machine Registry Hive (default).</summary>
    LOCAL_MACHINE,     // 0x80000002
    //USERS              // 0x80000003
  }

  // The registry storage tree for software is usually
  // HIVE\Software\<company name>\<application name>\<section name>\<value name>.
  // This provides for unique settings for each user, to make settings that everybody shares on the computer
  // use HKEY_LOCAL_MACHINE\Software\<company name>\<application name>\<section name>\<value name>
  //private const int ERROR_SUCCESS = 0;
  //private const int ERROR_NO_MORE_ITEMS = 259;
  //private const int MAX_PATH = 260;

  //private const int REG_NONE                = 0 //No value type;
  //private const int REG_SZ                  = 1 //Unicode null terminated string;
  //private const int REG_EXPAND_SZ           = 2 //Unicode null terminated string (with environment variable references);
  //private const int REG_BINARY              = 3 //Free form binary;
  //private const int REG_DWORD               = 4 //32-bit number;
  //private const int REG_DWORD_LITTLE_ENDIAN = 4 //32-bit number (same as REG_DWORD);
  //private const int REG_DWORD_BIG_ENDIAN    = 5 //32-bit number;
  //private const int REG_LINK                = 6 //Symbolic Link (unicode);
  //private const int REG_MULTI_SZ            = 7 //Multiple Unicode strings;
  //private const int REG_RESOURCE_LIST       = 8 //Resource list in the resource map;
  //private const int REG_FULL_RESOURCE_DESCRIPTOR = 9 //Resource list in the hardware description;

  //private const int REG_CREATED_NEW_KEY     = &H1;
  //private const int REG_OPENED_EXISTING_KEY = &H2;
  //private const int REG_OPTION_BACKURESTORE = 4;
  //private const int REG_OPTION_NON_VOLATILE = 0 // Persist through a reboot;
  //private const int REG_OPTION_VOLATILE     = 1 // go away on a reboot;

  //private const int STANDARD_RIGHTS_ALL      = &H1F0000;
  //private const int STANDARD_RIGHTS_EXECUTE  = &H20000;
  //private const int STANDARD_RIGHTS_READ     = &H20000;
  //private const int STANDARD_RIGHTS_REQUIRED = &HF0000;
  //private const int STANDARD_RIGHTS_WRITE    = &H20000;
  //private const int SYNCHRONIZE              = &H100000;
  //private const int KEY_CREATE_LINK          = &H20;
  //private const int KEY_CREATE_SUB_KEY       = &H4;
  //private const int KEY_ENUMERATE_SUB_KEYS   = &H8;
  //private const int KEY_EVENT                = &H1;
  //private const int KEY_NOTIFY               = &H10;
  //private const int KEY_QUERY_VALUE          = &H1;
  //private const int KEY_SET_VALUE            = &H2;
  //private const int KEY_WRITE = (STANDARD_RIGHTS_WRITE || KEY_SET_VALUE || KEY_CREATE_SUB_KEY) && ! SYNCHRONIZE;
  //private const int KEY_READ = (STANDARD_RIGHTS_READ || KEY_QUERY_VALUE || KEY_ENUMERATE_SUB_KEYS || KEY_NOTIFY) && ! SYNCHRONIZE;
  //private const int KEY_EXECUTE = KEY_READ;
  //private const int KEY_ALL_ACCESS = (STANDARD_RIGHTS_ALL || KEY_QUERY_VALUE || KEY_SET_VALUE || KEY_CREATE_SUB_KEY || KEY_ENUMERATE_SUB_KEYS || KEY_NOTIFY || KEY_CREATE_LINK) && ! SYNCHRONIZE;
  //  Written By: Mel Schehlein  -  May 12, 2005
 
  ///<summary>Class for the storage and retrieval of persistent application values to the Registry.</summary>
  /// <remarks>This class if a wrapper for the standard dotNet interface to the Registry. It permits
  /// the invocation of the registry with some very simple calls. It defaults, unless overridden by the user
  /// the registry path to values obtained from the Application Assembly in the form of
  ///<para> REGISTRY_HIVE "SOFTWARE/Application.CompanyName/Application.ProductName/CONFIG".</para></remarks>
  public class RegistryClass
  {
    // class variables for property values {
    /// <summary>Class storage location for selected Registry HiveID.</summary>
    /// <remarks>When access to read or write any value is initiated this is the registry Hive to access.</remarks>
    private E_REGISTRY_HIVES  m_lngHiveID  = E_REGISTRY_HIVES.LOCAL_MACHINE;
    /// <summary>Class storage location for selected Registry Root string.</summary>
    /// <remarks>Defaulted to "Software". The full registry key path is constructed of "Root/Shop/AppName/Section".</remarks>
    private string            m_strRoot    = "Software";
    /// <summary>Class storage location for selected Registry Shop string.</summary>
    /// <remarks>Defaulted to App.CompanyName. The full registry key path is constructed of "Root/Shop/AppName/Section".</remarks>
    private string            m_strShop    = Application.CompanyName;
    /// <summary>Class storage location for selected Registry Application string.</summary>
    /// <remarks>Defaulted to App.ProductName;. The full registry key path is constructed of "Root/Shop/AppName/Section".</remarks>
    private string            m_strAppName = Application.ProductName;
    /// <summary>Class storage location for selected Registry Section string.</summary>
    /// <remarks>Defaulted to "Config". The full registry key path is constructed of "Root/Shop/AppName/Section".</remarks>
    private string            m_strSection = "Config";
    /// <summary>Class storage location for the selected full Registry Key path string.</summary>
    /// <remarks>The full registry key path is constructed of "Root/Shop/AppName/Section".</remarks>
    private string            m_strFullPath; //m_strRoot + m_strShop + m_strAppName + m_strSection;

    //------------------- R e g i s t r y C l a s s --------------------
    //
    ///<overloads>This method has three overloads.</overloads>
    ///<summary>Constructor invoking a registry path using all defaults.</summary>
    ///<remarks>The registry key path is in the form of "Software/CompanyName/AppName/Section". This
    ///invocation takes all these defaults.</remarks>
    //
    //------------------------------------------------------------------
    public RegistryClass()
    {
      string            strVersion;

      strVersion      = Application.ProductVersion;    // gonna remove the last period and number
      strVersion      = strVersion.Substring( 0, strVersion.LastIndexOf(".") );
      m_strSection    = strVersion;
      MakeFullPath();
    }

    //------------------- R e g i s t r y C l a s s --------------------
    //
    ///<summary>Constructor with Application Name option.</summary>
    ///<param name='strAppName'>Application Name string to be used for registry key path.</param>
    ///<remarks>The registry key path is in the form of "Software/CompanyName/AppName/Section". This
    ///invocation takes all the defaults but the Application Name.</remarks>
    //
    //------------------------------------------------------------------
    public RegistryClass(
      string                strAppName )
    {
      m_strAppName    = strAppName;
      MakeFullPath();
    }

    //------------------- R e g i s t r y C l a s s --------------------
    //
    ///<summary>Constructor with Application Name and Section option.</summary>
    ///<param name='strAppName'>Application Name string to be used for registry key path.</param>
    ///<param name='strSection'>Section Name string to be used for registry key path.</param>
    ///<remarks>The registry key path is in the form of "Software/CompanyName/AppName/Section". This
    ///invocation takes all the defaults but the Application Name and Section.</remarks>
    //
    //------------------------------------------------------------------
    public RegistryClass(
      string                strAppName,
      string                strSection )
    {
      m_strAppName    = strAppName;
      m_strSection    = strSection;
      MakeFullPath();
    }


    //------------------- R e g V a l G e t _ o b j --------------------
    //
    ///<summary>Private procedure to get a value from the registry.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='objValDefault'>Default object if key does not exist.</param>
    ///<returns>object.</returns>
    ///<remarks>The dot net interface to the registry uses the object type as the
    ///data type qualifier. This routine is called by each of the data types.</remarks>
    //
    //------------------------------------------------------------------
    private object RegValGet_obj(
      string                pstrKey,
      object                objValDefault )
    {
      RegistryKey           regKey = null;
      object                objRet = null;

      try 
      {
        switch( m_lngHiveID )
        {
          case E_REGISTRY_HIVES.CURRENT_USER:
            regKey = Registry.CurrentUser.OpenSubKey( m_strFullPath, true );
            break;
          case E_REGISTRY_HIVES.LOCAL_MACHINE:
            regKey = Registry.LocalMachine.OpenSubKey( m_strFullPath, true );
            break;
        }
        if( regKey == null )
        { //the primary key does not exist, create it!
          switch( m_lngHiveID )
          {
            case E_REGISTRY_HIVES.CURRENT_USER:
              regKey = Registry.CurrentUser.CreateSubKey( m_strFullPath );
              break;
            case E_REGISTRY_HIVES.LOCAL_MACHINE:
              regKey = Registry.LocalMachine.CreateSubKey( m_strFullPath );
              break;
          }
          //regKey.CreateSubKey(pstrKey)
        }
        if( regKey != null )
        {  // the key was defined
          objRet = regKey.GetValue( pstrKey );
          if( objRet == null )
          {
            regKey.SetValue( pstrKey, objValDefault );
            objRet = objValDefault;
            regKey.Close();
          }
        }
      } 
      catch //( Exception excp )
      {    // the Registry key does not exist;
        //ArgumentException // the Registry key does not exist
        //IOException       // the Registry key is closed
        //SecurityException // User does not have permission to access
        ////MsgBox( excp.Message );
      }
      return objRet;
    }

    //----------------------- R e g V a l S e t ------------------------
    //
    ///<summary>Private procedure to write a value to the registry.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='objValDefault'>Value to store.</param>
    ///<returns>void.</returns>
    ///<remarks>The dot net interface to the registry uses the object type as the
    ///data type qualifier. This routine is called by each of the write data types.</remarks>
    //
    //------------------------------------------------------------------
    private void RegValSet(
      string                pstrKey,
      object                objValDefault )
    {
      RegistryKey           regKey = null;

      try 
      {
        switch( m_lngHiveID )
        {
          case E_REGISTRY_HIVES.CURRENT_USER:
            regKey = Registry.CurrentUser.OpenSubKey( m_strFullPath, true );
            break;
          case E_REGISTRY_HIVES.LOCAL_MACHINE:
            regKey = Registry.LocalMachine.OpenSubKey( m_strFullPath, true );
            break;
        }
        if( regKey == null )
        { //the primary key does not exist, create it!
          switch( m_lngHiveID )
          {
            case E_REGISTRY_HIVES.CURRENT_USER:
              regKey = Registry.CurrentUser.CreateSubKey( m_strFullPath );
              break;
            case E_REGISTRY_HIVES.LOCAL_MACHINE:
              regKey = Registry.LocalMachine.CreateSubKey( m_strFullPath );
              break;
          }
          //regKey.CreateSubKey( pstrKey )
        }
        if( regKey != null )
        {  // the key was defined
          regKey.SetValue( pstrKey, objValDefault );
          regKey.Close();
        }
      } 
      catch( Exception excp )
      {
        // the Registry key does not exist;
        //ArgumentException // the Registry key does not exist
        //IOException       // the Registry key is closed
        //SecurityException // User does not have permission to access
        MessageBox.Show( excp.Message );
      }
    }



    //--------------------- L o n g G e t _ l n g ----------------------
    //
    ///<summary>Returns a long value, or the default if none exists, from the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pobjDefault'>Reference to a default object if no registry value exists.</param>
    ///<returns>Int32.
    ///<para> If no value exists and the pobjDefault is null, returns null.</para></returns>
    ///<remarks>This procedure returns a long data value from the registry at the key referenced.
    ///<para>Long is actually a misnomer, in .NET a long is an Int64 and if you present that to 
    ///the Net Registry utilities as a value it knows it will not fit in a Int32(DW),
    /// hence it promotes it to a string to prevent a loss of data.</para>
    /// </remarks>
    //
    //------------------------------------------------------------------
    public Int32 LongGet_lng(
      string                pstrKey,
      object                pobjDefault )
    {
      String                strType;
      Int32                 s32Val;

      strType = pobjDefault.GetType().ToString().ToLower();
      if( strType.IndexOf( "int32" ) > -1 )
      {
        s32Val = (Int32)pobjDefault;
      }
      else
      {
        s32Val = Convert.ToInt32( pobjDefault );
      }
      return (Int32)( RegValGet_obj( pstrKey, s32Val ) );
    }


    //------------------- S t r i n g G e t _ s t r --------------------
    //
    ///<summary>Returns a string value, or the default if none exists, from the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pstrDefault'>Reference to a default object if no registry value exists.</param>
    ///<returns>string.
    ///<para> If no value exists and the pstrDefault is null, returns null.</para></returns>
    ///<remarks>This procedure returns a string from the registry at the key referenced.</remarks>
    //
    //------------------------------------------------------------------
    public string StringGet_str(
      string                pstrKey,
      string                pstrDefault )
    {
      return (System.String)RegValGet_obj( pstrKey, pstrDefault );
    }


    //------------------- B i n a r y G e t _ a r r --------------------
    //
    ///<summary>Returns a byte array value, or the default if none exists, from the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pabytDefault'>Reference to a default object if no registry value exists.</param>
    ///<returns>byte[]
    ///<para>If no value exists and the pabytDefault is null, returns null.</para></returns>
    ///<remarks>This procedure returns a byte array of data from the registry at the key referenced.</remarks>
    //
    //------------------------------------------------------------------
    public byte[] BinaryGet_arr(
      string                pstrKey,
      System.Array          pabytDefault )
    {
      return (byte[])RegValGet_obj( pstrKey, pabytDefault );
    }

    //------------------------- L o n g S e t --------------------------
    //
    ///<summary>Writes a long value to the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pobjValue'>Reference to object value to be written.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure stores a long (UInt32) in the registry at the key referenced.
    /// <para>Long is actually a misnomer, in .NET a long is an Int64 and if you present
    /// that to the Net Registry utilities as a value it knows it will not fit 
    /// in a Int32(DW), hence it promotes it to a string to prevent a loss of data.</para>
    /// <para>If the registry key does not exist it is created.</para></remarks>
    //
    //------------------------------------------------------------------
    public void LongSet(
      string                pstrKey,
      object                pobjValue )
    {
      string                strType;
      Int32                 s32Val;

      strType = pobjValue.GetType().ToString().ToLower();
      if ( strType.IndexOf( "int32" ) > -1 )
      {
        s32Val = (Int32)pobjValue;
      }
      else
      {
        s32Val = Convert.ToInt32( pobjValue );
      }
      RegValSet( pstrKey, s32Val );
    }

    //----------------------- S t r i n g S e t ------------------------
    //
    ///<summary>Writes a string value to the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pstrValue'>Reference to object value to be written.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure stores a string in the registry at the key referenced.
    ///<para>If the registry key does not exist it is created.</para></remarks>
    //
    //------------------------------------------------------------------
    public void StringSet(
      string                pstrKey,
      string                pstrValue )
    {
      RegValSet( pstrKey, pstrValue );
    }

    //----------------------- B i n a r y S e t ------------------------
    //
    ///<summary>Writes a byte array value to the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pabytVal'>Reference to object value to be written.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure stores a byte array of data in the registry at the key referenced.
    ///<para>If the registry key does not exist it is created.</para></remarks>
    //
    //------------------------------------------------------------------
    public void BinarySet(
      string                pstrKey,
      System.Array          pabytVal )
    {
      RegValSet( pstrKey, pabytVal );
    }

    //----------------------- D e l e t e K e y ------------------------
    //
    ///<summary>Deletes a registry key value.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure results in a registry key being deleted.</remarks>
    //
    //------------------------------------------------------------------
    public void DeleteKey(
      string                pstrKey )
    {
      RegistryKey           regKey = null;

      try
      {
        switch( m_lngHiveID )
        {
          case E_REGISTRY_HIVES.CURRENT_USER:
            regKey = Registry.CurrentUser.OpenSubKey( m_strFullPath, true );
            break;
          case E_REGISTRY_HIVES.LOCAL_MACHINE:
            regKey = Registry.LocalMachine.OpenSubKey( m_strFullPath, true );
            break;
        }
        if( regKey == null )
        { //the primary key does not exist, create it!
          switch( m_lngHiveID )
          {
            case E_REGISTRY_HIVES.CURRENT_USER:
              regKey = Registry.CurrentUser.CreateSubKey( m_strFullPath );
              break;
            case E_REGISTRY_HIVES.LOCAL_MACHINE:
              regKey = Registry.LocalMachine.CreateSubKey( m_strFullPath );
              break;
          }
          //regKey.CreateSubKey( pstrKey )
        }
        if( regKey != null )
        {  // the key was defined
          regKey.DeleteSubKey( pstrKey );
          regKey.Close();
        }
      }
      catch //( Exception excp )
      {
        // the Registry key does not exist;
        //MsgBox( excp.Message );
      }
    }

    //--------------------- D e l e t e V a l u e ----------------------
    //
    ///<summary>Deletes a registry key value.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure results in a value at the registry key location to become undefined.</remarks>
    //
    //------------------------------------------------------------------
    public void DeleteValue(
      string                pstrKey )
    {
      RegistryKey           regKey = null;

      try
      {
        switch( m_lngHiveID )
        {
          case E_REGISTRY_HIVES.CURRENT_USER:
            regKey = Registry.CurrentUser.OpenSubKey( m_strFullPath, true );
            break;
          case E_REGISTRY_HIVES.LOCAL_MACHINE:
            regKey = Registry.LocalMachine.OpenSubKey( m_strFullPath, true );
            break;
        }
        if( regKey == null )
        { //the primary key does not exist, create it!
          switch (m_lngHiveID) 
          {
            case E_REGISTRY_HIVES.CURRENT_USER:
              regKey = Registry.CurrentUser.CreateSubKey( m_strFullPath );
              break;
            case E_REGISTRY_HIVES.LOCAL_MACHINE:
              regKey = Registry.LocalMachine.CreateSubKey( m_strFullPath );
              break;
          }
          //regKey.CreateSubKey( pstrKey )
        }
        if( regKey != null )
        {  // the key was defined
          regKey.DeleteValue( pstrKey );
          regKey.Close();
        }
      }
      catch //( Exception excp )
      {
        // the Registry key does not exist;
        //MsgBox( excp.Message );
      }
    }

    // -------------------------- s t r A p p  -------------------------
    //
    ///<summary>App portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>The full registry path string is constructed from "Software/CompanyName/AppName/Section". strApp is the AppName portion.</remarks> 
    // ----------------------------------------------------------------
    public string  strApp
    {
      get
      {
        return m_strAppName;
      }
      set
      {
        m_strAppName = value;
        MakeFullPath();
      }
    }

    // ------------------------- s t r R o o t ------------------------
    //
    ///<summary>Root portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>The full registry path string is constructed from "Software/CompanyName/AppName/Section". strRoot is the Software portion.</remarks> 
    // ----------------------------------------------------------------
    public string  strRoot
    {
      get
      {
        return m_strRoot;
      }
      set
      {
        m_strRoot = value;
        MakeFullPath();
      }
    }

    // ---------------------- s t r S e c t i o n ---------------------
    //
    ///<summary>Section portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>The full registry path string is constructed from "Software/CompanyName/AppName/Section". strSection is the Section portion.</remarks> 
    // ----------------------------------------------------------------
    public string  strSection
    {
      get
      {
        return m_strSection;
      }
      set
      {
        m_strSection = value;
        MakeFullPath();
      }
    }

    // ------------------------- s t r S h o p ------------------------
    //
    ///<summary>Shop portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>The full registry path string is constructed from "Software/CompanyName/AppName/Section". strShop is the CompanyName portion.</remarks> 
    // ----------------------------------------------------------------
    public string  strShop
    {
      get
      {
        return m_strRoot;
      }
      set
      {
        m_strShop = value;
        MakeFullPath();
      }
    }

    // -------------------------- H i v e I D -------------------------
    //
    ///<summary>Hive portion of the registry key path.</summary>
    ///<value>Registry Hive enum.</value>
    ///<remarks>The Registry Hive that is accessed when a read or write is requested.</remarks> 
    // ----------------------------------------------------------------
    public  E_REGISTRY_HIVES HiveID
    {
      set
      {
        m_lngHiveID = value;
      }
    }

    //-------------------- M a k e F u l l P a t h ---------------------
    //
    ///<summary>Contructs a full registry key path string from the parts the user defined.</summary>
    ///<returns>void.</returns>
    ///<remarks>The full registry path string is constructed from "Software/CompanyName/AppName/Section".
    ///<para> If the user defines any one of the individual parts to be null it is left out of the string.</para>
    ///</remarks>
    //
    //------------------------------------------------------------------
    private void MakeFullPath()
    {
      StringBuilder         sbld = new StringBuilder( 100 );
      string                strSep = "";

      if( m_strRoot.Length > 0 )
      {
        sbld.Append( m_strRoot );
        strSep = "\\";
      }

      if( m_strShop.Length > 0 )
      {
        sbld.AppendFormat( "{0}{1}", strSep, m_strShop );
        strSep = "\\";
      }

      if( m_strAppName.Length > 0 )
      {
        sbld.AppendFormat( "{0}{1}", strSep, m_strAppName );
        strSep = "\\";
      }

      if( m_strSection.Length > 0 )
      {
        sbld.AppendFormat( "{0}{1}", strSep, m_strSection );
      }

      m_strFullPath = sbld.ToString();
    }
  } // End of Registry Class
}
