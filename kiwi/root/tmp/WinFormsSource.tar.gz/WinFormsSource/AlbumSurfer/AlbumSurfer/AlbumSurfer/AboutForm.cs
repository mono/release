// 05.05.19.19 completed comment work
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;  // for Win32Exception
using System.Windows.Forms;
using System.Diagnostics;     // for Process shell work
using System.IO;
using System.Text;
using System.Reflection;    // for Assembly
using SCRN = System.Windows.Forms.Screen;

namespace AlbumSurfer
{
  /// <summary>AboutForm Class Definition.</summary>
  /// <remarks>A typical invocation of this module would do the following:
  /// <code>
  ///{
  ///  AboutForm          frmAbout = new AboutForm();
  ///
  ///  frmAbout.ShowDialog( this );
  ///}</code>
  /// </remarks>
  public class AboutForm : System.Windows.Forms.Form
  {
    ///<summary>Form label for displaying the Company Name.</summary>
    ///<remarks>Value obtained from the Application object "CompanyName" property which itself comes from the Assembly "Company" attribute.</remarks>
    private System.Windows.Forms.Label m_lblCompany;
    ///<summary>Form label for displaying the form title.</summary>
    ///<remarks>Value obtained from the Assembly "Title" attribute.</remarks>
    private System.Windows.Forms.Label m_lblTitle;
    ///<summary>Form label for displaying the Product Version.</summary>
    ///<remarks>Value obtained from the Application object "Version" property which itself comes from the Assembly "Version" attribute.</remarks>
    private System.Windows.Forms.Label m_lblVersion;
    ///<summary>Form label for displaying the Product Copyright.</summary>
    ///<remarks>Value obtained from the Application object "Copyright" property which itself comes from the Assembly "Company" attribute.</remarks>
    private System.Windows.Forms.Label m_lblCopyright;
    ///<summary>Form label for displaying the Product Description.</summary>
    ///<remarks>Value obtained from the Application object "Description" property. This is typically a little narrative 
    /// that describes what the product can do.</remarks>
    private System.Windows.Forms.Label m_lblDescription;
    ///<summary>Form text box for displaying information about the release history of this product.</summary>
    ///<remarks>Value obtained from the Assembly "TradeMark" attribute.</remarks>
    private System.Windows.Forms.TextBox m_tbxReleaseInfo;

    ///<summary>Form button which spawns the SYSINFO application to show system information.</summary>
    ///<remarks>Presents the user with a System Info window permitting exploration of the systems characteristics.</remarks>
    private System.Windows.Forms.Button m_btnSysInfo;
    ///<summary>Form button to close the about form.</summary>
    ///<remarks>Button provided for the user to dispatch the dialog.</remarks>
    private System.Windows.Forms.Button m_btnOK;
    ///<summary>Form picture box for the display of the company logo.</summary>
    ///<remarks>A container for placing the corporate logo employing a transparency mechanism where all white pixels of
    /// the source bitmap are replaced with the control back ground.</remarks>
    private System.Windows.Forms.PictureBox m_pic1;
    ///<summary>Required designer variable.</summary>
    ///<remarks>Container object for the storage of all the objects on the form.</remarks>
    private System.ComponentModel.Container components = null;  // the wizard wants this to be named this


    //----------------------- A b o u t F o r m ------------------------
    //
    ///<summary>Constructor.</summary>
    ///<remarks>Constructor procedure which instantiates and initializes all the form objects.</remarks>
    //
    //------------------------------------------------------------------
    public AboutForm()
    {    // Required for Windows Form Designer support
      InitializeComponent();

      // Add any constructor code after InitializeComponent call
    }

    ///<summary>Clean up any resources being used.</summary>
    ///<remarks>Can be though of as the class destructor which disposes of all the form objects.</remarks>
    protected override void Dispose( bool disposing )
    {
      if( disposing )
      {
        if( components != null )
        {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>Required method for Designer support - do not modify
    /// the contents of this method with the code editor. </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AboutForm));
      this.m_lblTitle = new System.Windows.Forms.Label();
      this.m_lblVersion = new System.Windows.Forms.Label();
      this.m_tbxReleaseInfo = new System.Windows.Forms.TextBox();
      this.m_lblDescription = new System.Windows.Forms.Label();
      this.m_pic1 = new System.Windows.Forms.PictureBox();
      this.m_btnSysInfo = new System.Windows.Forms.Button();
      this.m_btnOK = new System.Windows.Forms.Button();
      this.m_lblCompany = new System.Windows.Forms.Label();
      this.m_lblCopyright = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // m_lblTitle
      // 
      this.m_lblTitle.BackColor = System.Drawing.SystemColors.Control;
      this.m_lblTitle.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.m_lblTitle.Location = new System.Drawing.Point(128, 32);
      this.m_lblTitle.Name = "m_lblTitle";
      this.m_lblTitle.Size = new System.Drawing.Size(368, 32);
      this.m_lblTitle.TabIndex = 0;
      this.m_lblTitle.Text = "Assembly App Title";
      this.m_lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // m_lblVersion
      // 
      this.m_lblVersion.BackColor = System.Drawing.SystemColors.Control;
      this.m_lblVersion.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.m_lblVersion.Location = new System.Drawing.Point(128, 63);
      this.m_lblVersion.Name = "m_lblVersion";
      this.m_lblVersion.Size = new System.Drawing.Size(368, 24);
      this.m_lblVersion.TabIndex = 1;
      this.m_lblVersion.Text = "Assembly Version";
      this.m_lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // m_tbxReleaseInfo
      // 
      this.m_tbxReleaseInfo.Location = new System.Drawing.Point(3, 176);
      this.m_tbxReleaseInfo.Multiline = true;
      this.m_tbxReleaseInfo.Name = "m_tbxReleaseInfo";
      this.m_tbxReleaseInfo.ReadOnly = true;
      this.m_tbxReleaseInfo.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.m_tbxReleaseInfo.Size = new System.Drawing.Size(488, 40);
      this.m_tbxReleaseInfo.TabIndex = 3;
      this.m_tbxReleaseInfo.Text = "Trademark from assembly";
      this.m_tbxReleaseInfo.Visible = false;
      // 
      // m_lblDescription
      // 
      this.m_lblDescription.Location = new System.Drawing.Point(136, 112);
      this.m_lblDescription.Name = "m_lblDescription";
      this.m_lblDescription.Size = new System.Drawing.Size(360, 32);
      this.m_lblDescription.TabIndex = 3;
      this.m_lblDescription.Text = "  Assembly Description";
      // 
      // m_pic1
      // 
      this.m_pic1.BackColor = System.Drawing.SystemColors.Control;
      this.m_pic1.Location = new System.Drawing.Point(0, 0);
      this.m_pic1.Name = "m_pic1";
      this.m_pic1.Size = new System.Drawing.Size(128, 128);
      this.m_pic1.TabIndex = 4;
      this.m_pic1.TabStop = false;
      this.m_pic1.Paint += new System.Windows.Forms.PaintEventHandler(this.m_pic1_Paint);
      // 
      // m_btnSysInfo
      // 
      this.m_btnSysInfo.Location = new System.Drawing.Point(160, 144);
      this.m_btnSysInfo.Name = "m_btnSysInfo";
      this.m_btnSysInfo.TabIndex = 2;
      this.m_btnSysInfo.Text = "System Info";
      this.m_btnSysInfo.Click += new System.EventHandler(this.m_btnSysInfo_Click);
      // 
      // m_btnOK
      // 
      this.m_btnOK.Location = new System.Drawing.Point(392, 144);
      this.m_btnOK.Name = "m_btnOK";
      this.m_btnOK.TabIndex = 1;
      this.m_btnOK.Text = "OK";
      this.m_btnOK.Click += new System.EventHandler(this.m_btnOK_Click);
      // 
      // m_lblCompany
      // 
      this.m_lblCompany.BackColor = System.Drawing.SystemColors.Control;
      this.m_lblCompany.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.m_lblCompany.Location = new System.Drawing.Point(128, 0);
      this.m_lblCompany.Name = "m_lblCompany";
      this.m_lblCompany.Size = new System.Drawing.Size(368, 34);
      this.m_lblCompany.TabIndex = 7;
      this.m_lblCompany.Text = "Assembly Company";
      this.m_lblCompany.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // m_lblCopyright
      // 
      this.m_lblCopyright.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.m_lblCopyright.Location = new System.Drawing.Point(128, 86);
      this.m_lblCopyright.Name = "m_lblCopyright";
      this.m_lblCopyright.Size = new System.Drawing.Size(368, 20);
      this.m_lblCopyright.TabIndex = 8;
      this.m_lblCopyright.Text = "Assembly Copyright";
      this.m_lblCopyright.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // AboutForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(496, 174);
      this.Controls.Add(this.m_lblCopyright);
      this.Controls.Add(this.m_lblCompany);
      this.Controls.Add(this.m_btnOK);
      this.Controls.Add(this.m_btnSysInfo);
      this.Controls.Add(this.m_pic1);
      this.Controls.Add(this.m_lblDescription);
      this.Controls.Add(this.m_tbxReleaseInfo);
      this.Controls.Add(this.m_lblVersion);
      this.Controls.Add(this.m_lblTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.KeyPreview = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.MinimumSize = new System.Drawing.Size(504, 208);
      this.Name = "AboutForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "AboutForm";
      this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AboutForm_KeyDown);
      this.Resize += new System.EventHandler(this.AboutForm_Resize);
      this.Load += new System.EventHandler(this.AboutForm_Load);
      this.ResumeLayout(false);

    }
    #endregion


    //------------------ A b o u t F o r m _ L o a d -------------------
    //
    ///<summary>Handles the form load event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='eve'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Narrative.</remarks>
    //
    //------------------------------------------------------------------
    private void AboutForm_Load(
      object                sender,
      System.EventArgs      eve )
    {
      int                   s32X;
      int                   s32Y;
      int                   s32ScreenWidth;
      int                   s32ScreenHeight;
      BoundsSpecified       bnds;

      
      // All the following information was retrieved from the Assembly
      this.Text = String.Format("About {0}  V{1}", Application.ProductName, Application.ProductVersion);
      AssemblyInfoGet();
      m_btnOK.Focus();

      //-------------------------------------------------------------
      // The following exercise simply makes sure that when we pop up 
      // on the screen that we are centered in or over our Owner window
      // Am I less wide than the app
      if( ( this.Owner.Width > this.Width ) )
      {   // I will fit in horizontally
        s32X = this.Owner.Left + ( ( this.Owner.Width - this.Width ) / 2);
      }
      else
      {   // I am wider, make sure on screen, try to center over top but not off screen
        s32X = this.Owner.Left - ( ( this.Width - this.Owner.Width ) / 2 );
        if( ( s32X < 0 ) )
        {
          s32X = 0;
        }

      }
      // we will always make sure we are completely on screen
      s32ScreenWidth = SCRN.PrimaryScreen.Bounds.Width;
      if( ( ( s32X + this.Width ) > s32ScreenWidth ) ) 
      {   // move to the right until whole window on screen
        s32X = s32ScreenWidth - this.Width;
      }

      // Am I less tall than the app
      if( ( this.Owner.Height > this.Height) ) 
      {   // I will fit in Vertically, offset half the difference
        s32Y = this.Owner.Top + ( ( this.Owner.Height - this.Height ) / 2 );
      } 
      else 
      {   // I am taller, make sure on screen
        s32Y = this.Owner.Top - ( ( this.Height - this.Owner.Height ) / 2 );
        if( ( s32Y < 0 ) )
        {
          s32Y = 0;
        }
      }
      s32ScreenHeight = SCRN.PrimaryScreen.Bounds.Height;
      if( ( ( s32Y + this.Height ) > s32ScreenHeight ) )
      {   // move back up so bottom is on screen
        s32Y = s32ScreenHeight - this.Height;
      }

      bnds = BoundsSpecified.X | BoundsSpecified.Y;
      this.SetBounds(s32X, s32Y, 0, 0, bnds);
    }


    //--------------- A b o u t F o r m _ K e y D o w n ----------------
    //
    ///<summary>Handles the form key down event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='eventArgs'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Provides a mechanism to dispatch the About form by pushing the escape key.</remarks>
    //
    //------------------------------------------------------------------
    private void AboutForm_KeyDown(
      object                sender,
      System.Windows.Forms.KeyEventArgs eventArgs )
    {
      Keys keyCode    = eventArgs.KeyCode;
      Keys keyShift   = eventArgs.KeyData;  //\ &H10000;

      switch( eventArgs.Modifiers )
      { 
        case 0: // NO MODIFIER KEYS PRESSED; CTRL,SHIFT,ALT
        {
          switch( keyCode )
          { 
            case System.Windows.Forms.Keys.Escape: // Here implies a vanilla Escape Key;
              m_btnOK_Click( m_btnOK, new System.EventArgs() );
              break;
            default:
              break;
          }
          break; // end of modifier keys = nonr
        }
          //case vbShiftMask // SHIFT KEY ONLY PRESSED
          //    switch( s16KeyCode )
          //    { 
          //        case System.Windows.Forms.Keys.Tab // Shift-Tab  tab to Previous control
          //        default:
          //    }  
          //    break;  // end of modifier keys = Shift pressed

          //case vbCtrlMask // CONTROL KEY ONLY PRESSED
          //    switch( s16KeyCode )
          //    {
          //        case System.Windows.Forms.Keys.return // here implies a Control-CR
          //        default:
          //    }
          //    break;   // end of modifier keys = Control pressed

        default:
          break;
      } // end of test Modifier Keys
    }


    //---------------- A b o u t F o r m _ R e s i z e -----------------
    //
    ///<summary>Handles the form resize event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='eve'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Makes sure all the objects on the form are positioned properly after resizing.</remarks>
    //
    //------------------------------------------------------------------
    private void AboutForm_Resize(
      object                sender,
      System.EventArgs      eve )
    {
      
      m_lblTitle.Width          = this.Width  - 170;
      m_lblVersion.Width        = this.Width  - 170;
      m_lblDescription.Width    = this.Width  - 25;
      m_lblCompany.Width        = this.Width  - 170;
      m_lblCopyright.Width      = this.Width  - 170;
      if( this.Height > (m_tbxReleaseInfo.Top + 50 ))  // Enough room for the history
      {
        m_tbxReleaseInfo.Visible  = true;
        m_tbxReleaseInfo.Height   = this.Height - 215; //195;
        m_tbxReleaseInfo.Width    = this.Width  - 20; //25;
      }
      else
      {
        m_tbxReleaseInfo.Visible  = false;
      }
    }


    //--------------------- b t n O K _ C l i c k ----------------------
    //
    ///<summary>Handles the m_btnOK click event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='eve'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Standard dialog form button for closing the from with an OK response.</remarks>
    //
    //------------------------------------------------------------------
    private void m_btnOK_Click(
      object                sender,
      System.EventArgs      eve )
    {
      this.Close();
    }


    //-------------- m _ b t n S y s I n f o _ C l i c k ---------------
    //
    ///<summary>Handles the m_btnSysInfo click event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='eve'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Provides for a means for the user to spawn the application which shows
    ///"System Information" about the structure of the system.</remarks>
    //
    //------------------------------------------------------------------
    private void m_btnSysInfo_Click(
      object                sender,
      System.EventArgs      eve )
    {
      string                strSysInfoPath;
      RegistryClass         regAbout;
      Process               proc;

      regAbout = new RegistryClass( "Shared Tools", "MSINFO" );
      regAbout.strShop = "Microsoft";

      strSysInfoPath = regAbout.StringGet_str( "PATH", "" );

      if( strSysInfoPath == "" ) // not in the Path location, look else where
      {
        regAbout.strApp = "static Tools Location";
        regAbout.strSection = "";
        strSysInfoPath = regAbout.StringGet_str( "MSINFO", "" );
        if( strSysInfoPath == "" )
        {
          //frmMsgBox = new MsgBoxForm();
          //frmMsgBox.lblMsg.Text = "System Information Is Unavailable At This Time";
          //frmMsgBox.ShowDialog();
          //frmMsgBox.Dispose();
          return;
        } 
        else 
        {
          if( true ) //(Dir(strSysInfoPath + "\\MSINFO32.EXE") != "") ) 
          {
            strSysInfoPath = strSysInfoPath + "\\MSINFO32.EXE";
          }
          //else 
          //{
          //frmMsgBox = new MsgBoxForm();
          //frmMsgBox.lblMsg.Text = "System Information Is Unavailable At This Time";
          //frmMsgBox.ShowDialog();
          //frmMsgBox.Dispose();
          //    return;
          //}
        }
      }

      proc = new Process();
      try
      {
        proc.StartInfo.FileName = strSysInfoPath; 
        proc.StartInfo.Verb = "";
        proc.StartInfo.CreateNoWindow = false;
        proc.Start();
      }
      catch( Win32Exception excpWin32 )
      {
        if( excpWin32.NativeErrorCode == 2 )  //ERROR_FILE_NOT_FOUND)
        {
          Console.WriteLine(excpWin32.Message + ". Check the path.");
        } 
        else if( excpWin32.NativeErrorCode == 5 ) //ERROR_ACCESS_DENIED)
        {
          //Console.WriteLine(excp.Message );
        }
      }
    } // end of m_btnSysInfo_Click()


    //-------------------- m _ p i c 1 _ P a i n t --------------------
    //
    ///<summary>Handles the m_pic1 paint event.</summary>
    ///<param name='objSender'>Reference to the m_pic1 Object.</param>
    ///<param name='ePaintArgs'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>This little exercise replaces the white in the bitmap 
    /// with the system control background color making the bitmap 
    /// act a bit like an icon.</remarks>
    //
    //------------------------------------------------------------------
    private void m_pic1_Paint(
      object                objSender,
      System.Windows.Forms.PaintEventArgs ePaintArgs )
    {
      string                strPathFile;
      Bitmap                bmp;
      Int32                 s32IX;
      Int32                 s32Xix;
      Int32                 s32Yix;
      Color                 colPixel;
      Color                 colBG = System.Drawing.SystemColors.Control;
      
      strPathFile = Application.StartupPath;
      // we want to make the root up from "\bin\Debug" or "\bin\Release" if in the IDE
      s32IX = strPathFile.IndexOf( "\\bin\\Debug" );
      if( s32IX < 0 )
      {
        s32IX = strPathFile.IndexOf( "\\bin\\Release" );
      }
      if( s32IX > 0 ) 
      {   // "bin\" is in the string
        strPathFile = strPathFile.Substring( 0, s32IX );
      }   // it has no '\' at the 
      strPathFile += "\\Logo.bmp";
      if( File.Exists( strPathFile ) == true )
      {
        bmp = new Bitmap(strPathFile);
        // not we will examine every pixel in the bitmap and replace the
        // white ones with the control background color
        for( s32Yix = 0; s32Yix < bmp.Height; s32Yix++ )
        {
          for( s32Xix = 0; s32Xix < bmp.Width; s32Xix++)
          {
            colPixel = bmp.GetPixel(s32Xix, s32Yix);
            if(   ( colPixel.R == 255 ) 
               && ( colPixel.G == 255 )
               && ( colPixel.B == 255 ) ) 
            {
              bmp.SetPixel( s32Xix, s32Yix, colBG );
            }
          } // bitmap pixels on the line
        } // bitmap line

        // we will center the logo if it is smaller
        s32Xix = 0;
        if( m_pic1.Width > bmp.Width )
        {
          s32Xix = (Int32)( ( m_pic1.Width - bmp.Width ) / 2 );
        }
        s32Yix = 0;
        if( m_pic1.Height > bmp.Height  )
        {
          s32Yix = (Int32)( ( m_pic1.Height - bmp.Height ) / 2 );
        }
        ePaintArgs.Graphics.DrawImageUnscaled( bmp, s32Xix, s32Yix );
        bmp.Dispose();
      } //bitmap file exists
    }

    // ----------------- A s s e m b l y I n f o G e t ------------------
    //
    ///<summary>Procedure to obtain information from the assembly attributes
    ///which is not part of the Application object.</summary>
    ///<returns>void</returns>
    ///<remarks>The Application object provides us with some info from the assembly data, but not all 
    /// of it. 
    /// <para>The Assembly Title string is also obtained for our window top label.</para>
    /// <para>The framework actually places the AssemblyName.Version string in the 
    /// AssemblyInformationalVersionAttribute which ends up as the Application.ProductVersion object.
    /// One can obtain the raw version info with the following code:
    /// <code>
    /// {
    ///    Assembly                        objAssembly;
    ///    AssemblyName                    assName;
    ///    
    ///    objAssembly = System.Reflection.Assembly.GetExecutingAssembly();
    ///    assName     = objAssembly.GetName();  // has raw Version info in it
    ///    strText     = assName.Version.ToString();
    ///    }</code>
    /// Because of this and that it is convenient to get the Version string from the 
    /// Application object we will hijack the Trademark attribute to store or product
    /// release history.
    /// </para>
    /// </remarks>
    //
    // ------------------------------------------------------------------
    private void AssemblyInfoGet()
    {
      Assembly                        objAssembly;
      AssemblyTitleAttribute          attrTitle;
      AssemblyDescriptionAttribute    attrDesc;
      AssemblyTrademarkAttribute      attrTMark;  
      AssemblyCopyrightAttribute      attrCopyRite;
      object[]                        aobjAttrs;
      Type                            typeObj;
      
      m_lblVersion.Text   = Application.ProductVersion;  // actually AssemblyInformationalVersionAttribute
      m_lblCompany.Text   = Application.CompanyName;
     
      objAssembly = System.Reflection.Assembly.GetExecutingAssembly(); 
      aobjAttrs = objAssembly.GetCustomAttributes( false );
      foreach ( object obj in  aobjAttrs )
      { // The Title typically has spaces in it where the ProductName will not
        typeObj = obj.GetType();
        if( typeObj == typeof( AssemblyTitleAttribute ) )
        {
          attrTitle = (System.Reflection.AssemblyTitleAttribute)obj;
          m_lblTitle.Text = attrTitle.Title;
        }
        else if( typeObj == typeof( AssemblyDescriptionAttribute ))
        {
          attrDesc = (System.Reflection.AssemblyDescriptionAttribute)obj;
          m_lblDescription.Text = attrDesc.Description;
        }
        else if( typeObj == typeof(AssemblyTrademarkAttribute))
        {
          attrTMark = (System.Reflection.AssemblyTrademarkAttribute)obj;
          m_tbxReleaseInfo.Text = attrTMark.Trademark; 
        }
        else if( typeObj == typeof(AssemblyCopyrightAttribute))
        {
          attrCopyRite = (System.Reflection.AssemblyCopyrightAttribute)obj;
          m_lblCopyright.Text = attrCopyRite.Copyright; 
        }
      } // end of aobjAttrs iteration
    } // end of AssemblyInfoGet()
  } // end class AboutForm
} // End Namespace
