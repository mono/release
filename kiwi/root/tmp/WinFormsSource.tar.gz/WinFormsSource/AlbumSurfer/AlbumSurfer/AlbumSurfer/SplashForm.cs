// 05.05.25.17 Changed timer to running all the time
// 05.05.16.08 completed comment work
using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.IO;              // for File testing
using System.Reflection;      // for Assembly info
using SCRN = System.Windows.Forms.Screen;

namespace AlbumSurfer
{
  ///<summary>Enum that describes the opacity state of the splash window.</summary>
  public enum E_SPLASH_STATE
  {
    ///<summary>Its in the process of becoming opaque.</summary>
    BECOMING_OPAQUE,
    ///<summary>Its opaque and is waiting to go away.</summary>
    SHOWING, 
    ///<summary>Its fading away.</summary>
    BECOMING_TRANSPARENT,
    ///<summary>Its the mode that waits for a click or parent GoAway to disappear.</summary>
    DONE,
    ///<summary>Its was in STAY mode and became fully opaque.</summary>
    OPAQUE,
    ///<summary>Its disappeared and deallocated.</summary>
    CLOSED,
  }
  ///<summary>Enum that configures the splash window display mode.</summary>
  public enum E_SPLASH_MODE
  {
    ///<summary>To make it disappear the parent either closes or the user clicks.</summary>
    STAY,
    ///<summary>After a few seconds it just fades away.</summary>
    GOAWAY,
  }

  /// <summary>Definition of Splash Form.</summary>
  ///<remarks> A typical invocation of this module would do the following:
  ///<code>
  ///static void Main() 
  ///{
  ///  g_reg             = new RegistryClass(  );
  ///  // get the last window placement and size from persistent storage
  ///  g_strWinPlacement = g_reg.StringGet_str( "MainWinDetails", "10,10,331,262" );
  ///
  ///  SplashForm.ShowIt( true, E_SPLASH_MODE.STAY, g_strWinPlacement ); 
  ///  Application.DoEvents();    // this must be here to allow the splash thread to do its init
  ///
  ///  SplashForm.SetStatus("Loading module 1", 10 );
  ///  System.Threading.Thread.Sleep( 500 );
  ///  SplashForm.SetStatus("Loading module 2", 30 );
  ///  System.Threading.Thread.Sleep( 300 );
  ///  SplashForm.SetStatus("Loading module 3", 60 );
  ///
  ///  frmMain   = new MainForm();
  ///  Application.Run( frmMain );
  ///  }</code>
  /// If the form is not set to GOAWAY then somewhere a CloseForm is invoked.
  ///<code>
  /// SplashForm.GoAway();</code>
  ///</remarks>
  public class SplashForm : System.Windows.Forms.Form
  {
    #region Form Statics
    ///<summary>Instantiation reference of SplashForm.</summary>
    ///<remarks>Mechanism to access instantiation from other static functions.</remarks>
    static SplashForm       ms_frmSplash      = null;
    ///<summary>Instantiation reference of Splash Form thread object.</summary>
    ///<remarks>.</remarks>
    static Thread           ms_thrdSplash     = null;
    ///<summary>Determines whether splash form remains until the user clicks it, parent window closes it, or fades away.</summary>
    ///<remarks>Enum storage location for Splash form mode.</remarks>
    static E_SPLASH_MODE    ms_eMode          = E_SPLASH_MODE.STAY; //.GOAWAY;
    ///<summary>"Top,Left,Width,Height" string obtained from persistence storage used to center Splash window over parent.</summary>
    ///<remarks>If value is an empty string then the Splash window is centered on the screen.</remarks>
    static string           ms_strWinPlacement = "";
    ///<summary>A Boolean that indicates whether the instantiated Splash window should display a progress bar.</summary>
    ///<remarks>If false no progress bar is displayed.</remarks>
    static bool             ms_ynPercentBar   = false;

    #endregion

    #region  Form Constants
    ///<summary>Up increment for timer opacity changes.</summary>
    ///<remarks>The Splash form appears more slowly than it disappears. ( .05 ).</remarks>
    private const double    INCREMENT         =   .05;
    ///<summary>Down increment for timer opacity changes.</summary>
    ///<remarks>The Splash form disappears more quickly than it appears. ( .08 ).</remarks>
    private const double    DECREMENT         =   .08;
    ///<summary>The value of the interval used for the form timer, milliseconds between timer ticks.</summary>
    ///<remarks>The timer interval is 56 milliseconds of 1 / 18 of a second. This is the minimum resolution of the timer.</remarks>
    private const int       TIMER_INTERVAL    = 56;
    #endregion

    #region Form Variables
    ///<summary>The directory path to where our application was started. It locates application data and bitmaps.</summary>
    ///<remarks>When in the development mode this directory path points to the source code to find data files.</remarks>
    private string          m_strAppPath;
    ///<summary>The opacity state the form is in. Used in enabling operations.</summary>
    ///<remarks>When a timer tick event occurs the procedure needs to know what to do next and it does this
    /// by knowing the present state it is and what mode we are in.</remarks>
    private E_SPLASH_STATE  m_eState          = E_SPLASH_STATE.BECOMING_OPAQUE;
    ///<summary>The amount of time in timer intervals to show opaque from if mode is GOAWAY.</summary>
    ///<remarks>The timer runs on 56 millisecond intervals, 18 = 1 second. This is a count of timer
    /// intervals for the fully opaque form to show before it starts to disappear if the mode is GOAWAY ( 5 * 18 ).</remarks>
    private Int32           m_s32ShowTime    = 5;
    ///<summary>Form label for displaying the latest status.</summary>
    ///<remarks>A Form label object for displaying the status the user has requested to be shown.</remarks>
    private System.Windows.Forms.Label m_lblStatus;
    ///<summary>Forms Timer for causing opacity modifications and show interval counting.</summary>
    ///<remarks>the tick event of this timer is used in conjunction with the form Mode and State to determine
    ///  what to do next. A tick event can cause the from to become more or less transparent or be used to determine
    ///  how long it will show in the full opaque mode.</remarks>
    private System.Windows.Forms.Timer m_timer1;
    ///<summary>Form label for displaying the Product Version.</summary>
    ///<remarks>Value obtained from the Application object "Version" property which itself comes from the Assembly "Version" attribute.</remarks>
    private System.Windows.Forms.Label m_lblProductVersion;
    ///<summary>A Form PictureBox object for displaying our Company logo bitmap.</summary>
    ///<remarks>In an effort to make the company logo work like an icon we copy from the source bitmap to the 
    /// PictureBox replacing all white pixels with the controls background pixel. (Wa La transparency).</remarks>
    private System.Windows.Forms.PictureBox m_pic1;
    ///<summary>Form label for displaying the Company Name.</summary>
    ///<remarks>Value obtained from the Application object "CompanyName" property which itself comes from the Assembly "Company" attribute.
    ///<para>In the first version of this module the timer was stopped if it was a "STAY" mode but when it is Stopped ( disabled )
    ///it is a candidate for garbage collection, and if there is a long interval, it goes away. Now we just keep it running and ignore
    ///the ticks in the "STAY" mode.</para></remarks>
    private System.Windows.Forms.Label m_lblCompanyName;
    ///<summary>Form progress bar available to user for completion display.</summary>
    ///<remarks>Progress bar percentage ranges between 0 and 100.</remarks>
    private System.Windows.Forms.ProgressBar m_pbar1;
    ///<summary>Form label for displaying the Assembly Title.</summary>
    ///<remarks>Value obtained from the Assembly "Title" attribute.</remarks>
    private System.Windows.Forms.Label m_lblAssemblyTitle;
    ///<summary>Component container for all the forms m_components.</summary>
    ///<remarks>.</remarks>
    private System.ComponentModel.IContainer components;  //cannot rename, wizard likes this
    #endregion

    ///<summary>Constructor.</summary>
    ///<remarks>Instantiates all objects defined on the form and initializes them. Set the timer interval and start it.</remarks>
    public SplashForm(  )
    {
      InitializeComponent();
      this.Opacity          = .00;
      m_timer1.Interval     = TIMER_INTERVAL;
      m_timer1.Start();
    }

    ///<summary>Form Destructor.</summary>
    ///<remarks>Disposes of all objects owned by the form.</remarks>
    protected override void Dispose( bool disposing )
    {
      if( disposing )
      {
        if(components != null)
        {
          components.Dispose();
        }
      }
      base.Dispose( disposing );
    }

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(SplashForm));
      this.m_lblStatus = new System.Windows.Forms.Label();
      this.m_lblAssemblyTitle = new System.Windows.Forms.Label();
      this.m_lblProductVersion = new System.Windows.Forms.Label();
      this.m_pic1 = new System.Windows.Forms.PictureBox();
      this.m_lblCompanyName = new System.Windows.Forms.Label();
      this.m_pbar1 = new System.Windows.Forms.ProgressBar();
      this.m_timer1 = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // m_lblStatus
      // 
      this.m_lblStatus.BackColor = System.Drawing.Color.Transparent;
      this.m_lblStatus.Location = new System.Drawing.Point(18, 132);
      this.m_lblStatus.Name = "m_lblStatus";
      this.m_lblStatus.Size = new System.Drawing.Size(416, 25);
      this.m_lblStatus.TabIndex = 0;
      this.m_lblStatus.Text = "Starting Application";
      this.m_lblStatus.Click += new System.EventHandler(this.SplashForm_Click);
      // 
      // m_lblAssemblyTitle
      // 
      this.m_lblAssemblyTitle.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
      this.m_lblAssemblyTitle.Location = new System.Drawing.Point(132, 40);
      this.m_lblAssemblyTitle.Name = "m_lblAssemblyTitle";
      this.m_lblAssemblyTitle.Size = new System.Drawing.Size(313, 30);
      this.m_lblAssemblyTitle.TabIndex = 3;
      this.m_lblAssemblyTitle.Text = "Assembly Title";
      this.m_lblAssemblyTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.m_lblAssemblyTitle.Click += new System.EventHandler(this.SplashForm_Click);
      // 
      // m_lblProductVersion
      // 
      this.m_lblProductVersion.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold);
      this.m_lblProductVersion.Location = new System.Drawing.Point(131, 71);
      this.m_lblProductVersion.Name = "m_lblProductVersion";
      this.m_lblProductVersion.Size = new System.Drawing.Size(314, 28);
      this.m_lblProductVersion.TabIndex = 4;
      this.m_lblProductVersion.Text = "Version";
      this.m_lblProductVersion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.m_lblProductVersion.Click += new System.EventHandler(this.SplashForm_Click);
      // 
      // m_pic1
      // 
      this.m_pic1.Location = new System.Drawing.Point(2, 1);
      this.m_pic1.Name = "m_pic1";
      this.m_pic1.Size = new System.Drawing.Size(127, 127);
      this.m_pic1.TabIndex = 5;
      this.m_pic1.TabStop = false;
      this.m_pic1.Click += new System.EventHandler(this.SplashForm_Click);
      this.m_pic1.Paint += new System.Windows.Forms.PaintEventHandler(this.m_pic1_Paint);
      // 
      // m_lblCompanyName
      // 
      this.m_lblCompanyName.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold);
      this.m_lblCompanyName.Location = new System.Drawing.Point(131, 4);
      this.m_lblCompanyName.Name = "m_lblCompanyName";
      this.m_lblCompanyName.Size = new System.Drawing.Size(315, 32);
      this.m_lblCompanyName.TabIndex = 6;
      this.m_lblCompanyName.Text = "Company";
      this.m_lblCompanyName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.m_lblCompanyName.Click += new System.EventHandler(this.SplashForm_Click);
      // 
      // m_pbar1
      // 
      this.m_pbar1.Location = new System.Drawing.Point(133, 104);
      this.m_pbar1.Name = "m_pbar1";
      this.m_pbar1.Size = new System.Drawing.Size(312, 14);
      this.m_pbar1.TabIndex = 7;
      this.m_pbar1.Click += new System.EventHandler(this.SplashForm_Click);
      // 
      // m_timer1
      // 
      this.m_timer1.Tick += new System.EventHandler(this.m_timer1_Tick);
      // 
      // SplashForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.SystemColors.Control;
      this.ClientSize = new System.Drawing.Size(447, 162);
      this.Controls.Add(this.m_pbar1);
      this.Controls.Add(this.m_lblCompanyName);
      this.Controls.Add(this.m_pic1);
      this.Controls.Add(this.m_lblProductVersion);
      this.Controls.Add(this.m_lblAssemblyTitle);
      this.Controls.Add(this.m_lblStatus);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "SplashForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "SplashForm";
      this.TopMost = true;
      this.Click += new System.EventHandler(this.SplashForm_Click);
      this.Load += new System.EventHandler(this.SplashForm_Load);
      this.ResumeLayout(false);

    }
    #endregion

    // ************* Static Methods *************** //
    // All static methods permit the invocation of the functions with no reference to the object
    // from anywhere in the other forms

    // ----------------------- R u n S p l a s h ------------------------
    //
    ///<summary>Method for the thread to execute on</summary>
    ///<returns>void</returns>
    ///<remarks>Instantiates a new SplashForm and attaches it to the application.</remarks>
    //
    // ------------------------------------------------------------------
    static private void RunSplash()
    {
      ms_frmSplash = new SplashForm();
      Application.Run( ms_frmSplash );
    }

    // -------------------------- S h o w I t ---------------------------
    //
    ///<summary>A static method to use defaults and show the SplashForm.</summary>
    ///<returns>void</returns>
    ///<remarks>Window placement is on center of screen, mode is GOAWAY and no progress bar.</remarks>
    // 
    // ------------------------------------------------------------------
    static public void ShowIt()
    {  // Make sure it's only launched once.

      if( ms_frmSplash != null )
        return;

      ms_strWinPlacement = "";
      ms_eMode = E_SPLASH_MODE.GOAWAY;
      ms_ynPercentBar = false;
      SplashThreadStart();
    }
    
    // -------------------------- S h o w I t ---------------------------
    //
    ///<summary>A static method to select progress bar visibility and show the SplashForm.</summary>
    ///<param name='ynPercentBar'>Visibility of progress bar.</param>
    ///<returns>void</returns>
    /// <remarks>Window placement is on center of screen, mode is GOAWAY.</remarks>
    //
    // ------------------------------------------------------------------
    static public void ShowIt(
      bool            ynPercentBar )
    {
      // Make sure it's only launched once.
      if( ms_frmSplash != null )
        return;
     
      ms_strWinPlacement = "";
      ms_eMode = E_SPLASH_MODE.GOAWAY;
      ms_ynPercentBar = ynPercentBar;
      SplashThreadStart();
    }
    
    // -------------------------- S h o w I t ---------------------------
    //
    ///<summary>A static method to select progress bar visibility, display mode and show the SplashForm.</summary>
    ///<param name='ynPercentBar'>Visibility of progress bar.</param>
    ///<param name='emode'>Display mode option.</param>
    ///<returns>void</returns>
    ///<remarks>Window placement is on center of screen.</remarks>
    // 
    // ------------------------------------------------------------------
    static public void ShowIt(
      bool            ynPercentBar,
      E_SPLASH_MODE   emode )
    {
      // Make sure it's only launched once.
      if( ms_frmSplash != null )
        return;

      ms_strWinPlacement = "";
      ms_eMode = emode;
      ms_ynPercentBar = ynPercentBar;
      SplashThreadStart();
    }

    // -------------------------- S h o w I t ---------------------------
    // 
    ///<summary>A static method to select progress bar visibility, display mode, window placement, and show the SplashForm.</summary>
    ///<param name='ynPercentBar'>Visibility of progress bar.</param>
    ///<param name='emode'>Display mode option.</param>
    ///<param name='strWinPlacement'>Window placement string "Top,Left,Width,Height".</param>
    ///<returns>void</returns>
    ///<remarks>User selects progress bar visibility, display mode and window placement.</remarks>
    //
    // ------------------------------------------------------------------
    static public void ShowIt(
      bool            ynPercentBar,
      E_SPLASH_MODE   emode,
      string          strWinPlacement )
    {
      // Make sure it's only launched once.
      if( ms_frmSplash != null )
        return;

      ms_strWinPlacement = strWinPlacement;
      ms_eMode = emode;
      ms_ynPercentBar = ynPercentBar;
      SplashThreadStart();
    }

    
    // --------------- S p l a s h T h r e a d S t a r t ----------------
    // 
    ///<summary>A static method to create the thread and start it.</summary>
    ///<returns>void.</returns>
    ///<remarks>Creates and spawns a new thread for the Splash form and its timer to run.</remarks>
    //
    // ------------------------------------------------------------------
    static private void SplashThreadStart()
    {

      ms_thrdSplash = new Thread( new ThreadStart( SplashForm.RunSplash ));
      ms_thrdSplash.IsBackground = true;
      ms_thrdSplash.ApartmentState = ApartmentState.STA;
      ms_thrdSplash.Start();
    }


    // ----------------------- f r m S p l a s h ------------------------
    //
    ///<summary>A static method to obtain the SplashForm instantiation reference.</summary>
    // ------------------------------------------------------------------
    static public SplashForm frmSplash 
    {
      get
      {
        return ms_frmSplash;
      } 
    }


    // ------------------------- G o A w a y  --------------------------
    // 
    ///<summary>A static method to make the SplashForm go away.</summary>
    ///<returns>void.</returns>
    ///<remarks>A procedure which initiates a disappearing sequence for the Splash form. Generally this only needs
    ///to be called if the form was instantiated in the "STAY" mode. </remarks>
    //
    // ------------------------------------------------------------------
    static public void GoAway()
    {

      if(   ( ms_frmSplash == null )
         || ( ms_frmSplash.IsDisposed == true ) )
        return;

      if( ms_eMode == E_SPLASH_MODE.STAY )
      {
        ms_eMode = E_SPLASH_MODE.GOAWAY;
        if( ms_frmSplash.m_eState == E_SPLASH_STATE.OPAQUE )
        {
          ms_frmSplash.m_eState = E_SPLASH_STATE.BECOMING_TRANSPARENT;
        }
      }

    }

    // ------------------- m _ t i m e r 1 _ T i c k --------------------
    //
    ///<summary>Handle the timer tick event.</summary>
    ///<param name='sender'>Timer object sending the event.</param>
    ///<param name='e'>Timer Tick Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>On a timer tick we use the state indicator to determine whether
    /// we are becoming opaque, becoming transparent, or showing for a predetermined
    /// period of time. If our mode is GOAWAY then after the showing interval has ended
    /// we set the state to becoming transparent to disappear and exit.
    ///<para>If the form is defined as a GOAWAY form then the sequence the timer will got through is</para>
    ///<para>BECOMING_OPAQUE  -- SHOWING(ShowTime)  -- BECOMING_TRANSPARENT</para>
    ///<para>If the form is defined as a STAY form then the sequence is</para>
    ///<para>BECOMING_OPAQUE -- OPAQUE( until a GoAway request ) -- BECOMING_TRANSPARENT</para>
    ///</remarks>
    //
    // ------------------------------------------------------------------
    private void m_timer1_Tick(
      object                sender,
      System.EventArgs      e )
    {
      switch( m_eState )
      {
        case E_SPLASH_STATE.OPAQUE:  // This is effectively a don't care.
          return;

        case E_SPLASH_STATE.BECOMING_OPAQUE:  // revealing
          this.Opacity += INCREMENT;
          if( this.Opacity >= 1 )
          {
            if( ms_eMode == E_SPLASH_MODE.GOAWAY )
            {
              m_eState = E_SPLASH_STATE.SHOWING;  // show for show time
            }
            else // its E_SPLASH_MODE.STAY 
            {
              m_eState = E_SPLASH_STATE.OPAQUE;  // Let the user make us go away
            }
          }
          break;

        case E_SPLASH_STATE.SHOWING: // showing
          m_s32ShowTime--;
          if( m_s32ShowTime <= 0 )
          {
            m_eState = E_SPLASH_STATE.BECOMING_TRANSPARENT;  // show for a while
          }
          break;

        case E_SPLASH_STATE.BECOMING_TRANSPARENT: // disappearing
          this.Opacity -= DECREMENT;
          if( this.Opacity <= 0 )
          {
            m_timer1.Stop();
            this.TopMost = false;
            this.Close();
            ms_thrdSplash = null;	// we don't need these any more.
            ms_frmSplash = null;
            m_eState = E_SPLASH_STATE.CLOSED;
          }
          break;
      }
    }

    // ----------------------- S e t S t a t u s ------------------------
    //
    ///<summary> A static method to set the status string.</summary>
    ///<param name='strStatus'>Status string to be displayed to the user.</param>
    ///<returns>void.</returns>
    ///<remarks>Procedure to change the status string displayed to the user.</remarks>
    //
    // ------------------------------------------------------------------
    static public void SetStatus(
      string                strStatus )
    {
      if( ms_frmSplash != null )
      {
        ms_frmSplash.SetStatusOnForm( strStatus );
      }
    }

    // ----------------------- S e t S t a t u s ------------------------
    //
    ///<summary>A static method to set the status and to update the progress bar.</summary>
    ///<param name='strStatus'>Status string to be displayed to the user.</param>
    ///<param name='s32Percent'>Int32 value ranging between 0 and 100 to be displayed by progress bar.</param>
    ///<returns>void.</returns>
    ///<remarks>Procedure to change the status string displayed to the user and to update the progress
    /// bar percentage.</remarks>
    //
    // ------------------------------------------------------------------
    static public void SetStatus(
      string                strStatus,
      Int32                 s32Percent )
    {
      if( ms_frmSplash != null )
      {
        ms_frmSplash.SetPercentageOnForm( s32Percent );  // here is where we call through the static into the object
        ms_frmSplash.SetStatusOnForm( strStatus );
      }
    }

    // ---------------------- S e t P e r c e n t -----------------------
    //
    ///<summary>A static method to update the progress bar output.</summary>
    ///<param name='s32Percent'>Int32 value ranging between 0 and 100.</param>
    ///<returns>void.</returns>
    ///<remarks>Procedure to update the progress bar percentage.</remarks>
    //
    // ------------------------------------------------------------------
    static public void SetPercent(
      Int32                 s32Percent )
    {
      if( ms_frmSplash != null )
      {
        ms_frmSplash.SetPercentageOnForm( s32Percent );
      }
    }

    // P r i v a t e   m e t h o d s   e x e c u t e d   i n   t h e   f o r m   c o n t e x t -

    //--------------- S p l a s h S c r e e n _ L o a d ----------------
    //
    ///<summary>Handles the form load event.</summary>
    ///<param name='sender'>Form object sending the event.</param>
    ///<param name='e'>Event arguments for a form load.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure attempts to center the splash form over top its
    /// parent window, the thing is it can be called before the parent window
    /// is instantiated therefore we provide the Window Placement string and
    /// perform the calculations for its screen placement. If the Window Placement 
    /// string supplied is empty we use the form's center on screen default option.
    ///</remarks>
    //
    // ------------------------------------------------------------------
    private void SplashForm_Load(
      object                sender,
      System.EventArgs      e )
    {
      string[]              astrValues          = null;
      Int32                 s32Left             = 10;
      Int32                 s32Top              = 10;
      Int32                 s32Width            = 477;
      Int32                 s32Height           = 162;
      Int32                 s32X;
      Int32                 s32Y;
      Int32                 s32WidthScrn;
      Int32                 s32HeightScrn;
      BoundsSpecified       bnds;
  
      AssemblyInfoGet();

      if( ms_ynPercentBar == false )
      {
        m_pbar1.Visible = false;
      }

      if( ms_strWinPlacement.Length < 1 )
        return;  // us the default centering

      astrValues = ms_strWinPlacement.Split( ',' );
      if( astrValues.Length > 3 )
      {
        s32Left    = Convert.ToInt32( astrValues[0] );
        s32Top     = Convert.ToInt32( astrValues[1] );
        s32Width   = Convert.ToInt32( astrValues[2] );
        s32Height  = Convert.ToInt32( astrValues[3] );
      }

      s32WidthScrn = SCRN.PrimaryScreen.Bounds.Width;
      s32HeightScrn = SCRN.PrimaryScreen.Bounds.Height;

      // The following exercise simply makes sure that when we pop up 
      // on the screen that we are centered in or over our parent window
      // and or are on the screen, a.k.a. MainWinDetails
      // In fact, our parent form may not even be instantiated yet
      // First we will check the sanity of the passed in values
      if( s32Width >= s32WidthScrn )
      {
        s32Width = s32WidthScrn;
        s32Left = 0;
      }
      if( s32Height >= s32HeightScrn )
      {
        s32Height = s32HeightScrn;
        s32Top = 0;
      }
      if( s32Left < 0 )
      {
        s32Left = 0;   // if off screen on left, move back right
      }

      // Am I less wide than my parent
      if( ( s32Width > this.Width ) )
      {   // I will fit in horizontally
        s32X = s32Left + ( ( s32Width - this.Width ) / 2);
      }
      else
      {   // I am wider, make sure on screen, try to center over top but not off screen
        s32X = s32Left - ( ( this.Width - s32Width ) / 2 );
        if( ( s32X < 0 ) )
        {
          s32X = 0;
        }
      }

      // we will always make sure we are completely on screen
      if( ( ( s32X + this.Width ) > s32WidthScrn ) ) 
      {   // move to the right until whole window on screen
        s32X = s32WidthScrn - this.Width;
      }

      // Am I less tall than the my parent
      if( ( s32Height > this.Height) ) 
      {   // I will fit in Vertically, offset half the difference
        s32Y = s32Top + ( ( s32Height - this.Height ) / 2 );
      } 
      else 
      {   // I am taller, make sure on screen
        s32Y = s32Top - ( ( this.Height - s32Height ) / 2 );
        if( ( s32Y < 0 ) )
        {
          s32Y = 0;
        }
      }
     
      if( ( ( s32Y + this.Height ) > s32HeightScrn ) )
      {   // move back up so bottom is on screen
        s32Y = s32HeightScrn - this.Height;
      }

      bnds = BoundsSpecified.X | BoundsSpecified.Y;
      this.SetBounds(s32X, s32Y, 0, 0, bnds);
    }


    // Internal method for setting the percentage of the progress bar.
    // ------------- S e t P e r c e n t a g e O n F o r m --------------
    //
    ///<summary>Form context procedure to adjust the percentage of the progress bar.</summary>
    ///<param name='s32Percent'>Int32 value to range between 0 and 100.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure passes the percentage value to the progress bar object.</remarks>
    //
    // ------------------------------------------------------------------
    private void SetPercentageOnForm(
      Int32                 s32Percent )
    {
      if( s32Percent > 100 )
        s32Percent = 100;

      if( s32Percent < 0 )
        return;

      m_pbar1.Value = s32Percent;
    }

    // ----------------- S e t S t a t u s O n F o r m ------------------
    //
    ///<summary>Procedure to effect a status string change.</summary>
    ///<returns>void.</returns>
    ///<remarks>Form context procedure to update the status label string.</remarks>
    //
    // ------------------------------------------------------------------
    private void SetStatusOnForm( 
      string                strStatus )
    {

      m_lblStatus.Text = strStatus;  // else we will catch it with timer
    }

    // ----------------- A s s e m b l y I n f o G e t ------------------
    //
    ///<summary>Procedure to obtain information from the assembly attributes
    ///which is not part of the Application object.</summary>
    ///<returns>void.</returns>
    ///<remarks>The Application object provides us with most of the assembly data, but not all 
    /// of it. This procedure adjusts the start up directory to be the source directory regardless
    /// of whether we were in release or debug mode, so that data files local to the application
    /// can be found.
    ///<para>The Assembly Title string is also obtained for our window top label.</para>
    ///</remarks>
    //
    // ------------------------------------------------------------------
    private void AssemblyInfoGet()
    {
      Assembly                        objAssembly;
      AssemblyTitleAttribute          attrTitle;
    //AssemblyDescriptionAttribute    attrDesc;
    //AssemblyTrademarkAttribute      attrTMark;   
      object[]                        aobjAttrs;
      Type                            typeObj;
      int                             s32IX;

      m_lblProductVersion.Text = Application.ProductVersion;
      m_lblCompanyName.Text = Application.CompanyName;
       
      m_strAppPath = Application.StartupPath;
      // we want to make the root up from "\bin\debug" or "\bin\Release"
      s32IX = m_strAppPath.IndexOf( "\\bin\\" );
      if( s32IX > 0 ) 
      {   // "bin\" is in the string
        m_strAppPath = m_strAppPath.Substring( 0, s32IX );
      }   // it has no '\' at the end

      objAssembly = System.Reflection.Assembly.GetExecutingAssembly();
      aobjAttrs = objAssembly.GetCustomAttributes( false );
      foreach ( object obj in  aobjAttrs )
      {
        typeObj = obj.GetType();
        if ( typeObj == typeof(AssemblyTitleAttribute))
        {
          attrTitle = (System.Reflection.AssemblyTitleAttribute)obj;
          m_lblAssemblyTitle.Text = attrTitle.Title;
        }
        //else if ( typeObj == typeof(AssemblyDescriptionAttribute))
        //{
        //  attrDesc = (System.Reflection.AssemblyDescriptionAttribute)obj;
        //  g_strDescription = attrDesc.Description;
        //}
        //else if ( typeObj == typeof(AssemblyTrademarkAttribute))
        //{
        //  attrTMark = (System.Reflection.AssemblyTrademarkAttribute)obj;
        //  g_strAppHistory = attrTMark.Trademark;
        //}
      } // end of aobjAttrs iteration
    }  // end of AssemblyInfoGet()

    // ----------------- S p l a s h F o r m _ C l i c k ---------------
    //
    ///<summary>Handles effectively any click on the Splash form.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event Argument Object.</param>
    ///<returns>void.</returns>
    ///<remarks>All objects on the Splash form have their click event come
    /// here, that provides a mechanism to start a disappearing act if the 
    /// window is defined in the STAY mode. The click to disappear will no work
    /// until the form has become completely opaque.</remarks>
    //
    // ------------------------------------------------------------------
    private void SplashForm_Click(
      object                sender,
      System.EventArgs      e )
    {
      GoAway();
    }


    // -------------------- m _ p i c 1 _ P a i n t ---------------------
    //
    ///<summary>Handles the m_pic1 paint event.</summary>
    ///<param name='sender'>The picture box object sending the event.</param>
    ///<param name='ePaintArgs'>Paint Arguments Object.</param>
    ///<returns>void.</returns>
    ///<remarks>When a Invalidation or exposure event occurs this procedure is
    /// called to repaint the supplier bitmap. This procedure walks through the 
    /// complete bitmap looking for white pixels and replacing them with the 
    /// control background pixels. This effective makes WHITE the transparency
    /// color.</remarks>
    //
    // ------------------------------------------------------------------
    private void m_pic1_Paint(
      object                sender,
      System.Windows.Forms.PaintEventArgs ePaintArgs )
    {
      string                strPathFile;
      Bitmap                bmp;
      Int32                 s32IX;
      Int32                 s32Xix;
      Int32                 s32Yix;
      Color                 colPixel;
      Color                 colBG = System.Drawing.SystemColors.Control;
      
      strPathFile = Application.StartupPath;
      // we want to make the root up from "\bin\Debug" or "\bin\Release" if in the IDE
      s32IX = strPathFile.IndexOf( "\\bin\\Debug" );
      if( s32IX < 0 )
      {
        s32IX = strPathFile.IndexOf( "\\bin\\Release" );
      }
      if( s32IX > 0 ) 
      {   // "bin\" is in the string
        strPathFile = strPathFile.Substring( 0, s32IX );
      }   // it has no '\' at the 
      strPathFile += "\\Logo.bmp";
      if( File.Exists( strPathFile ) == true )
      {
        bmp = new Bitmap(strPathFile);
        // not we will examine every pixel in the bitmap and replace the
        // white ones with the control background color
        for( s32Yix = 0; s32Yix < bmp.Height; s32Yix++ )
        {
          for( s32Xix = 0; s32Xix < bmp.Width; s32Xix++)
          {
            colPixel = bmp.GetPixel(s32Xix, s32Yix);
            if(   ( colPixel.R == 255 ) 
               && ( colPixel.G == 255 )
               && ( colPixel.B == 255 ) ) 
            {
              bmp.SetPixel( s32Xix, s32Yix, colBG );
            }
          } // bitmap pixels on the line
        } // bitmap line

        // we will center the logo if it is smaller
        s32Xix = 0;
        if( m_pic1.Width > bmp.Width )
        {
          s32Xix = (Int32)( ( m_pic1.Width - bmp.Width ) / 2 );
        }
        s32Yix = 0;
        if( m_pic1.Height > bmp.Height  )
        {
          s32Yix = (Int32)( ( m_pic1.Height - bmp.Height ) / 2 );
        }
        ePaintArgs.Graphics.DrawImageUnscaled( bmp, s32Xix, s32Yix );
        bmp.Dispose();
      } //bitmap file exists
    }
  }
}
