using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace AlbumSurfer
{
	///<summary>Options Form Object Definition.</summary>
	///<remarks>Defines the Options Form and all objects owned by it.</remarks>
	public class OptionsForm : System.Windows.Forms.Form
	{
    ///<summary>Forms treeview object.</summary>
    ///<remarks>This object permits selection of multiple user control option pages.</remarks>
    private System.Windows.Forms.TreeView m_tvw1;
    ///<summary>Forms splitter object.</summary>
    ///<remarks>This object permits selection of display partitioning between the treeview and user control.</remarks>
    private System.Windows.Forms.Splitter m_spl1;
    ///<summary>User control object.</summary>
    ///<remarks>this is page 0 of optional application parameters.</remarks>
    private AlbumSurfer.Page0Uctrl m_uctlPage0;
    ///<summary>User control object.</summary>
    ///<remarks>This is page 1 of optional application parameters.</remarks>
    private AlbumSurfer.Page1Uctrl m_uctlPage1;
    ///<summary>Required designer variable. </summary>
    ///<remarks>Container object for all objects owned by the Options form.</remarks>
    private System.ComponentModel.Container components = null;

    // --------------------- O p t i o n s F o r m ----------------------
    //
    ///<summary>Class constructor for an OptionsForm</summary>
    ///<returns>void</returns>
    ///<remarks>Call InitializeComponent which instantiates and initializes all objects owned by the form and managed by the wizard.</remarks>
    // 
    // ------------------------------------------------------------------
    public OptionsForm()
		{
			InitializeComponent();

    //  tvw1.SelectedNode = tvw1.Nodes[ 1 ];
		}

		///<summary>Clean up any resources being used.</summary>
	  ///<remarks>Effectively the destructor, object collected by the garbage collection.</remarks>
    protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		    #region Windows Form Designer generated code
		    /// <summary>
		    /// Required method for Designer support - do not modify
		    /// the contents of this method with the code editor.
		    /// </summary>
		    private void InitializeComponent()
		    {
          System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OptionsForm));
          this.m_tvw1 = new System.Windows.Forms.TreeView();
          this.m_spl1 = new System.Windows.Forms.Splitter();
          this.m_uctlPage1 = new AlbumSurfer.Page1Uctrl();
          this.m_uctlPage0 = new AlbumSurfer.Page0Uctrl();
          this.SuspendLayout();
          // 
          // m_tvw1
          // 
          this.m_tvw1.Dock = System.Windows.Forms.DockStyle.Left;
          this.m_tvw1.HideSelection = false;
          this.m_tvw1.ImageIndex = -1;
          this.m_tvw1.Location = new System.Drawing.Point(0, 0);
          this.m_tvw1.Name = "m_tvw1";
          this.m_tvw1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
                                                                           new System.Windows.Forms.TreeNode("Options", new System.Windows.Forms.TreeNode[] {
                                                                                                                                                              new System.Windows.Forms.TreeNode("Interval"),
                                                                                                                                                              new System.Windows.Forms.TreeNode("Jpeg")})});
          this.m_tvw1.SelectedImageIndex = -1;
          this.m_tvw1.Size = new System.Drawing.Size(121, 374);
          this.m_tvw1.TabIndex = 0;
          this.m_tvw1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.m_tvw1_AfterSelect);
          // 
          // m_spl1
          // 
          this.m_spl1.Location = new System.Drawing.Point(121, 0);
          this.m_spl1.Name = "m_spl1";
          this.m_spl1.Size = new System.Drawing.Size(3, 374);
          this.m_spl1.TabIndex = 1;
          this.m_spl1.TabStop = false;
          // 
          // m_uctlPage1
          // 
          this.m_uctlPage1.Dock = System.Windows.Forms.DockStyle.Fill;
          this.m_uctlPage1.Location = new System.Drawing.Point(124, 0);
          this.m_uctlPage1.Name = "m_uctlPage1";
          this.m_uctlPage1.Size = new System.Drawing.Size(564, 374);
          this.m_uctlPage1.TabIndex = 2;
          this.m_uctlPage1.Visible = false;
          // 
          // m_uctlPage0
          // 
          this.m_uctlPage0.Dock = System.Windows.Forms.DockStyle.Fill;
          this.m_uctlPage0.Location = new System.Drawing.Point(124, 0);
          this.m_uctlPage0.Name = "m_uctlPage0";
          this.m_uctlPage0.Size = new System.Drawing.Size(564, 374);
          this.m_uctlPage0.TabIndex = 3;
          // 
          // OptionsForm
          // 
          this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
          this.ClientSize = new System.Drawing.Size(688, 374);
          this.Controls.Add(this.m_uctlPage0);
          this.Controls.Add(this.m_uctlPage1);
          this.Controls.Add(this.m_spl1);
          this.Controls.Add(this.m_tvw1);
          this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
          this.Name = "OptionsForm";
          this.Text = "OptionsForm";
          this.Closing += new System.ComponentModel.CancelEventHandler(this.OptionsForm_Closing);
          this.Load += new System.EventHandler(this.OptionsForm_Load);
          this.ResumeLayout(false);

        }
		    #endregion

    //------------- O p t i o n s F o r m _ C l o s i n g --------------
    //
    ///<summary>Handles the ? event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Change the visibility of each user control to invisible permitting them to preserve whatever they must.</remarks>
    //
    //------------------------------------------------------------------
    void OptionsForm_Closing(
      object                sender,
      System.ComponentModel.CancelEventArgs e )
    {
      m_uctlPage0.Visible = false;
      m_uctlPage1.Visible = false;
    }

    //---------------- O p t i o n s F o r m _ L o a d -----------------
    //
    ///<summary>Handles the ? event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>This event would typically be used to init any form any child data. </remarks>
    //
    //------------------------------------------------------------------
    void OptionsForm_Load(
      object                sender,
      System.EventArgs      e )
    {
     m_tvw1.ExpandAll();
      m_uctlPage0.m_ynSuspendLayout = false; // you can pay attention to events now
      m_uctlPage1.m_ynSuspendLayout = false;
    }

    //-------------- m _ t v w 1 _ A f t e r S e l e c t ---------------
    //
    ///<summary>Handles the treeview after select event.</summary>
    ///<param name='sender'>Object sending the event.</param>
    ///<param name='e'>Event arguments.</param>
    ///<returns>void.</returns>
    ///<remarks>Sets up the mask correctly from after select to show the 
    ///appropriate user control.</remarks>
    //
    //------------------------------------------------------------------
    void m_tvw1_AfterSelect(
      object                sender,
      System.Windows.Forms.TreeViewEventArgs e )
    {
      UInt32                u32Mask;
      switch( m_tvw1.SelectedNode.Index )
      {
          // u32Mask = 1 << tvw1.SelectedNode.Index;
        case 0:      u32Mask = 0x0001;      break;
        case 1:      u32Mask = 0x0002;      break;
        default:     u32Mask = 0x0001;      break;
      }
      ShowUctrl( u32Mask );
    }

    //----------------------- S h o w U c t r l ------------------------
    //
    ///<summary>Procedure which is passed a mask indicating the user control to display.</summary>
    ///<param name='u32Mask'>Binary mask used to indicate user control to display.</param>
    ///<returns>void.</returns>
    ///<remarks>Mechanism to show a user control. If the visible control has changed we make the old one
    ///invisible thereby permitting it to preserve any necessary data. Two user controls will have
    ///visibility event the old visible one becomes invisible, and the new one become visible.</remarks>
    //
    //------------------------------------------------------------------
    void ShowUctrl(
      UInt32                u32Mask )
    {

      m_uctlPage0.Visible = ( (u32Mask & 0x0001) != 0 );
      m_uctlPage1.Visible = ( (u32Mask & 0x0002) != 0 );

      // Change the the form text to represent the user control being shown
      switch( u32Mask )
      {
        case 0x0001:
          this.Text = "Auto Show Interval";
          break;
        case 0x0002:
          this.Text = "Jpeg Save Quality";
          break;
      }
    }
	}
}
