// 05.05.19.19 completed comment work
using System;
using System.Data;
using System.IO;              // for File
using System.Windows.Forms;   // for Application

namespace AlbumSurfer
{
  ///<summary> Class for the storage and retrieval of Application persistent data values to a local XML data file.</summary>
  ///<remarks> This module is meant to be a transparent substitute for the Registry Class 
  /// and provides all the function calls that module provided. This difference is that 
  /// this module stores the persistent data in a local XML file instead of the registry.</remarks>
  public class RegXmlClass
  {
    ///<summary>Default XML dataset table name.</summary>
    ///<remarks>The table name defaults to "tblValues".</remarks>
    public const string STR_TBL_NAME        = "tblValues";
    /// <summary>Class storage location for XML data path file string.</summary>
    /// <remarks>This is the location of the XML file.</remarks>
    private string            m_strPathFile;
    ///<summary>Class storage of the dataset that represents the stored data in the XML file.</summary>
    ///<remarks>This dataset get loaded at initialization time and saved with every write of the class.</remarks>
    private RegXmlDataSet     m_dset;
    ///<summary>Class storage location for selected Registry Root string.</summary>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks>
    private string            m_strRoot         = "Software";
    ///<summary>Class storage location for selected Registry Shop string.</summary>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks>
    private string            m_strShop         = Application.CompanyName;
    ///<summary>Class storage location for selected Registry Application string.</summary>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks>
    private string            m_strAppName      = Application.ProductName;
    ///<summary>Class storage location for selected Registry Section string.</summary>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks>
    private string            m_strSection      = "Config";
    ///<summary>Class storage location for the XML filename string.</summary>
    ///<remarks>This defaults to "AppConfig.xml".</remarks>
    private string            m_strXmlFilename  = "AppConfig.xml";

    // --------------------- R e g X m l C l a s s ----------------------
    //
    ///<overloads>This method has three overloads.</overloads>
    ///<summary>Constructor to maintain compatibility with the Registry version.</summary>
    ///<remarks>In the registry registry version this invocation takes all the defaults.</remarks>
    //
    //------------------------------------------------------------------
    public RegXmlClass()
    {
      m_dset = new RegXmlDataSet();
      DoesDBExist();
    }

    // --------------------- R e g X m l C l a s s ----------------------
    //
    ///<summary>Constructor to maintain compatibility with the Registry version.</summary>
    ///<param name='strAppName'>Application Name string to be used for registry key path.</param>
    ///<remarks>In the registry registry version this invocation provides for a Application Name argument.</remarks>
    //
    //------------------------------------------------------------------
    public RegXmlClass(
      string                strAppName )
    {
      m_strAppName = strAppName;
      
      m_dset = new RegXmlDataSet();
      DoesDBExist();
    }

    // --------------------- R e g X m l C l a s s ----------------------
    //
    ///<summary>Constructor to maintain compatibility with the Registry version.</summary>
    ///<param name='strAppName'>Application Name string to be used for registry key path.</param>
    ///<param name='strSection'>Section Name string to be used for registry key path.</param>
    ///<remarks>In the registry registry version this invocation provides for two arguments.</remarks>
    //
    //------------------------------------------------------------------
    public RegXmlClass(
      string                strAppName,
      string                strSection )
    {
      m_strAppName    = strAppName;
      m_strSection    = strSection;

      m_dset = new RegXmlDataSet();
      DoesDBExist();
    }



    // --------------------- L o n g G e t _ l n g ----------------------
    //
    ///<summary>Returns a long value, or the default if none exists, from the persistent storage.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pobjDefault'>Reference to a default object if no registry value exists.</param>
    ///<returns>Int32.
    ///<para> If no value exists and the pobjDefault is null, returns null.</para></returns>
    ///<remarks>This procedure returns a long data value from the registry at the key referenced.
    ///<para>Long is actually a misnomer, in .NET a long is an Int64 and if you present that to 
    ///the Net Registry utilities as a value it knows it will not fit in a Int32(DW),
    /// hence it promotes it to a string to prevent a loss of data.</para>
    /// </remarks>
    //
    //------------------------------------------------------------------
    public Int32 LongGet_lng(
      string                pstrKey,
      object                pobjDefault )
    {
            
      String                strFilter;
      Int32                 s32Val      = 0;
      RegXmlDataSet.tblValuesRow[]  adrows;
      RegXmlDataSet.tblValuesRow    drow;

      strFilter = string.Format( "txtKey='{0}'", pstrKey );
      adrows = (RegXmlDataSet.tblValuesRow[])m_dset.tblValues.Select( strFilter );
      if( adrows.Length < 1 )  // we need to create it
      {
        drow          = m_dset.tblValues.NewtblValuesRow();
        drow.lngVal   = (Int32)pobjDefault;
        drow.txtKey   = pstrKey;
        m_dset.tblValues.Rows.Add( drow );
        m_dset.WriteXml( m_strPathFile );
      }
      else
      {
        drow = adrows[0];
      }

      s32Val = drow.lngVal;

      return s32Val;
    }

    // ------------------- S t r i n g G e t _ s t r --------------------
    //
    ///<summary>Returns a string value, or the default if none exists, from the persistent storage.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pstrDefault'>Reference to a default object if no registry value exists.</param>
    ///<returns>string.
    ///<para> If no value exists and the pstrDefault is null, returns null.</para></returns>
    ///<remarks>This procedure returns a string from the registry at the key referenced.</remarks>
    //
    //------------------------------------------------------------------
    public string StringGet_str(
      string                pstrKey,
      string                pstrDefault )
    {
      String                strFilter;
      string                strVal        = "";
      RegXmlDataSet.tblValuesRow[]  adrows;
      RegXmlDataSet.tblValuesRow    drow;

      strFilter = string.Format( "txtKey='{0}'", pstrKey );
      adrows = (RegXmlDataSet.tblValuesRow[])m_dset.tblValues.Select( strFilter );
      if( adrows.Length < 1 )  // we need to create it
      {
        drow = m_dset.tblValues.NewtblValuesRow();
        drow.txtVal = pstrDefault;
        drow.txtKey = pstrKey;
        m_dset.tblValues.Rows.Add( drow );
        m_dset.WriteXml( m_strPathFile );
      }
      else
      {
        drow = adrows[0];
      }

      strVal = drow.txtVal;

      return strVal;
    }

    //------------------- B i n a r y G e t _ a r r --------------------
    //
    ///<summary>Returns a byte array value, or the default if none exists, from the persistent storage.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pau8Default'>Reference to a default object if no registry value exists.</param>
    ///<returns>byte[].
    ///<para>If no value exists and the pabytDefault is null, returns null.</para></returns>
    ///<remarks>This procedure returns a byte array of data from the registry at the key referenced.</remarks>
    //
    //------------------------------------------------------------------
    public byte[] BinaryGet_arr(
      string                pstrKey,
      byte[]                pau8Default )
    {
      String                strFilter;
      byte[]                au8         = { 0, };
      RegXmlDataSet.tblValuesRow[]  adrows;
      RegXmlDataSet.tblValuesRow    drow;

      strFilter = string.Format( "txtKey='{0}'", pstrKey );
      adrows = (RegXmlDataSet.tblValuesRow[])m_dset.tblValues.Select( strFilter );
      if( adrows.Length < 1 )  // we need to create it
      {
        drow = m_dset.tblValues.NewtblValuesRow();
        drow.binVal = pau8Default;
        drow.txtKey = pstrKey;
        m_dset.tblValues.Rows.Add( drow );
        m_dset.WriteXml( m_strPathFile );
      }
      else
      {
        drow = adrows[0];
      }

      return drow.binVal;
    }

    //------------------------- L o n g S e t --------------------------
    //
    ///<summary>Writes a long value to the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pobjValue'>Reference to object value to be written.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure stores a long (UInt32) in the registry at the key referenced.
    /// <para>Long is actually a misnomer, in .NET a long is an Int64 and if you present
    /// that to the Net Registry utilities as a value it knows it will not fit 
    /// in a Int32(DW), hence it promotes it to a string to prevent a loss of data.</para>
    /// <para>If the registry key does not exist it is created.</para></remarks>
    //
    //------------------------------------------------------------------
    public void LongSet(
      string                pstrKey,
      object                pobjValue )
    {
      String                strFilter;
      RegXmlDataSet.tblValuesRow[]  adrows;
      RegXmlDataSet.tblValuesRow    drow;

      strFilter = string.Format( "txtKey='{0}'", pstrKey );
      adrows = (RegXmlDataSet.tblValuesRow[])m_dset.tblValues.Select( strFilter );
      if( adrows.Length < 1 )  // we need to create it
      {
        drow = m_dset.tblValues.NewtblValuesRow();
        drow.lngVal = (Int32)pobjValue;
        drow.txtKey = pstrKey;
        m_dset.tblValues.Rows.Add( drow );
      }
      else
      {
        drow = adrows[0];
        drow.BeginEdit();
        drow.lngVal  = (Int32)pobjValue; 
        drow.EndEdit();
      }

      m_dset.WriteXml( m_strPathFile );
    }

    //----------------------- S t r i n g S e t ------------------------
    //
    ///<summary>Writes a string value to the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pstrValue'>Reference to object value to be written.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure stores a string in the registry at the key referenced.
    ///<para>If the registry key does not exist it is created.</para></remarks>
    //
    //------------------------------------------------------------------
    public void StringSet(
      string                pstrKey,
      string                pstrValue )
    {
      String                strFilter;
      RegXmlDataSet.tblValuesRow[]  adrows;
      RegXmlDataSet.tblValuesRow    drow;

      strFilter = string.Format( "txtKey='{0}'", pstrKey );
      adrows = (RegXmlDataSet.tblValuesRow[])m_dset.tblValues.Select( strFilter );
      if( adrows.Length < 1 )  // we need to create it
      {
        drow = m_dset.tblValues.NewtblValuesRow();
        drow.txtVal = pstrValue;
        drow.txtKey = pstrKey;
        m_dset.tblValues.Rows.Add( drow );
      }
      else
      {
        drow = adrows[0];
        drow.BeginEdit();
        drow.txtVal  = pstrValue;
        drow.EndEdit();
      }

      m_dset.WriteXml( m_strPathFile );
    }

    //----------------------- B i n a r y S e t ------------------------
    //
    ///<summary>Writes a byte array value to the registry key referenced.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<param name='pau8Val'>Reference to object value to be written.</param>
    ///<returns>void.</returns>
    ///<remarks>This procedure stores a byte array of data in the registry at the key referenced.
    ///<para>If the registry key does not exist it is created.</para></remarks>
    //
    //------------------------------------------------------------------
    public void BinarySet(
      string                pstrKey,
      byte[]                pau8Val )
    {
      String                strFilter;
      RegXmlDataSet.tblValuesRow[]  adrows;
      RegXmlDataSet.tblValuesRow    drow;

      strFilter = string.Format( "txtKey='{0}'", pstrKey );
      adrows = (RegXmlDataSet.tblValuesRow[])m_dset.tblValues.Select( strFilter );
      if( adrows.Length < 1 )  // we need to create it
      {
        drow = m_dset.tblValues.NewtblValuesRow();
        drow.binVal = pau8Val;
        drow.txtKey = pstrKey;
        m_dset.tblValues.Rows.Add( drow );
      }
      else
      {
        drow = adrows[0];
        drow.BeginEdit();
        drow.binVal  = pau8Val;
        drow.EndEdit();
      }

      m_dset.WriteXml( m_strPathFile );
    }


    // ----------------------- D e l e t e K e y ------------------------
    //
    ///<summary>To handle the ? message reply construction.</summary>
    ///<param name='pstrKey'>Arg1Purpose.</param>
    ///<returns>void.</returns>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks>
    //
    // ------------------------------------------------------------------
    public void DeleteKey(
      string                pstrKey )
    {
    }


    //----------------------- D e l e t e K e y ------------------------
    //
    ///<summary>Deletes a registry key value.</summary>
    ///<param name='pstrKey'>Reference to key string.</param>
    ///<returns>void.</returns>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks>
    //
    //------------------------------------------------------------------
    public void DeleteValue(
      string                pstrKey )
    {
    }

    // -------------------------- s t r A p p  -------------------------
    //
    ///<summary>App portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks> 
    // ----------------------------------------------------------------
    public string  strApp
    {
      get 
      {
        return m_strAppName;
      }
      set 
      {
        m_strAppName = value;
      }
    }

    // ------------------------- s t r R o o t ------------------------
    //
    ///<summary>Root portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks> 
    // ----------------------------------------------------------------
    public string  strRoot
    {
      get 
      {
        return m_strRoot;
      }
      set 
      {
        m_strRoot = value;
      }
    }

    // ---------------------- s t r S e c t i o n ---------------------
    //
    ///<summary>Section portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks> 
    // ----------------------------------------------------------------
    public string  strSection
    {
      get 
      {
        return m_strSection;
      }
      set 
      {
        m_strSection = value;
      }
    }

    // ------------------------- s t r S h o p ------------------------
    //
    ///<summary>Shop portion of the registry key path.</summary>
    ///<value>string.</value>
    ///<remarks>Provided to maintain compatibility with the Registry version of the class.</remarks> 
    // ----------------------------------------------------------------
    public string  strShop
    {
      get 
      {
        return m_strRoot;
      }
      set 
      {
        m_strShop = value;
      }
    }

    // --------------------- s t r F i l e n a m e --------------------
    //
    ///<summary>XML filename use for data storage.</summary>
    ///<value>string.</value>
    ///<remarks>This file contains the persistence data storage XML dataset.</remarks> 
    // ----------------------------------------------------------------
    public string  strFilename
    {
      get 
      {
        return m_strXmlFilename;
      }
      set 
      {
        m_strXmlFilename = value;
      }
    }

    //--------------------- D o e s D B E x i s t ----------------------
    //
    ///<summary>Loads the XML data file if it exists.</summary>
    ///<returns>void.</returns>
    ///<remarks>If the XML data file exists this routine loads the XML dataset with its contents</remarks>
    //
    //------------------------------------------------------------------
    private void DoesDBExist()
    {
      string                strAppPath;
      Int32                 s32IX;

      strAppPath = Application.StartupPath;
      // we want to make the root up from "\bin\debug" or "\bin\Release"
      s32IX = strAppPath.IndexOf( "\\bin\\" );
      if( s32IX > 0 ) 
      {   // "bin\" is in the string
        strAppPath = strAppPath.Substring( 0, s32IX );
      }   // it has no '\' at the end

      m_strPathFile = strAppPath + "\\" + m_strXmlFilename;
      if( File.Exists( m_strPathFile ) == true )
      {
        m_dset.ReadXml( m_strPathFile );  // Read the file into our dataset
      }
    }
  }  // End of RegXml
}
