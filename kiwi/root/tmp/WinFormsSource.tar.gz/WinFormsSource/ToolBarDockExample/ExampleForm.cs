using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using rpaulo.toolbar;

namespace ToolBarDockExample
{
	public class ExampleForm : System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.ImageList _imageList;
		private System.Windows.Forms.ToolBar _toolBar1;
		private System.Windows.Forms.ToolBarButton toolBarButton1;
		private System.Windows.Forms.ToolBarButton toolBarButton2;
		private System.Windows.Forms.ToolBarButton toolBarButton3;
		private System.Windows.Forms.ToolBarButton toolBarButton4;
		private System.Windows.Forms.ToolBarButton toolBarButton5;
		private System.Windows.Forms.ToolBarButton toolBarButton6;
		private System.Windows.Forms.ToolBarButton toolBarButton7;
		private System.Windows.Forms.ToolBarButton toolBarButton8;
		private System.Windows.Forms.ToolBarButton toolBarButton9;
		private System.Windows.Forms.ToolBarButton toolBarButton10;
		private System.Windows.Forms.ToolBarButton toolBarButton11;
		private System.Windows.Forms.ToolBarButton toolBarButton12;
		private System.Windows.Forms.ToolBar _toolBar2;
		private System.Windows.Forms.ToolBarButton toolBarButton13;
		private System.Windows.Forms.ToolBarButton toolBarButton14;
		private System.Windows.Forms.ToolBarButton toolBarButton15;
		private System.Windows.Forms.ToolBarButton toolBarButton16;
		private System.Windows.Forms.ToolBarButton toolBarButton17;
		private System.Windows.Forms.ToolBarButton toolBarButton18;
		private System.Windows.Forms.ToolBar _toolBar3;
		private System.Windows.Forms.ToolBarButton toolBarButton23;
		private System.Windows.Forms.ToolBarButton toolBarButton24;
		private System.Windows.Forms.ToolBarButton toolBarButton19;
		private System.Windows.Forms.ToolBar _toolBar4;
		private System.Windows.Forms.RichTextBox _richTextBox;
		private System.Windows.Forms.DateTimePicker _dateTimePicker;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.MenuItem menuItem18;
		private System.Windows.Forms.MenuItem menuItem19;
		private System.Windows.Forms.MenuItem menuView;
		private System.Windows.Forms.MenuItem menuViewToolbars;

		// This member manages the toolbar framework.
		ToolBarManager _toolBarManager;

		public ExampleForm()
		{
			InitializeComponent();

			_richTextBox.Text = 
				"This is an example of a toolbar framework.\n" +
				"  by Rogerio Paulo, rpaulo@bigfoot.com\n" +
				"\n" +
				"Features:\n"+
				"    float/dock bars\n"+
				"    change layout of docked bars\n"+
				"    double-click to switch from docked to floating and vice-versa\n"+
				"    show/hide bar\n"+
				"    right-click for bar view menu\n"+
				"    should work with any control\n"+
				"\n"+
				"Drop me an email if you find it useful,\n"+
				"and if you see any BUG, solve it and let me know! ;-)";

			// The parameter to the constructor sets the form where the toolbars can be docked.
			// This would be your application main form
			_toolBarManager = new ToolBarManager(this, this);


			// The control Text property is used to draw the bar name while floating
			// and on view/hide menu.
			_toolBar1.Text = "Bar #1";
			_toolBar2.Text = "Bar #2";
			_toolBar3.Text = "Bar #3";
			_toolBar4.Text = "Bar #4";

			// Add toolbar (default position)
			_toolBarManager.AddControl(_toolBar1);
			// Add toolbar (floating)
			_toolBarManager.AddControl(_toolBar2, DockStyle.None);
			// Add toolbar (left)
			_toolBarManager.AddControl(_toolBar3, DockStyle.Left);
			// Add toolbar (left, on the left of _toolBar3)
			_toolBarManager.AddControl(_toolBar4, DockStyle.Left, _toolBar3, DockStyle.Left);
			// Add control
			ToolBarDockHolder holder = _toolBarManager.AddControl(_dateTimePicker, DockStyle.Bottom); 
			// Added by mav
			holder.ToolbarTitle = "Appointment";
			holder.AllowedBorders = AllowedBorders.Top|AllowedBorders.Bottom;
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ExampleForm));
			this._imageList = new System.Windows.Forms.ImageList(this.components);
			this._toolBar1 = new System.Windows.Forms.ToolBar();
			this.toolBarButton1 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton2 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton3 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton4 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton5 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton6 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton7 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton10 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton9 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton11 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton12 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton8 = new System.Windows.Forms.ToolBarButton();
			this._toolBar2 = new System.Windows.Forms.ToolBar();
			this.toolBarButton13 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton14 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton15 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton16 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton17 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton18 = new System.Windows.Forms.ToolBarButton();
			this._toolBar3 = new System.Windows.Forms.ToolBar();
			this.toolBarButton23 = new System.Windows.Forms.ToolBarButton();
			this.toolBarButton24 = new System.Windows.Forms.ToolBarButton();
			this._toolBar4 = new System.Windows.Forms.ToolBar();
			this.toolBarButton19 = new System.Windows.Forms.ToolBarButton();
			this._richTextBox = new System.Windows.Forms.RichTextBox();
			this._dateTimePicker = new System.Windows.Forms.DateTimePicker();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.menuItem19 = new System.Windows.Forms.MenuItem();
			this.menuItem16 = new System.Windows.Forms.MenuItem();
			this.menuItem17 = new System.Windows.Forms.MenuItem();
			this.menuItem18 = new System.Windows.Forms.MenuItem();
			this.menuView = new System.Windows.Forms.MenuItem();
			this.menuViewToolbars = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// _imageList
			// 
			this._imageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this._imageList.ImageSize = new System.Drawing.Size(16, 16);
			this._imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("_imageList.ImageStream")));
			this._imageList.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// _toolBar1
			// 
			this._toolBar1.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this._toolBar1.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						 this.toolBarButton1,
																						 this.toolBarButton2,
																						 this.toolBarButton3,
																						 this.toolBarButton4,
																						 this.toolBarButton5,
																						 this.toolBarButton6,
																						 this.toolBarButton7,
																						 this.toolBarButton10,
																						 this.toolBarButton9,
																						 this.toolBarButton11,
																						 this.toolBarButton12,
																						 this.toolBarButton8});
			this._toolBar1.Divider = false;
			this._toolBar1.Dock = System.Windows.Forms.DockStyle.None;
			this._toolBar1.DropDownArrows = true;
			this._toolBar1.ImageList = this._imageList;
			this._toolBar1.Name = "_toolBar1";
			this._toolBar1.ShowToolTips = true;
			this._toolBar1.Size = new System.Drawing.Size(100, 111);
			this._toolBar1.TabIndex = 0;
			// 
			// toolBarButton1
			// 
			this.toolBarButton1.ImageIndex = 4;
			// 
			// toolBarButton2
			// 
			this.toolBarButton2.ImageIndex = 7;
			// 
			// toolBarButton3
			// 
			this.toolBarButton3.ImageIndex = 11;
			// 
			// toolBarButton4
			// 
			this.toolBarButton4.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton5
			// 
			this.toolBarButton5.ImageIndex = 6;
			// 
			// toolBarButton6
			// 
			this.toolBarButton6.ImageIndex = 5;
			// 
			// toolBarButton7
			// 
			this.toolBarButton7.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton10
			// 
			this.toolBarButton10.ImageIndex = 1;
			// 
			// toolBarButton9
			// 
			this.toolBarButton9.ImageIndex = 0;
			// 
			// toolBarButton11
			// 
			this.toolBarButton11.ImageIndex = 12;
			// 
			// toolBarButton12
			// 
			this.toolBarButton12.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton8
			// 
			this.toolBarButton8.ImageIndex = 3;
			// 
			// _toolBar2
			// 
			this._toolBar2.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this._toolBar2.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						 this.toolBarButton13,
																						 this.toolBarButton14,
																						 this.toolBarButton15,
																						 this.toolBarButton16,
																						 this.toolBarButton17,
																						 this.toolBarButton18});
			this._toolBar2.Divider = false;
			this._toolBar2.Dock = System.Windows.Forms.DockStyle.None;
			this._toolBar2.DropDownArrows = true;
			this._toolBar2.ImageList = this._imageList;
			this._toolBar2.Name = "_toolBar2";
			this._toolBar2.ShowToolTips = true;
			this._toolBar2.Size = new System.Drawing.Size(100, 67);
			this._toolBar2.TabIndex = 1;
			// 
			// toolBarButton13
			// 
			this.toolBarButton13.ImageIndex = 8;
			// 
			// toolBarButton14
			// 
			this.toolBarButton14.ImageIndex = 7;
			// 
			// toolBarButton15
			// 
			this.toolBarButton15.ImageIndex = 11;
			// 
			// toolBarButton16
			// 
			this.toolBarButton16.Style = System.Windows.Forms.ToolBarButtonStyle.Separator;
			// 
			// toolBarButton17
			// 
			this.toolBarButton17.ImageIndex = 6;
			// 
			// toolBarButton18
			// 
			this.toolBarButton18.ImageIndex = 5;
			// 
			// _toolBar3
			// 
			this._toolBar3.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this._toolBar3.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						 this.toolBarButton23,
																						 this.toolBarButton24});
			this._toolBar3.Divider = false;
			this._toolBar3.Dock = System.Windows.Forms.DockStyle.None;
			this._toolBar3.DropDownArrows = true;
			this._toolBar3.ImageList = this._imageList;
			this._toolBar3.Name = "_toolBar3";
			this._toolBar3.ShowToolTips = true;
			this._toolBar3.Size = new System.Drawing.Size(100, 23);
			this._toolBar3.TabIndex = 2;
			// 
			// toolBarButton23
			// 
			this.toolBarButton23.ImageIndex = 9;
			// 
			// toolBarButton24
			// 
			this.toolBarButton24.ImageIndex = 10;
			// 
			// _toolBar4
			// 
			this._toolBar4.Appearance = System.Windows.Forms.ToolBarAppearance.Flat;
			this._toolBar4.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
																						 this.toolBarButton19});
			this._toolBar4.Divider = false;
			this._toolBar4.Dock = System.Windows.Forms.DockStyle.None;
			this._toolBar4.DropDownArrows = true;
			this._toolBar4.ImageList = this._imageList;
			this._toolBar4.Name = "_toolBar4";
			this._toolBar4.ShowToolTips = true;
			this._toolBar4.Size = new System.Drawing.Size(100, 23);
			this._toolBar4.TabIndex = 3;
			// 
			// toolBarButton19
			// 
			this.toolBarButton19.ImageIndex = 12;
			// 
			// _richTextBox
			// 
			this._richTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this._richTextBox.Name = "_richTextBox";
			this._richTextBox.Size = new System.Drawing.Size(292, 266);
			this._richTextBox.TabIndex = 4;
			this._richTextBox.Text = "";
			// 
			// _dateTimePicker
			// 
			this._dateTimePicker.Name = "_dateTimePicker";
			this._dateTimePicker.TabIndex = 5;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem2,
																					  this.menuView,
																					  this.menuItem3,
																					  this.menuItem6,
																					  this.menuItem4});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem7,
																					  this.menuItem12,
																					  this.menuItem8,
																					  this.menuItem9,
																					  this.menuItem10,
																					  this.menuItem13,
																					  this.menuItem11});
			this.menuItem1.Text = "File";
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 0;
			this.menuItem7.Text = "New";
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 1;
			this.menuItem12.Text = "-";
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 2;
			this.menuItem8.Text = "Open";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 3;
			this.menuItem9.Text = "Save";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 4;
			this.menuItem10.Text = "Save as...";
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 5;
			this.menuItem13.Text = "-";
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 6;
			this.menuItem11.Text = "Quit";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem14,
																					  this.menuItem15,
																					  this.menuItem19,
																					  this.menuItem16,
																					  this.menuItem17,
																					  this.menuItem18});
			this.menuItem2.Text = "Edit";
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 0;
			this.menuItem14.Text = "Undo";
			// 
			// menuItem15
			// 
			this.menuItem15.Index = 1;
			this.menuItem15.Text = "Redo";
			// 
			// menuItem19
			// 
			this.menuItem19.Index = 2;
			this.menuItem19.Text = "-";
			// 
			// menuItem16
			// 
			this.menuItem16.Index = 3;
			this.menuItem16.Text = "Cut";
			// 
			// menuItem17
			// 
			this.menuItem17.Index = 4;
			this.menuItem17.Text = "Copy";
			// 
			// menuItem18
			// 
			this.menuItem18.Index = 5;
			this.menuItem18.Text = "Paste";
			// 
			// menuView
			// 
			this.menuView.Index = 2;
			this.menuView.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					 this.menuViewToolbars});
			this.menuView.Text = "View";
			this.menuView.Popup += new System.EventHandler(this.menuView_Popup);
			// 
			// menuViewToolbars
			// 
			this.menuViewToolbars.Index = 0;
			this.menuViewToolbars.Text = "Toolbars";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 3;
			this.menuItem3.Text = "Extras";
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 4;
			this.menuItem6.Text = "Window";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 5;
			this.menuItem4.Text = "?";
			// 
			// ExampleForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this._toolBar4,
																		  this._toolBar3,
																		  this._toolBar2,
																		  this._toolBar1,
																		  this._dateTimePicker,
																		  this._richTextBox});
			this.Menu = this.mainMenu1;
			this.Name = "ExampleForm";
			this.Text = "Example ";
			this.ResumeLayout(false);

		}
		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new ExampleForm());
		}

		private void menuView_Popup(object sender, System.EventArgs e)
		{
			menuViewToolbars.MenuItems.Clear();
			foreach (Control c in _toolBarManager.GetControls())
			{
				ToolBarDockHolder holder = _toolBarManager.GetHolder(c);
				MenuItem mi = new MenuItem(holder.ToolbarTitle, new EventHandler(this.viewToolbarsClicked));
				mi.Checked = holder.Visible;
				menuViewToolbars.MenuItems.Add(mi);
			}
		}

		private void viewToolbarsClicked(object sender, EventArgs e)
		{
			MenuItem mi = sender as MenuItem;
			ToolBarDockHolder holder = _toolBarManager.GetHolder(mi.Text);
			_toolBarManager.ShowControl(holder.Control, !holder.Control.Visible);
		}
	}
}
